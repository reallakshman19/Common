#!/usr/bin/env node
// Only converts POSIX-runner raw receipts into the shared JSON manifest.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const [root, pkg] = process.argv.slice(2);
if (!root || !pkg) {console.error('Usage: node finalize-posix-meta.mjs RECEIPTS PACKAGE');process.exit(2);}
const pinned=JSON.parse(fs.readFileSync(path.join(pkg,'PINNED.json'),'utf8'));
const read=x=>fs.readFileSync(path.join(root,x),'utf8').trimEnd();
const result={runKind:'LOCAL_NATIVE_PINNED_CLEAN_CLONES',runTimestamp:new Date().toISOString(),node:read('node-version.txt'),git:read('git-version.txt'),platform:os.platform()+' '+os.release(),host:os.hostname(),runs:{}};
for(const label of ['base','head']){
 const hashes=read(`hashes-${label}.tsv`).split('\n').filter(Boolean).map(s=>{const [p,a,b]=s.split('\t');return {path:p,headBlob:a,rawBlob:b};});
 result[label]={commit:label==='base'?pinned.base:pinned.head,headObserved:read(`head-${label}.txt`),testFileCount:Number(read(`count-${label}.txt`)),gitStatusBefore:read(`status-${label}-before.txt`),gitStatusAfter:read(`status-${label}-after.txt`),hashes};
}
for(const name of ['base-target','head-target','base-full','head-full']){
 result.runs[name]={exit:Number(read(`exit-${name}.txt`)),arguments:read(`command-${name}.txt`),stdout:`${name}.tap`,stderr:`${name}.stderr`};
}
fs.writeFileSync(path.join(root,'execution-meta.json'),JSON.stringify(result,null,2)+'\n');
console.log('Created:',path.join(root,'execution-meta.json'));
