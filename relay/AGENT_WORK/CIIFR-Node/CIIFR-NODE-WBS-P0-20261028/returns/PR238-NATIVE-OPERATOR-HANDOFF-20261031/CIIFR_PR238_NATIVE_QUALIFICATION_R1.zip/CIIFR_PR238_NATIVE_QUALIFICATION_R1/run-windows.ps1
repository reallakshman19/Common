<#
  CIIFR-Node PR238 pinned native review runner.
  Requires Git, Node 22+, and access to GitHub. Creates new detached clean clones.
  Does not mutate product source or any pre-existing checkout.
#>
param([Parameter(Position=0)][string]$OutputRoot = '')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$packageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pinned = Get-Content -LiteralPath (Join-Path $packageDir 'PINNED.json') -Raw | ConvertFrom-Json
if (-not $OutputRoot) {
  $OutputRoot = Join-Path (Get-Location).Path ('PR238_NATIVE_' + (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ') + '_' + $PID)
}
if (Test-Path -LiteralPath $OutputRoot) { throw ('Refusing existing directory: ' + $OutputRoot) }
[void](New-Item -ItemType Directory -Path $OutputRoot)
$OutputRoot = (Resolve-Path -LiteralPath $OutputRoot).Path
$receipts = Join-Path $OutputRoot 'receipts'
[void](New-Item -ItemType Directory -Path $receipts)
$nodeCmd = (Get-Command node -ErrorAction Stop).Source
$gitCmd  = (Get-Command git -ErrorAction Stop).Source
$meta = [ordered]@{
  runKind='LOCAL_NATIVE_PINNED_CLEAN_CLONES'
  runTimestamp=[DateTime]::UtcNow.ToString('o')
  node=(& $nodeCmd --version).Trim()
  git=(& $gitCmd --version).Trim()
  platform=[Environment]::OSVersion.VersionString
  host=[Environment]::MachineName
  runs=[ordered]@{}
}
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
function Save-Meta {
  $data = $script:meta | ConvertTo-Json -Depth 25
  [IO.File]::WriteAllText((Join-Path $script:receipts 'execution-meta.json'), $data + "`n", $script:utf8NoBom)
}
function Checked-Git {
  param([string]$Dir, [string[]]$GitArgs)
  $data = & $script:gitCmd -C $Dir @GitArgs 2>&1
  if ($LASTEXITCODE -ne 0) { throw ('Git command failed: git -C ' + $Dir + ' ' + ($GitArgs -join ' ') + ': ' + ($data | Out-String)) }
  return (($data | Out-String).Trim())
}
function Clone-Exact {
  param([string]$Label, [string]$Sha)
  $dir = Join-Path $script:OutputRoot $Label
  Write-Host ('Cloning ' + $Label + ' at ' + $Sha)
  $cloneOutput = Join-Path $script:receipts ('clone-' + $Label + '.stdout')
  $cloneError = Join-Path $script:receipts ('clone-' + $Label + '.stderr')
  # Git -c setting must be applied BEFORE first checkout, including for Windows autocrlf defaults.
  $p = Start-Process -FilePath $script:gitCmd -ArgumentList @('-c','core.autocrlf=false','clone','--no-checkout',$script:pinned.repository,('"'+$dir+'"')) -Wait -PassThru -NoNewWindow -RedirectStandardOutput $cloneOutput -RedirectStandardError $cloneError
  if ($p.ExitCode -ne 0) { throw ('Clone failed for ' + $Label + '; see ' + $cloneError) }
  [void](Checked-Git $dir @('config','core.autocrlf','false'))
  $checkoutOutput = Join-Path $script:receipts ('checkout-' + $Label + '.stdout')
  $checkoutError = Join-Path $script:receipts ('checkout-' + $Label + '.stderr')
  $p = Start-Process -FilePath $script:gitCmd -ArgumentList @('-C',('"'+$dir+'"'),'checkout','--detach',$Sha) -Wait -PassThru -NoNewWindow -RedirectStandardOutput $checkoutOutput -RedirectStandardError $checkoutError
  if ($p.ExitCode -ne 0) { throw ('Checkout failed for ' + $Label + '; see ' + $checkoutError) }
  $observed = Checked-Git $dir @('rev-parse','HEAD')
  if ($observed -ne $Sha) { throw ('Pinned identity mismatch for ' + $Label + ': ' + $observed) }
  $before = Checked-Git $dir @('status','--porcelain=v1','--untracked-files=all')
  $testFiles = @((& $script:gitCmd -C $dir ls-files -- 'tests/cii-fnr-vnext-*.test.mjs') | Where-Object { $_ })
  if ($LASTEXITCODE -ne 0 -or $testFiles.Count -ne 21) { throw ('VNext test list count mismatch ' + $Label + ': ' + $testFiles.Count) }
  $verifiedPaths = @($testFiles)
  foreach ($entry in $script:pinned.blobExpectations.PSObject.Properties) {
    if ($entry.Name.StartsWith('tabs/')) {
      $verifiedPaths += $entry.Name
      $verifiedPaths += 'docs/' + $entry.Name
    }
  }
  $hashes = @()
  foreach ($file in @($verifiedPaths | Select-Object -Unique)) {
    $blob = Checked-Git $dir @('rev-parse',('HEAD:' + $file))
    $raw = Checked-Git $dir @('hash-object','--no-filters','--',$file)
    if ($raw -ne $blob) { throw ('Raw worktree blob mismatch ' + $Label + ': ' + $file) }
    $hashes += [ordered]@{ path=$file; headBlob=$blob; rawBlob=$raw }
  }
  $script:meta[$Label] = [ordered]@{ commit=$Sha;headObserved=$observed;testFileCount=$testFiles.Count;gitStatusBefore=$before;gitStatusAfter=$before;hashes=$hashes }
  $script:meta[$Label + 'TestPaths'] = $testFiles
  Save-Meta
}
function Run-Case {
  param([string]$Label, [string]$Kind)
  $tag = "$Label-$Kind"
  $dir = Join-Path $script:OutputRoot $Label
  $arguments = @('--test','--test-reporter=tap')
  if ($Kind -eq 'full') {
    $arguments += '--test-concurrency=1'
    $arguments += @($script:meta[$Label + 'TestPaths'])
  } else { $arguments += 'tests/cii-fnr-vnext-branch-scope.test.mjs' }
  $stdout = Join-Path $script:receipts ($tag + '.tap')
  $stderr = Join-Path $script:receipts ($tag + '.stderr')
  Write-Host ('Running ' + $tag + ' at exact ' + $script:meta[$Label].headObserved)
  # Start-Process writes the native raw stdout/stderr bytes (PowerShell 5 > redirection does not).
  $p = Start-Process -FilePath $script:nodeCmd -ArgumentList $arguments -WorkingDirectory $dir -Wait -PassThru -NoNewWindow -RedirectStandardOutput $stdout -RedirectStandardError $stderr
  $script:meta.runs[$tag] = [ordered]@{ exit=[int]$p.ExitCode;arguments=('node '+($arguments -join ' '));stdout=($tag+'.tap');stderr=($tag+'.stderr') }
  Save-Meta
  Write-Host ($tag + ': exit ' + $p.ExitCode)
}
try {
  Clone-Exact 'base' $pinned.base
  Clone-Exact 'head' $pinned.head
  Run-Case 'base' 'target'
  Run-Case 'head' 'target'
  Run-Case 'base' 'full'
  Run-Case 'head' 'full'
  foreach ($label in @('base','head')) {
    $dir = Join-Path $OutputRoot $label
    $meta[$label].gitStatusAfter = Checked-Git $dir @('status','--porcelain=v1','--untracked-files=all')
  }
  Save-Meta
  $verificationLog = Join-Path $receipts 'verifier.stdout'
  $verificationErr = Join-Path $receipts 'verifier.stderr'
  $arguments = @(('"' + (Join-Path $packageDir 'verify-results.mjs') + '"'), ('"' + $receipts + '"'))
  $p = Start-Process -FilePath $nodeCmd -ArgumentList $arguments -WorkingDirectory $packageDir -Wait -PassThru -NoNewWindow -RedirectStandardOutput $verificationLog -RedirectStandardError $verificationErr
  Write-Host ('Verification exit: ' + $p.ExitCode + '; receipts: ' + $receipts)
  if (Test-Path (Join-Path $receipts 'verification.json')) { Get-Content -LiteralPath (Join-Path $receipts 'verification.json') -Raw | Write-Output }
  exit $p.ExitCode
} catch {
  $meta['setupError'] = $_.Exception.Message
  Save-Meta
  [Console]::Error.WriteLine('Qualification incomplete, see ' + $receipts + ': ' + $_.Exception.Message)
  exit 2
}
