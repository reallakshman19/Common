#!/usr/bin/env bash
# Read-only native PR238 qualification. Creates new isolated detached clones; never reuses a checkout.
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT="${1:-$PWD/PR238_NATIVE_$(date -u +%Y%m%dT%H%M%SZ)_$$}"
if [[ -e "$ROOT" ]]; then printf 'Refusing to reuse existing directory: %s\n' "$ROOT" >&2; exit 2; fi
mkdir -p "$ROOT/receipts"; ROOT="$(cd "$ROOT" && pwd -P)"
RECEIPTS="$ROOT/receipts"
# If native checkout is blocked, retain a machine-readable failure receipt; do not create false TAP results.
on_exit () {
 local rc=$?
 if [[ "$rc" -ne 0 && ! -f "$RECEIPTS/verification.json" ]]; then
   printf 'EXIT_CODE=%s\nSTAGE=%s\n' "$rc" "${CURRENT_STAGE:-SETUP}" > "$RECEIPTS/blocked-status.txt"
 fi
}
trap on_exit EXIT
CURRENT_STAGE=PREREQUISITES
command -v git >/dev/null || { echo 'Missing git' >&2; exit 2; }
command -v node >/dev/null || { echo 'Missing node' >&2; exit 2; }
git --version > "$RECEIPTS/git-version.txt"
node --version > "$RECEIPTS/node-version.txt"
mapfile -t CONFIG < <(node -e 'const j=require(process.argv[1]);console.log(j.repository);console.log(j.base);console.log(j.head)' "$PKG/PINNED.json")
REPO="${CONFIG[0]}"; BASE="${CONFIG[1]}"; HEAD="${CONFIG[2]}"

clone_exact () {
 local label="$1" sha="$2" dir="$ROOT/$1"
 printf 'Cloning exact %s %s\n' "$label" "$sha"
 git -c core.autocrlf=false clone --no-checkout "$REPO" "$dir" > "$RECEIPTS/clone-${label}.stdout" 2> "$RECEIPTS/clone-${label}.stderr"
 git -C "$dir" config core.autocrlf false
 git -C "$dir" checkout --detach "$sha" > "$RECEIPTS/checkout-${label}.stdout" 2> "$RECEIPTS/checkout-${label}.stderr"
 local observed
 observed="$(git -C "$dir" rev-parse HEAD)"
 printf '%s\n' "$observed" > "$RECEIPTS/head-${label}.txt"
 [[ "$observed" == "$sha" ]] || { echo "Wrong HEAD for $label: $observed" >&2; exit 3; }
 git -C "$dir" status --porcelain=v1 --untracked-files=all > "$RECEIPTS/status-${label}-before.txt"
 mapfile -t tests < <(git -C "$dir" ls-files -- 'tests/cii-fnr-vnext-*.test.mjs')
 printf '%s\n' "${#tests[@]}" > "$RECEIPTS/count-${label}.txt"
 [[ "${#tests[@]}" -eq 21 ]] || { echo "Wrong test file count for $label" >&2; exit 3; }
 # Probe every VNext test and each critical source and served mirror, using Git raw blobs.
 mapfile -t modules < <(node -e 'const j=require(process.argv[1]);for(const p of Object.keys(j.blobExpectations).filter(x=>x.startsWith("tabs/"))){console.log(p);console.log("docs/"+p)}' "$PKG/PINNED.json")
 printf '' > "$RECEIPTS/hashes-${label}.tsv"
 for p in "${tests[@]}" "${modules[@]}"; do
   local raw gitblob
   gitblob="$(git -C "$dir" rev-parse "HEAD:$p")"
   raw="$(git -C "$dir" hash-object --no-filters -- "$p")"
   printf '%s\t%s\t%s\n' "$p" "$gitblob" "$raw" >> "$RECEIPTS/hashes-${label}.tsv"
   [[ "$raw" == "$gitblob" ]] || { echo "Raw Git mismatch: $label / $p" >&2; exit 3; }
 done
}

run_test() {
 local label="$1" kind="$2" dir="$ROOT/$1" tag="${label}-${kind}"
 local -a args=(--test --test-reporter=tap)
 if [[ "$kind" == full ]]; then
   args+=(--test-concurrency=1)
   mapfile -t list < <(git -C "$dir" ls-files -- 'tests/cii-fnr-vnext-*.test.mjs')
   args+=("${list[@]}")
 else
   args+=(tests/cii-fnr-vnext-branch-scope.test.mjs)
 fi
 printf 'node' > "$RECEIPTS/command-${tag}.txt"
 printf ' %q' "${args[@]}" >> "$RECEIPTS/command-${tag}.txt"
 printf '\n' >> "$RECEIPTS/command-${tag}.txt"
 printf 'Executing %s\n' "$tag"
 set +e
 (cd "$dir" && node "${args[@]}") > "$RECEIPTS/${tag}.tap" 2> "$RECEIPTS/${tag}.stderr"
 local code=$?
 set -e
 printf '%s\n' "$code" > "$RECEIPTS/exit-${tag}.txt"
 printf '%s native exit %s\n' "$tag" "$code"
}

CURRENT_STAGE=CLONE_BASE
clone_exact base "$BASE"
CURRENT_STAGE=CLONE_HEAD
clone_exact head "$HEAD"
CURRENT_STAGE=TEST_BASE_TARGET
run_test base target
CURRENT_STAGE=TEST_HEAD_TARGET
run_test head target
CURRENT_STAGE=TEST_BASE_FULL
run_test base full
CURRENT_STAGE=TEST_HEAD_FULL
run_test head full
for label in base head; do
 git -C "$ROOT/$label" status --porcelain=v1 --untracked-files=all > "$RECEIPTS/status-${label}-after.txt"
done
CURRENT_STAGE=RECEIPT_ASSEMBLY
node "$PKG/finalize-posix-meta.mjs" "$RECEIPTS" "$PKG"
set +e
node "$PKG/verify-results.mjs" "$RECEIPTS" > "$RECEIPTS/verifier.stdout" 2> "$RECEIPTS/verifier.stderr"
code=$?
set -e
printf 'Verification exit: %s, receipts: %s\n' "$code" "$RECEIPTS"
cat "$RECEIPTS/verification.json" | head -50
exit "$code"
