# OWNER → Authorized local native-execution operator — CIIFR-Node PR238

**Existing non-author review continuation; execution only. No takeover, production edit or merge.**

Execute the supplied `CIIFR_PR238_NATIVE_QUALIFICATION_R1` package on an authorized network-connected Windows or Linux workstation. Follow `README.md`. Pin exact base `417bf6a954c5a6de72237537e94b05b285191350` and candidate `fa6e948eb0f71ba93fe8bab01625e3146d1df3a0`; DO NOT substitute moving `main` or a newer head. Record your actual operator identity, system platform, Node version, Git version and authorship/prior exposure. Do not call this blind review or distinct GitHub principal if authenticated as the PR author.

**Execute:** In a new directory, with autocrlf disabled before first checkout, run targeted base + candidate tests and complete base + candidate VNext suites using separate clean clones. Collect `git rev-parse HEAD`, raw `git hash-object --no-filters` compared with `git rev-parse HEAD:<path>` for every VNext test and critical source/served mirror, clean status before/after, exact commands, exit codes and raw TAP. Preserve the expected inherited base FAIL; it is not a new candidate defect. Review and explain any unexpected result without editing the tests.

**Required checks:** `verification.json` must show `PASS_PINNED_NATIVE_TESTS`. Do not relabel the author's old 125/125 source overlay as an integrated head. Verify no untracked or modified files after tests, no private original file, and no source/fixture changes.

**Return:** Package `receipts/` with a `sha256sum` or PowerShell `Get-FileHash` inventory and publish the measured identities through the *existing* Common CIIFR-Node task relay. Post a concise execution addendum on PR238 linking the relay and cross-link issue231 once if it is not already linked for this execution. Record actual identities/readback and your actual account relationship to the author. If execution fails, report `PARTIAL`/`NOT_RUN` with failure stage and logs; do not claim PASS.

**Authority:** Native qualification is independent of engineering/vendor acceptance. GATE_R0 remains HOLD. PR238, PR232 and PR226 merges, P2 work, property writing, deployment and release require Owner approval; stop after evidence return.
