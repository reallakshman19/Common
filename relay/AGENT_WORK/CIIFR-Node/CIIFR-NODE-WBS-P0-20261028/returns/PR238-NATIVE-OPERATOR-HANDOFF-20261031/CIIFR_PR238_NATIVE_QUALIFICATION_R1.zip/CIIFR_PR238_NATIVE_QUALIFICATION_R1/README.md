# CIIFR-Node PR238 — exact-pinned native qualification runner

**Status on creation:** NOT_RUN in the review agent environment. This package is a native operator runner, not evidence that the native gate has passed. It neither requires private original CII nor edits product source. Do **not** use an existing working checkout.

Repository: `https://github.com/reallakshman19/XML_Compare_Utilities.git`  
Base: `417bf6a954c5a6de72237537e94b05b285191350`  
Candidate: `fa6e948eb0f71ba93fe8bab01625e3146d1df3a0`.

## Run once on a connected machine

Requirements: Git, Node.js 22+ (ideally 24.22.1 to compare with author logs), and network access to GitHub. The scripts create **two separate clean clones** in a new timestamped directory, disable autocrlf **before checkout**, pin detached HEAD, verify repository and raw worktree blobs, and execute:

- base targeted test;
- head targeted test;
- base full 21-file VNext suite (useful extra comparison);
- head full 21-file VNext suite.

### Windows PowerShell

Open PowerShell in the directory where the ZIP was extracted:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run-windows.ps1
```

### Linux/macOS Bash

```bash
bash ./run-posix.sh
```

Optional: pass a fresh output root as the script's first argument. It **must not already exist**; the script will refuse to reuse or delete an existing directory. Windows examples may use a quoted absolute path.

## Acceptance and receipts

Each runner creates `base/`, `head/` and `receipts/` inside the new output root. Receipts contain:

- `execution-meta.json` — pinned identities, raw Git-object and raw-worktree `git hash-object --no-filters` values for all 21 VNext tests plus critical source and served modules; clean worktree state; tool versions; exact test counts and raw exit codes.
- `base-target.tap`, `head-target.tap`, `base-full.tap`, `head-full.tap` — unmodified native test output.
- `verification.json` — result of independent receipt consistency checks.

Expected: base targeted **18 pass / 1 fail** (19 total), head targeted **20/20 pass**; base full **94/1** (95 total), head full **96/96**. The base failure must be retained rather than suppressed. Any unexpected count, incorrect Git object, dirty checkout, missing file or nonzero head exit causes the verifier to report `FAIL_OR_INCOMPLETE`.

The standalone verification command is:

```bash
node verify-results.mjs /absolute/path/to/receipts
```

**Deliver:** the `receipts/` directory and the script's exit status to the PR238 thread and the existing Common CIIFR-Node relay. Do not upload credentials, private originals or unrelated worktrees. The final gate is source and test qualification only; **GATE_R0, merges PR238/232/226, P2, Property Transfer writing and release remain HOLD** pending Owner decision.

## Integrity and limits

Known blob identities are pinned in `PINNED.json` (base and head test blobs, production and served mirrors). A test-only correction with unchanged source modules cannot replace vendor/CAESAR qualification. These scripts do not use author-reported TAP logs as pass input. GitHub Actions ISO Composite Identity jobs on PR238 are not substitutes for the targeted VNext suite.
