#!/usr/bin/env node
// Verifies existing receipts. Does not run tests, fetch, edit, or approve merges.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const packageDir = path.dirname(fileURLToPath(import.meta.url));
const pinned = JSON.parse(fs.readFileSync(path.join(packageDir, 'PINNED.json'), 'utf8'));
const root = process.argv[2];
if (!root) { console.error('Usage: node verify-results.mjs <absolute receipts-directory>'); process.exit(2); }
const problems = [], checks = {}, logs = {};
const get = name => fs.readFileSync(path.join(root, name));
const digest = b => crypto.createHash('sha256').update(b).digest('hex');
let meta;
try { meta = JSON.parse(get('execution-meta.json').toString('utf8')); }
catch (e) { console.error('Missing or invalid execution-meta.json:', e.message); process.exit(2); }
for (const label of ['base', 'head']) {
  const id = label === 'base' ? pinned.base : pinned.head;
  if (meta[label]?.commit !== id || meta[label]?.headObserved !== id)
    problems.push(`${label} commit identity mismatch`);
  if (meta[label]?.testFileCount !== pinned.expectedTestFiles)
    problems.push(`${label} file count: ${meta[label]?.testFileCount}, expected ${pinned.expectedTestFiles}`);
  if (meta[label]?.gitStatusBefore !== '' || meta[label]?.gitStatusAfter !== '')
    problems.push(`${label} worktree not clean at start/end`);
  const rows = (meta[label]?.hashes ?? []);
  checks[`${label}-raw-hash-rows`] = rows.length;
  if (rows.length < pinned.expectedTestFiles + 8)
    problems.push(`${label} too few worktree blob rows: ${rows.length}`);
  for (const x of rows) {
    if (!x.path || !/^[a-f0-9]{40}$/.test(x.headBlob ?? '') ||
        x.headBlob !== x.rawBlob) problems.push(`${label} raw blob mismatch: ${x.path}`);
    const rule = pinned.blobExpectations[x.path] || pinned.blobExpectations[x.path.replace(/^docs\//, '')];
    if (rule) {
      const want = typeof rule === 'string' ? rule : rule[label];
      if (want && x.headBlob !== want) problems.push(`${label} known-blob mismatch: ${x.path}`);
    }
  }
  const testblob = pinned.blobExpectations['tests/cii-fnr-vnext-branch-scope.test.mjs'][label];
  if (!rows.some(x => x.path === 'tests/cii-fnr-vnext-branch-scope.test.mjs' && x.rawBlob === testblob))
    problems.push(`${label} pinned test Git blob not verified`);
  const modules = Object.keys(pinned.blobExpectations).filter(x=>x.startsWith('tabs/'));
  for (const p of modules) {
    if (!rows.some(x=>x.path===p && x.rawBlob===pinned.blobExpectations[p]))
      problems.push(`${label} module missing/mismatch: ${p}`);
    if (!rows.some(x=>x.path==='docs/'+p && x.rawBlob===pinned.blobExpectations[p]))
      problems.push(`${label} served mirror missing/mismatch: ${p}`);
  }
}
for (const [label, expected] of Object.entries(pinned.expected)) {
  try {
    const contents = get(`${label}.tap`);
    logs[`${label}.tap`] = { bytes:contents.length, sha256:digest(contents) };
    const txt = contents.toString('utf8');
    const count = (name) => {
      const matches = [...txt.matchAll(new RegExp(`^# ${name} (\\d+)\\s*$`, 'gm'))];
      return matches.length ? Number(matches.at(-1)[1]) : null;
    };
    const got = { tests:count('tests'), pass:count('pass'), fail:count('fail'), exit:meta.runs?.[label]?.exit };
    checks[label] = got;
    for (const field of Object.keys(expected)) if (got[field] !== expected[field])
      problems.push(`${label}.${field}: got ${got[field]}, expected ${expected[field]}`);
    if (label === 'base-target' && !txt.includes('not ok ') )
      problems.push('base-target lacks inherited negative assertion');
    if (label === 'head-target' && !txt.includes('exact B1 selection changes only its owned FROM name'))
      problems.push('head-target lacks B1 assertion');
  } catch(e) { problems.push(`${label}.tap missing/unreadable: ${e.message}`); }
}
const result = {
  verdict: problems.length ? 'FAIL_OR_INCOMPLETE' : 'PASS_PINNED_NATIVE_TESTS',
  scope: 'Native test qualification only; no CAESAR or Property Transfer acceptance',
  reviewerExecution: true, base:pinned.base, head:pinned.head,
  node:meta.node, git:meta.git, platform:meta.platform,
  checks, logs, problems,
  note: 'A passing artifact still does not establish distinct-human GitHub identity or merge authority.'
};
fs.writeFileSync(path.join(root,'verification.json'), JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
process.exitCode = problems.length ? 1 : 0;
