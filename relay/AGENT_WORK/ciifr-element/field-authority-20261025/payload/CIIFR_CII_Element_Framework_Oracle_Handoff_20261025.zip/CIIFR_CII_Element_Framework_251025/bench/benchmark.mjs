import {performance} from 'node:perf_hooks';
import {indexCii} from '../src/fixed-cii-index.mjs';
import {syntheticCii} from '../src/synthetic-fixtures.mjs';
import {planTransfer} from '../src/transfer-planner.mjs';
const samples=[353,1000,3000],runs=3;
const quantile=(x,q)=>x.slice().sort((a,b)=>a-b)[Math.ceil((x.length-1)*q)];
const results=[];
for(const n of samples){
  const input=syntheticCii({elementCount:n}), times=[];let observed;
  for(let i=0;i<runs+1;i++){
    const start=performance.now();observed=indexCii(input);
    const ms=performance.now()-start;if(i)times.push(ms);
  }
  const pair=observed.elements[0];const source=indexCii(input);
  const t0=performance.now();const planned=planTransfer({source,target:observed,
    mapping:[{sourceFrom:pair.from,sourceTo:pair.to,targetFrom:pair.from,targetTo:pair.to}],
    properties:['ELEMENTS.DIAMETER','ELEMENTS.PRESSURE_1','RIGID.WEIGHT']});
  const planMs=performance.now()-t0;
  results.push({fixture:'PUBLIC_SYNTHETIC',elements:n,bytes:input.length,
    parseMedianMs:Number(quantile(times,.5).toFixed(3)),parseP95SampleMs:Number(quantile(times,.95).toFixed(3)),
    planOneRowMs:Number(planMs.toFixed(3)),processStatus:planned.proposals.find(x=>x.property==='ELEMENTS.PRESSURE_1')?.status,
    writerEligible:planned.writerEligible});
}
console.log(JSON.stringify({schema:'CIIFR.ElementBenchmark.v1',runtime:process.version,platform:process.platform,
  repeats:runs,notes:'One warm-up; sample p95 is not statistically rigorous; synthetic only; parsing read-only; no browser or export',results},null,2));
