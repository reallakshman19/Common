# Design rationale / decision register (shareable, not private deliberation)

**D1 · Why a node and an element are separate.** One node may be the TO of one element and FROM of another; rigid weight belongs to the member, not the node. Decision: NodeName selection uses a logical node; engineering property transfer uses a unique element witness.

**D2 · Why pointer is not a node number.** An element's NODENAME pointer indexes another section. A zero pointer has no field to overwrite; a valid pointer can still be shared. Decision: use typed, ordinal-based pointer resolution; no arbitrary number matching.

**D3 · Why the reader is byte-oriented.** Fixed-width fields can be adjacent with no whitespace separators; text reformatting changes outside-byte evidence. Decision: preserve original `Uint8Array` and record `[start,end)` slices; never round-trip a parsed object into output bytes as a writer shortcut.

**D4 · Why SOURCE/TARGET identical numbers are not identity authority.** Source revisions may renumber, split, reroute or reverse members. Decision: unique directed pair is only a candidate; typed data proposals remain review-only until separately qualified correspondence.

**D5 · Why case/unit qualification gates core process fields.** Temperature1 in one model might refer to a different scenario than Temperature1 in another, and a visually identical pressure could use different units. Decision: register process property IDs but deliberately HOLD until field schema, case index and unit mapping are independently sourced and tested.

**D6 · Why rigid transfer has its own adapter.** A rigid auxiliary row does not live at the same physical location as an ELEMENTS header field. Decision: do not infer RIGID pointer column using ordinal coincidences; qualify it from source/converter and negative fixtures first.

**D7 · Why no 'NodeName for rigids'.** Rigid data is element-specific. Creating endpoint names does not transfer weight/type and could introduce unrelated edits. Decision: remove that proposal; do not create NODENAME records during element property transfer.

**D8 · Why a separate framework, not Tab 3 patch.** Canonical issue #139 assigns Tab 3 to GEOMETRY. Later Owner discussion proposes Element Based Transfer. Decision: mark placement unresolved; produce a nonwired read-only component that can survive Owner scope arbitration.

**D9 · Why read-only first.** PR #176's structural writer has author self-tests but no independent qualification. The active G1 geometry branch shares UI paths; modifying it risks overlapping ownership. Decision: independent pure modules and fixtures, no active branch or writer edits, distinct independent review before consequential integration.

**D10 · Why synthetic fixtures aren't a benchmark oracle.** Fixture code and parser share assumptions; a 13/13 green suite does not prove physical data semantics. Decision: retain owner-original local census as separate **read-only observational** evidence; require native converter oracle, separately derived expectation and a surviving error case before writer acceptance.

## Rejected shortcuts
- 'Use only FromNode' for rigid transfer: ambiguous (many members share a node).
- 'Find (Info only) must match before node assignment': incorrect for the approved node-number operation.
- 'Rename rigid endpoint nodes first': no benefit to property transfer.
- 'Automatically transfer all temperatures/pressures from visually same slots': unsafe without case and units mapping.
- 'Reuse Geometry proximity as a confirmed element correspondence': not granted by original Method C and issue #139.
- 'Change Tab3 UI and writer in same prototype': conflicts with active authority and independence constraints.

## Highest-impact surviving wrong behavior
An adapter might read the right byte column on one sample but attach the wrong **operating case** or **auxiliary owner** on another, producing numerically plausible yet physically incorrect results. Independent falsification must use two original models or an independently produced fixture with deliberately permuted case slots and shared auxiliary pointers; require exact per-field provenance and a reject/HOLD result. The current suite does not establish this.
