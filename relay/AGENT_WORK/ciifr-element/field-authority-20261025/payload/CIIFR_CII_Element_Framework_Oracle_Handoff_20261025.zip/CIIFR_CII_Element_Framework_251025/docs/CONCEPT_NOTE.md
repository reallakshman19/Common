# CIIFR — CII Entity/Element/Pointer Transfer Framework · Concept Note v0.1

**Dated:** 25 October 2026  
**Status:** DESIGN + TESTED READ-ONLY PROTOTYPE, not product writer authorization.  
**Project:** XML_Compare_Utilities, CII Find & Replace / CII Compare workspace.  
**Source authority:** Owner conversation request for a general reusable core/process/rigid transfer architecture; XCU issue #139 (original three-tab contract); `docs/CIIcompareconceptnote.md` (identity/delta/writer separation); PR #176 (Nodal Based Node name transfer); pinned Common `START_HERE.md` at `63bb13d0`.

## End-user outcome
The Owner should be able to transfer explicitly selected engineering data from a trusted SOURCE CII or vetted CSV to a TARGET0 CII, by qualified logical node or element correspondence; inspect exactly what will change; approve individual operations; validate all physical record/pointer/count/units effects; and export TARGET1 as a new copy with a reversible evidence report. No silent global node offset, regex sweep across numeric fields, or modifications to original TARGET0.

## Scope is not silently changed
The original VNext task issue #139 explicitly defines Tab 3 as **GEOMETRY** (signed topology/correspondence), not generic element-property transfer. Later Owner discussion suggests an **Element Based Transfer** as a future tab/capability. Placement and amendment are UNRESOLVED: new element transfer MUST NOT replace or repurpose the assigned Geometry tab or its reviewer/coder work without a recorded Owner scope change. This package is a **separate, nonwired, read-only research seam**, not a competing implementation of #139's Tab 3.

## Objects are not interchangeable
1. **Physical CII section/record:** line-oriented ASCII fixed-width text with byte offsets; `#$ ELEMENTS` has 15 physical rows per element for the qualified v11/v14 subset. The first ELEMENTS row has 6 fields of widths `[15,13,13,13,13,13]`: FROM, TO, DX, DY, DZ, DIAMETER.
2. **Logical node:** file-local engineering node number, e.g. `565`. A single logical node may appear in many element endpoints; a node is not a physical record, a NodeName, or a pointer.
3. **Element:** directed FROM→TO member (plus an ordinal/witness to disambiguate duplicate pairs), owning an ELEMENTS 15-row physical card. `285` alone cannot select an element; `280→285` is an element pair, but duplicates may still exist.
4. **Auxiliary record:** a typed record in `NODENAME`, `RIGID`, `RESTRANT`, etc.; reference by **section-specific pointer index**. Pointer ordinal, node number, and element ordinal are different namespaces. Shared pointers alter multiple owners and cannot be edited naively.
5. **Engineering property:** a typed field or group, with authoritative section/row/column mapping, units, case meaning, cardinality dependency and preservation rule. Equal-looking numbers do not prove equal semantics.

## Three distinct products / engines
- Nodal NodeName assignment (PR #176): `FindNode → ReplaceName`, optional `Find` audit. All incident FROM/TO aliases and absent NODENAME pointers are in scope **only** under its separately qualified writer.
- Geometry correspondence (issue #139 / #166): SOURCE/TARGET graph registration and candidate evidence. An XY/Z near node, a projected segment point, and a genuinely approved physical NODE are not interchangeable. It is not a property writer.
- Element-property transfer (this package): SOURCE/TARGET element identity → typed direct-field or auxiliary-field read adapters → reviewable differences → **future** separately authorized writer. This is not node naming.

## Examples that distinguish concepts
- Node `565`: in the Owner's original 612,613-byte V14 TARGET0, ELEMENTS 112 `560→565` and 113 `565→570` both have `NODENAME` pointer 0. A NodeName writer must add valid records and patch CONTROL + both element pointer fields. A property transfer MUST NOT create NodeNames as a side effect.
- A hypothetical rigid element `10→15`: properties might live in a RIGID auxiliary record referenced by a **separately qualified RIGID pointer**, not by its endpoint names. Transferring rigid WEIGHT/TYPE is an ELEMENT operation, but matching `10→15` is not itself proof of physical correspondence across independently renumbered models.
- Process pressure/temperature: a direct ELEMENTS data field may have several scenario slots. Slot number, source units and operating case association must all be qualified; `0`, blank, and unparsed are different states.

## Functional contract for future adoption
Inputs: original SOURCE and TARGET0 byte streams + SHA-256, explicit mapping or independently accepted correspondence receipt, selected property groups/fields with qualified version+unit schema, and safety policy.

Output: `PlanResult` with per-property source and target witnesses, pointer chain if any, exact read spans and untouched source bytes, physical unit names, before/after values, HOLD reasons, ownership conflicts, applicability / missing values, and `writerEligible=false` until independently authorized.

Future writer remains separate: immutable TARGET0 → approved exact diff → before-byte guard → pointer/cardinality/schema/units checks → reparse and negative assurance → TARGET1 + raw changed-span report. This prototype deliberately implements **no writer / binary patch**.

## Acceptance gates (proposed, not a claim of acceptance)
- Correct physical byte index and V11/V14 dialect source map; full original fixture byte hashes checked privately.
- Source/target object identity proven independently or held; no global node offset, no first duplicate selected.
- Property adapter field map independently validated against converter/schema/native engineering oracle, with real precision and units/case interpretation.
- For pointer-backed properties, correct owner cardinality, existing / blank / missing / shared pointer semantics; new record creation only under specific writer amendment and noncollateral proof.
- All selected changes produce detailed before/after spans, protect irrelevant bytes and original TARGET0, and reparse exported TARGET1.
- A negative engineering case must survive test design review; native suite, served browser, and Owner's real-file trial are separate reports. No merger or release except Owner authorization.

## Next two connected bounded deliveries
**E1 — Source-and-schema qualification.** Read-only source-derived CII ELEMENTS process-field offset/case/units map and RIGID pointer map, dual-version real-file inventory with independent reference controls. Establish at least one real original comparison outcome and one bad pointer/case/unit falsifier. No writers.

**E2 — Transfer engine prototype.** Consume E1’s verified property descriptor and separately accepted element correspondence; implement selected process/rigid read-only transfer proposals with browser preview, evidence and explicit HOLDs. Only then propose a distinct Writer scope/authority card. Preserves E1’s negative tests.

**Owner arbitration required:** whether Element Based Transfer should be a separate later operation/workspace or amendment to the pre-existing three-tab VNext issue. No assumed tab replacement.
