# CII Architecture — Logical Nodes, 15-Row Elements, Physical Pointer Records

## 1. Physical fixed-width model (verified for the scoped V14 owner fixture)

```text
CII byte stream (immutable TARGET0)
  #$ VERSION      ... V11/V14 dialect indication
  #$ CONTROL      ... NODENAME count (13-character field at [41,54) in row 0)
  #$ ELEMENTS     ... 353 element cards x 15 physical lines in tested original
       card i, row 0: FROM [0,15), TO [15,28), DX [28,41),
                      DY [41,54), DZ [54,67), DIAMETER [67,80)
       card i, row13: NODENAME pointer [67,80) (1-based NODENAME record index)
       other record positions: NOT assumed transferable without field map
  #$ NODENAME     ... 258 rows in the tested original
       nameRecord ptr k, row: FROM name [2,28), TO name [28,53)
  #$ BEND         ... separate auxiliary rows
  #$ RIGID        ... 38 rows in the tested original; pointer mapping UNQUALIFIED
  #$ RESTRANT, ... ... additional auxiliary typed sections
  #$ UNITS        ... units config, required context for numeric transfer
```

Offsets are half-open **byte offsets within the original byte array**, not character positions after text reserialization. Element ordinals in this prototype are zero-based; NODENAME pointer indices in CII are **1-based**. Pointer 0 means *no referenced NODENAME record*. The physical first row does **not** contain a universal global node identifier distinct from FROM/TO.

## 2. The pointer chain — what the engine must follow

```text
Logical NODE 565
       |
       +-- (ELEMENTS index 112) 560 -> 565
       |          |  row13 namePtr = 0
       |          +---- [no NODENAME record to overwrite]
       |
       +-- (ELEMENTS index 113) 565 -> 570
                  |  row13 namePtr = 0
                  +---- [no NODENAME record to overwrite]

Nodal rename (distinct future writer authority) would:
  append 2 NODENAME rows, assign ptr 259/260,
  update row13 pointer spans in two existing ELEMENTS cards,
  update CONTROL NONAM 258 -> 260,
  reparse and check all unrelated content.

Element property transfer (THIS research seam) would:
  select an element witness and field/property,
  do NOT fabricate any NodeName pointer,
  produce read-only evidence and HOLD pending property-specific authority.
```

Three pointer states must remain distinct: `0 = ABSENT`, `1..count = VALID`, `>count / malformed = INVALID`. A valid index may still be **SHARED** by two or more element cards and requires explicit alias-owner resolution. An unreferenced existing record is **ORPHAN** and must not be silently reallocated. Some auxiliary sections have multirow units; pointers are section-typed and never treated as generic byte addresses.

## 3. Object identities and failure modes

```text
SOURCE immutable model           TARGET0 immutable model
       |                                 |
  original byte index                original byte index
       |                                 |
  physical element witnesses        physical element witnesses
       +-------- correspondence evidence ------+
                  one-to-one or HOLD
                                |
              field-specific typed adapter
               / direct         / auxiliary
       [ELEMENTS offset]    [ELEMENTS pointer] -> [SECTION record]
                 \            /
             qualified before/after evidence
                         |
                  conflict / unit / case / owner checks
                         |
            READ-ONLY PLAN (NO WRITER ELIGIBILITY)
                         |
           independent challenge + Owner decision
                         |
           future separate qualified Writer authority
```

A pair of numeric endpoints such as 10→15 is a **search key** and **evidence**, not universal engineering identity. Duplicate pairs, reversed direction, node renumbering and changed topology require a separate correspondence source. A projection onto an element segment is not automatically an existing physical node.

## 4. Typed descriptor, not generic regex

```ts
interface FieldDescriptor {
  id: string;
  dialect: 11 | 14;
  location: {section: string; cardRow?: number; colStart: number; colEnd: number};
  pointer?: {ownerSection: 'ELEMENTS'; pointerField: string;
             referencedSection: string; oneBased: true; cardinality: number};
  value: {semantic: string; encoding: string; units: string; caseId?: string;
          blankZeroPolicy: 'DISTINCT' | 'QUALIFIED_EQUAL'; precision: string};
  authority: {originalSource: string; oracle: string; qualification: string};
}
```

`PROPERTY_REGISTRY` in this kit publishes only read-qualified ELEMENTS.DIAMETER; TEMPERATURE_1, PRESSURE_1, FLUID_DENSITY, and RIGID.WEIGHT / TYPE are registered as **HOLD** examples. Do not infer offsets just from a 325-looking or 11600-looking string in raw records. Converter definitions / native benchmark qualification must establish row index, column, case semantics, units and version.

## 5. Proposed module seams

- `src/fixed-cii-index.mjs` — strict read-only fixed-width line and section index; known V11/V14 NODENAME pointer map.
- `src/element-identity.mjs` — exact directed pair lookup with duplicate HOLD; explicit source→target pairing flagged *unqualified*.
- `src/property-adapters.mjs` — typed property registry and read-only current-value access; unresolved process/rigid fields HOLD.
- `src/transfer-planner.mjs` — read-only proposal ledger, source/target provenance, unit-compatibility requirement; **never emits a writer claim**.
- `src/synthetic-fixtures.mjs` — invented v14 data, variable scale, blank-name pointer and shared/duplicate cases.
- `tests/framework.test.mjs` — adversarial native tests.
- `bench/benchmark.mjs` — synthetic parse/plan performance with explicit bounded environment and statistical limits.

These do NOT import or modify the existing Normal/Geometry/Writer implementation and do NOT change the three-tab UI shell. The platform-specific module import and contract wiring must be a later reviewed integration decision.

## 6. Architecture-specific hazards and counterexamples

| Counterexample | Required behavior | Implemented read-only check |
| --- | --- | --- |
| `NODE=565`, pointer 0 on two cards | no made-up physical name; record absence | yes |
| Shared valid NODENAME pointer | don't edit one owner and affect another | indexed; HOLD for future writer |
| Duplicate `FROM→TO` elements | no choose-first | yes |
| Reversed direction `TO→FROM` | no silent equivalence | yes |
| Nodes renumbered between files | explicit correspondence required | exact pairing alone unqualified |
| Source/target units differ | no numeric transfer | yes (exact UNITS payload compatibility check, provisional) |
| T/P case slot meaning differs | no wrong-case transfer | adapter HOLD |
| RIGID ordinal confused with NODENAME pointer | no cross-section alias | rigid pointer adapter HOLD |
| Positive vs blank/zero | distinct states and presence mask | HOLD until descriptor qualified |
| Target edited after preview | stale SHA / approval revoked | specified; future writer only |
| Changed section count or row width | fail closed | yes for NODENAME and ELEMENTS |
| Mutated byte span leaks to neighboring columns | reject non-authorized bytes | future writer / independent verifier |

## 7. Extension without revamping the product

E1 adds one *verified descriptor* at a time, e.g. a native-sourced process case field or the real RIGID pointer field. E2 makes an auditable proposal with provenance. A later code owner may create a narrow `writerAdapter` if (and only if) the existing source-qualified writer supports that operation. A new record creation mode is separate from an in-place fixed-width edit. Avoid general 'copy all fields' or unqualified automatic unit conversion.
