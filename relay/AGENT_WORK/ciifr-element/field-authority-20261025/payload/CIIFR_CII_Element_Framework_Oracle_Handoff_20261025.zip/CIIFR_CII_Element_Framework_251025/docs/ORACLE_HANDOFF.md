# CIIFR — Oracle handoff / recovery checkpoint

**Framework task:** CIIFR-ELEMENT-FOUNDATION-251025 (local working identifier only; not an activated Cycle assignment).  
**Authority/coordination:** Common `oracle-cycles/ciifr/CURRENT.json` rev3 ACTIVE, standalone **for the existing Geometry G1 work**, not this new element-transfer assignment. The configured Oracle chat ID is NOT_CONFIRMED_FOR_THIS_CHAT. Do not change its assignments, issue #166/#169, active G1 repair, or authorization as a side effect of this package.

**Owner outcome now requested:** a reusable CII entity/element/pointer foundation, process/rigid transfer extension concept, architecture explanation, code modules, fixtures, benchmark and understandable engineering decision rationale for future specialists.

**Source precedence:** Owner aim and amendments; native issue #139 and #166; PR #176 (draft NodeName writer); exact original private CII; XCU `AGENTS.md`; pinned Common START_HERE `63bb13d0`; reported historical findings. The original VNext Tab 3 GEOMETRY scope persists until actual Owner amendment.

**Live checked candidate at package composition:** XCU `main` `c823f0c0edbeb315c07fa2911390dc781968146f`; PR #176 DRAFT head `e973af8b249d4770ae766c8554ac71aba2de119c`, UNMERGED; G1 PR #174 separate ongoing reader/writer boundary. Recheck when picking up: hashes and assignments can change.

**Authorship/exposure:** Current Oracle previously authored PR #176 in this chat history. This package's tests and design were also created by the same contributor; **SELF-ASSESSED ONLY**. No independent reviewer PASS, product qualification, private original engineering-write trial, or Owner acceptance asserted.

## Exact scope delivered
- Concept note, complex physical-element/typed-pointer explanation, qualified/held property registry and decision/falsifier ledger.
- Pure Node.js read-only prototype index / directed element locator / property adapters / proposal planner.
- Generated *invented* V14 fixture set and independent negative branches; no private raw CII bytes.
- Native Node tests and synthetic perf microbenchmark; separate read-only local census on Owner private CII.
- No product UI modification, no geometry engine change, no Writer mutation, no VNext tab replacement, no merge/release.

## Evidence classes
**EXECUTED_HERE:** native `node --test tests/framework.test.mjs`; native `node bench/benchmark.mjs`; `indexCii` read-only on private original; hash and count inspection (see evidence JSON).  
**SELF-ASSESSED:** package semantics and synthetic expected outcomes.  
**NOT_RUN:** served Chromium, app integration, v11 original fixture trial, RIGID-pointer-specific real specimen transfer, independently derived case/units mapping, data writer, real TARGET1 output, exact PR #176 mainline CI.  
**UNKNOWN / HOLD:** native original model-proven core PROCESS map, unit and case mapping; RIGID pointer position and owner cardinality; element correspondence across independently numbered models; separate independent reviewer.  

## Fixture custody
- Original private CII stays in Owner's protected custody; package does NOT include it. Local measured file SHA-256 starts `4c9c9546…` and the full hash is in local evidence JSON. Never push it to public GitHub/Common.
- `fixtures/*.CII` are synthetic generated wholly by this package. The public-safe fixture hash manifest travels with the ZIP.
- Local archive and `sandbox:/...` links are LOCAL_ONLY, **not** a cross-chat relay delivery. Before giving bytes to another agent publish the public-safe ZIP in an approved immutable `Common relay/AGENT_WORK/.../payload/` path and a receipt, read back exact commit/blob, then receiver independently measures downloaded bytes/SHA. This package is ready for relay staging, but receipt and recipient verification are NOT_DONE.

## Highest risk and falsifier
Risk: source and target can have similar bytes while physical identity, process case, unit or pointer owner differ. The next tester must independently qualify a real field source and construct a wrong-case source/target fixture that shows the result HOLD rather than a plausible wrong numerical transfer. Do not reuse this author's expected results as a blind oracle.

## ONE EXACT NEXT ACTION
**Authorized specialist, once actually assigned:** inspect original v11/v14 SOURCE/TARGET and converter/native writer field sources; establish/record an independently reviewed physical field map for `ELEMENTS` process conditions and `RIGID` pointer/weight/type, including units and operating-case meaning, then run one positive and one real discriminating negative pair in READ_ONLY mode. Return file/field index positions, fixture provenance, exact hashes, native test commands and a HOLD/PASS decision for that *specific field map*. **No writer, tab repurpose, or merge.**

**Next delivery after that:** consume the source-qualified field registry in this research planner and expose element-property before/after claims in a separate read-only preview, preserving the Geometry tab and node-name functionality.
