# CIIFR CII Entity / Element / Pointer Framework — 25 Oct 2026

**Status:** standalone READ-ONLY proof of architecture. **No Writer or CII export**, no changes to production, no approved source/target mapping, no product UI installation.

## What is here
- `docs/CONCEPT_NOTE.md`: Owner intent, workstream distinction, next two prototypes and tab-placement HOLD.
- `docs/ARCHITECTURE_AND_POINTER_MODEL.md`: original-byte ELEMENTS, NODENAME and pointer semantics, source/target correspondence, process/rigid adapter design.
- `docs/DESIGN_DECISIONS_AND_FALSIFIERS.md`: explicit rationale/alternatives and what might still be wrong (not model private reasoning).
- `docs/ORACLE_HANDOFF.md`: source-bound checkpoint, source and authority, evidence, next single action.
- `src/fixed-cii-index.mjs`: read-only fixed ASCII parser/index for physically qualified V11/V14 subset.
- `src/element-identity.mjs`: pair matching and duplicate/reversed HOLD, no model correspondence authentication.
- `src/property-adapters.mjs`: field registry, READ-QUALIFIED diameter; other process and RIGID fields HOLD.
- `src/transfer-planner.mjs`: read-only evidence ledger; explicitly writerEligible=false.
- `src/synthetic-fixtures.mjs`: invented V14 fixture generator, including node 565 pattern, ambiguous/shared pointers.
- `fixtures/`: public-safe CII examples, mapping CSV and expected count ledger.
- `tests/`: native Node adversarial tests.
- `bench/`: read-only synthetic performance harness.
- `evidence/`: actual synthetic benchmark and sanitized local private-file read-only census (no private raw bytes).

## Execute (Node >= 18; tested Node v22.16.0)

Windows Command Prompt: `RUN_TESTS.cmd` and `RUN_BENCH.cmd`.

Any shell from the package root:
```
node --test tests/framework.test.mjs
node bench/benchmark.mjs
```

Import in another Node script:
```js
import {readFileSync} from 'node:fs';
import {indexCii,nodeNameOccurrences} from './src/fixed-cii-index.mjs';
const original = new Uint8Array(readFileSync('fixtures/synthetic-base.CII'));
const indexed = indexCii(original);
console.log(indexed.elements.length, nodeNameOccurrences(indexed,565));
```

Do not feed this research planner's review results into an engineering writer. Its parser is deliberately a limited, independent reader, not a fully qualified CAESAR II parser. Process and rigid adapters require an actual original-source field map and native negative tests.

## No accidental source disclosure
The ZIP contains no original private model bytes, no original proprietary element records or private raw filenames; only aggregate local measurements and input hashes in `evidence/private_local_inventory.json`. Fixture strings are invented. Common cross-agent relay remains LOCAL_ONLY until an authorized public-safe payload/receipt is posted and recipient byte retrieval verified.
