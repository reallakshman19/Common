@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (echo Node.js 18+ is required.& pause & exit /b 1)
node --test tests\framework.test.mjs
if errorlevel 1 (echo TEST FAIL& pause & exit /b 1)
echo TEST PASS (limited read-only module assertions; not CII writer qualification)
pause
