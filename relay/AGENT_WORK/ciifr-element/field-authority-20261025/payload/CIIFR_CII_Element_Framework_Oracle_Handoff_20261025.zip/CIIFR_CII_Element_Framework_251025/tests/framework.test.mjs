import test from 'node:test';
import assert from 'node:assert/strict';
import {indexCii,nodeNameOccurrences} from '../src/fixed-cii-index.mjs';
import {locateDirected,locateMappedElement} from '../src/element-identity.mjs';
import {PROPERTY_REGISTRY,inspectProperty} from '../src/property-adapters.mjs';
import {planTransfer} from '../src/transfer-planner.mjs';
import {syntheticCii} from '../src/synthetic-fixtures.mjs';
const parse=o=>indexCii(syntheticCii(o));
test('fixed original bytes, 15-row element/53-byte name and zero-pointer node 565',()=>{
  const bytes=syntheticCii(),snapshot=Buffer.from(bytes),p=indexCii(bytes);
  assert.equal(p.version,14);assert.equal(p.elements.length,4);assert.equal(p.nodeNameCount,2);
  assert.equal(p.observations.missingNamePointerElements,2);
  assert.deepEqual(nodeNameOccurrences(p,565).map(x=>x.status),['POINTER_ZERO','POINTER_ZERO']);
  assert.deepEqual(bytes,new Uint8Array(snapshot));
});
test('node 285 has two aliases and each physical name field retains absolute byte span',()=>{
  const p=parse();const occurrences=nodeNameOccurrences(p,285);
  assert.equal(occurrences.length,2);assert.deepEqual(occurrences.map(x=>x.name),['SYN-A','SYN-A']);
  for(const o of occurrences) assert.equal(o.physicalSpan.end-o.physicalSpan.start,o.side==='FROM'?26:25);
});
test('shared name pointer is observed, never assumed to be unique',()=>{
  const p=parse({shared:true});assert.equal(p.observations.sharedNamePointers.length,1);
  assert(nodeNameOccurrences(p,285).every(o=>o.status==='POINTER_SHARED'));
});
test('duplicate directed pair always HOLD, no choose-first behavior',()=>{
  const p=parse({duplicates:true});
  assert.equal(locateDirected(p,280,285).status,'AMBIGUOUS_DUPLICATE_PAIR');
});
test('reversed node pair not silently deemed identical',()=>{
  const p=parse(); assert.equal(locateDirected(p,285,280).status,'NO_MATCH');
});
test('source and target renumbering requires explicit map, still no approved identity',()=>{
  const a=parse(),b=parse();
  const result=locateMappedElement(a,b,{sourceFrom:280,sourceTo:285,targetFrom:560,targetTo:565});
  assert.equal(result.status,'PAIR_LOCATED_NOT_ENGINEERING_IDENTITY');
});
test('process and rigid pointer fields stay on HOLD until independently qualified',()=>{
  const p=parse(),e=p.elements[0];
  for (const prop of ['ELEMENTS.TEMPERATURE_1','ELEMENTS.PRESSURE_1','ELEMENTS.FLUID_DENSITY','RIGID.WEIGHT','RIGID.TYPE'])
    assert.match(inspectProperty(p,e,prop).status,/^HOLD_/);
  assert.equal(PROPERTY_REGISTRY['ELEMENTS.DIAMETER'].qualification,'READ_QUALIFIED');
});
test('source-target diameter discrepancy produces REVIEW_ONLY not writer claim',()=>{
  const a=parse(),b=parse();const bbytes=syntheticCii();
  // Mutate only synthetic buffer's known diameter span, not private or original data.
  const pos=b.elements[0].diameterSpan.start;
  bbytes.set(Buffer.from('        140.0'),pos);
  const target=indexCii(bbytes),result=planTransfer({source:a,target,
    mapping:[{sourceFrom:280,sourceTo:285,targetFrom:280,targetTo:285}],properties:['ELEMENTS.DIAMETER']});
  assert.equal(result.summary.review,1);assert.equal(result.proposals[0].writerAuthority,'NONE');
  assert.equal(result.writerEligible,false);
});
test('units mismatch HOLDs otherwise observed diameter',()=>{
  const a=parse(),b=parse({unitTag:'SYNTHETIC_OTHER_UNITS'});
  const result=planTransfer({source:a,target:b,
    mapping:[{sourceFrom:280,sourceTo:285,targetFrom:280,targetTo:285}],properties:['ELEMENTS.DIAMETER']});
  assert.equal(result.proposals[0].reason,'UNITS_UNVERIFIED_OR_MISMATCH');
});
test('duplicate target mapping and unknown property do not create writer authority',()=>{
  const a=parse(),b=parse();
  const p=planTransfer({source:a,target:b,mapping:[
    {sourceFrom:280,sourceTo:285,targetFrom:280,targetTo:285},
    {sourceFrom:285,sourceTo:290,targetFrom:280,targetTo:285}],properties:['ELEMENTS.DIAMETER','PROCESS.UNKNOWN']});
  assert.equal(p.diagnostics[0].status,'TARGET_ELEMENT_REUSED');
  assert.equal(p.proposals.find(x=>x.property==='PROCESS.UNKNOWN').status,'HOLD');
});
test('missing or malformed pointer blocks parse: no auto-created records',()=>{
  const bytes=syntheticCii();const p=indexCii(bytes);
  const ptr=p.elements[2].cardLines[13].start+67;
  bytes.set(Buffer.from('           77'),ptr);
  assert.throws(()=>indexCii(bytes),/NODENAME_POINTER_OUT_OF_RANGE/);
});
test('unsupported file, corrupted cardinality and malformed row are rejected',()=>{
  const bytes=syntheticCii();const p=indexCii(bytes);
  const bad=new Uint8Array(bytes); bad.set(Buffer.from('           99'),p.names[0].from.start-2);
  // This may damage an unrelated name line but cannot prove cardinality; use control count instead.
  const count=new Uint8Array(bytes); const raw=Buffer.from(count); const start=raw.indexOf(Buffer.from('#$ CONTROL\r\n'))+12;
  count.set(Buffer.from('           77'),start+41);
  assert.throws(()=>indexCii(count),/CARDINALITY_MISMATCH/);
});
test('self-loop endpoint is two physical name slots, not one inferred alias',()=>{
  const bytes=syntheticCii();const p=indexCii(bytes);const start=p.elements[0].cardStart;
  bytes.set(Buffer.from(String(280).padStart(13,' ')),start+15);
  const q=indexCii(bytes);const names=nodeNameOccurrences(q,280);
  assert.equal(names.length,2);assert.deepEqual(names.map(n=>n.side),['FROM','TO']);
});
