# Hand-stated synthetic expectations (not an independent engineering oracle)

- `synthetic-base.CII`: 4 * 15 ELEMENTS physical rows, 2 NODENAME physical records, NODENAME pointers `[1,2,0,0]`; logical 285 has TO + FROM aliases, logical 565 has two `pointer=0` endpoint occurrences.
- `synthetic-shared-pointer.CII`: pointers `[1,1,0,0]`; physical NODENAME record 1 has two element owners, so any name update requires explicit handling.
- `synthetic-duplicate-pair.CII`: directed pair `280→285` appears twice; first-match selection must fail closed.
- `synthetic-named-565.CII`: pointers `[1,2,3,4]`; logical 565 has two physically populated aliases.
- `synthetic-other-units.CII`: same toy element structure but deliberately different UNITS payload; numeric copying must HOLD.

These expectations are derived from the invented fixture definitions, not from a separately sourced native CAESAR II reference. They must not be rebranded as independent acceptance.
