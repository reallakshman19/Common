/** Invented educational data. No source or customer labels/values copied. */
const row=values=>values.map((v,i)=>String(v).padStart(i===0?15:13,' ')).join('');
const named=(a,b)=>'  '+a.padEnd(26,' ')+b.padEnd(25,' ');
const element=(from,to,pointer,diameter='125.0')=>Array.from({length:15},(_,i)=>{
  if(i===0)return row([from,to,100,0,0,diameter]);
  if(i===13)return row([0,0,0,0,0,pointer]);
  return row([0,0,0,0,0,0]);
});
export function syntheticCii({node565=true,shared=false,duplicates=false,
    elementCount=4,unitTag='INVENTED_METRIC',lineEnding='\r\n'}={}){
  if(elementCount<4)throw new Error('AT_LEAST_FOUR_ELEMENTS_REQUIRED');
  const parts=[['280','285',1],['285','290',shared?1:2],['560','565',node565?0:3],['565','570',node565?0:4]];
  for(let i=4;i<elementCount;i++)parts.push([String(10000+i*10),String(10010+i*10),0]);
  if(duplicates)parts[1]=['280','285',shared?1:2];
  const names= node565 ? [named('','SYN-A'),named('SYN-A','')]:
    [named('','SYN-A'),named('SYN-A',''),named('','SYN-B'),named('SYN-B','')];
  const lines=['#$ VERSION',row([5,14,1256]),'#$ CONTROL',
    row([parts.length,0,0,names.length,0,0]),
    '#$ ELEMENTS',...parts.flatMap(p=>element(...p)),
    '#$ NODENAME',...names,'#$ BEND','#$ RIGID','#$ UNITS',unitTag];
  return new Uint8Array(Buffer.from(lines.join(lineEnding)+lineEnding,'ascii'));
}
