/** Read-only SOURCE -> TARGET0 evidence proposals. NEVER produces writer approval. */
import {locateMappedElement} from './element-identity.mjs';
import {inspectProperty,PROPERTY_REGISTRY} from './property-adapters.mjs';
export const PLAN_SCHEMA='CIIFR.ElementEvidencePlan.v1';
export function planTransfer({source,target,mapping,properties}){
  if(!source?.elements||!target?.elements||!Array.isArray(mapping)||!Array.isArray(properties))
    throw new Error('PLAN_INVALID_INPUT');
  const proposals=[],diagnostics=[],usedTarget=new Set();
  for(const [i,row] of mapping.entries()){
    const match=locateMappedElement(source,target,row);
    if(match.status!=='PAIR_LOCATED_NOT_ENGINEERING_IDENTITY'){
      diagnostics.push({row:i+1,status:match.status,source:match.source,target:match.target});continue;
    }
    const targetWitness=match.target.witness;
    if(usedTarget.has(targetWitness)){
      diagnostics.push({row:i+1,status:'TARGET_ELEMENT_REUSED',targetWitness});continue;
    }
    usedTarget.add(targetWitness);
    for(const p of properties){
      const left=inspectProperty(source,match.source,p),right=inspectProperty(target,match.target,p);
      let status='HOLD';let reason='FIELD_NOT_QUALIFIED';
      if(left.status==='OBSERVED_READ_ONLY' && right.status==='OBSERVED_READ_ONLY'){
        if(PROPERTY_REGISTRY[p]?.unitDependency && (!source.unitsPayload || source.unitsPayload!==target.unitsPayload)){
          reason='UNITS_UNVERIFIED_OR_MISMATCH';
        } else if(left.raw===right.raw){status='NO_CHANGE';reason='BYTE_IDENTICAL';}
        else {status='REVIEW_ONLY';reason='FIELD_VALUES_DIFFER_IDENTITY_NOT_PROVED';}
      }else reason=left.status!=='OBSERVED_READ_ONLY'?left.status:right.status;
      proposals.push({row:i+1,property:p,status,reason,
        sourceElementWitness:match.source.witness,targetElementWitness:targetWitness,
        before:right.value??null,proposed:left.value??null,
        targetByteSpan:right.span??null,sourceByteSpan:left.span??null,
        correspondenceAuthority:'EXPLICIT_PAIR_ONLY_UNQUALIFIED',
        writerAuthority:'NONE'});
    }
  }
  return {schema:PLAN_SCHEMA,readOnly:true,writerEligible:false,
    proposals,diagnostics,summary:{rowCount:mapping.length,proposals:proposals.length,
      review:proposals.filter(p=>p.status==='REVIEW_ONLY').length,
      held:proposals.filter(p=>p.status==='HOLD').length,
      unchanged:proposals.filter(p=>p.status==='NO_CHANGE').length}};
}
