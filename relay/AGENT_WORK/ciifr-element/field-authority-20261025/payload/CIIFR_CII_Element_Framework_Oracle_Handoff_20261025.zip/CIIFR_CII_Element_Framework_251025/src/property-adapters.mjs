/** Registry ONLY. Physical offsets must be source-verified before any adapter is qualified. */
export const PROPERTY_REGISTRY=Object.freeze({
  'ELEMENTS.DIAMETER': Object.freeze({section:'ELEMENTS',relation:'DIRECT',
    physical:'element first row, [67,80) (13 bytes)',
    qualification:'READ_QUALIFIED',unitDependency:true}),
  'ELEMENTS.TEMPERATURE_1':Object.freeze({section:'ELEMENTS',relation:'DIRECT',
    qualification:'HOLD_PROCESS_FIELD_SCHEMA_UNVERIFIED',unitDependency:true}),
  'ELEMENTS.PRESSURE_1':Object.freeze({section:'ELEMENTS',relation:'DIRECT',
    qualification:'HOLD_PROCESS_FIELD_SCHEMA_UNVERIFIED',unitDependency:true}),
  'ELEMENTS.FLUID_DENSITY':Object.freeze({section:'ELEMENTS',relation:'DIRECT',
    qualification:'HOLD_PROCESS_FIELD_SCHEMA_UNVERIFIED',unitDependency:true}),
  'RIGID.WEIGHT':Object.freeze({section:'RIGID',relation:'POINTER',
    qualification:'HOLD_RIGID_POINTER_FIELD_MAP_UNVERIFIED',unitDependency:true}),
  'RIGID.TYPE':Object.freeze({section:'RIGID',relation:'POINTER',
    qualification:'HOLD_RIGID_POINTER_FIELD_MAP_UNVERIFIED',unitDependency:false})
});
export function inspectProperty(index,element,propertyId){
  const d=PROPERTY_REGISTRY[propertyId];
  if(!d)return {status:'HOLD_UNKNOWN_PROPERTY',propertyId};
  if(d.qualification!=='READ_QUALIFIED')return {status:d.qualification,propertyId,section:d.section,relation:d.relation};
  if(propertyId==='ELEMENTS.DIAMETER')return {status:'OBSERVED_READ_ONLY',propertyId,
    value:element.diameterSpan.raw.trim(),raw:element.diameterSpan.raw,
    span:{start:element.diameterSpan.start,end:element.diameterSpan.end}};
  return {status:'HOLD_MISSING_ADAPTER',propertyId};
}
