/** Read-only byte-indexed CAESAR II V11/V14 inspection subset; NOT a general parser/writer. */
export const SCHEMA = 'CIIFR.ElementReadIndex.v1';
const error = code => { throw new Error(code); };
function ascii(bytes, begin, end) {
  let s = '';
  for (let i = begin; i < end; i++) {
    if (bytes[i] > 127 || bytes[i] < 32 && bytes[i] !== 9) error('NON_ASCII_RECORD');
    s += String.fromCharCode(bytes[i]);
  }
  return s;
}
export function scanCiiLines(bytes) {
  if (!(bytes instanceof Uint8Array)) error('CII_UINT8ARRAY_REQUIRED');
  const result = []; let start = 0;
  for (let i = 0; i < bytes.length; i++) {
    if (bytes[i] !== 10 && bytes[i] !== 13) continue;
    const term = bytes[i] === 13 && bytes[i + 1] === 10 ? 2 : 1;
    result.push({ start, end: i, next: i + term, text: ascii(bytes, start, i) });
    i += term - 1; start = i + 1;
  }
  if (start < bytes.length) result.push({start,end:bytes.length,next:bytes.length,text:ascii(bytes,start,bytes.length)});
  return result;
}
function marker(str) { return /^\s*#\$\s*(\S.*?)\s*$/i.exec(str)?.[1]?.toUpperCase() || null; }
function integer(str, code) {
  const t=str.trim();
  if (!/^[+\-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][+\-]?\d+)?$/.test(t)) error(code);
  const v=Number(t.replace(/[dD]/g,'E'));
  if (!Number.isSafeInteger(v)) error(code);
  return v;
}
function fixed(line, first, last, code) {
  if (!line || line.end - line.start < last) error(code+'_SHORT');
  return line.text.slice(first,last);
}
export function indexCii(bytes) {
  const lines=scanCiiLines(bytes),sections=new Map(),order=[];
  let current=null;
  for (const line of lines) {
    const m=marker(line.text);
    if(m){if(sections.has(m))error('DUPLICATE_SECTION_'+m);
      current=m;sections.set(m,[]);order.push(m);
    } else if (current && line.text.trim()) sections.get(current).push(line);
  }
  for(const s of ['VERSION','CONTROL','ELEMENTS'])if(!sections.has(s))error('REQUIRED_SECTION_'+s+'_ABSENT');
  if(order[0]!=='VERSION')error('VERSION_NOT_FIRST');
  const header=sections.get('VERSION')[0]?.text?.trim()?.split(/\s+/);
  const version=header && Number(header[1]);
  if(![11,14].includes(version))error('VERSION_UNSUPPORTED');
  const control=sections.get('CONTROL')[0];
  const nodeNameCount=integer(fixed(control,41,54,'CONTROL_NODENAME_COUNT'),'INVALID_NODENAME_COUNT');
  if(nodeNameCount<0)error('NEGATIVE_NODENAME_COUNT');
  const names=sections.get('NODENAME')||[];
  if(names.length!==nodeNameCount)error('NODENAME_CARDINALITY_MISMATCH');
  const erows=sections.get('ELEMENTS');
  if(erows.length%15!==0)error('ELEMENT_NOT_15_LINES');
  const elements=[], pointerOwners=new Map(), byNode=new Map(), byDirectedPair=new Map();
  for(let i=0;i<erows.length;i+=15){
    const head=erows[i],point=erows[i+13];
    const from=integer(fixed(head,0,15,'ELEMENT_FROM'),'ELEMENT_FROM_INVALID');
    const to=integer(fixed(head,15,28,'ELEMENT_TO'),'ELEMENT_TO_INVALID');
    const namePtr=integer(fixed(point,67,80,'ELEMENT_NODENAME_POINTER'),'NODENAME_POINTER_INVALID');
    if(namePtr<0||namePtr>nodeNameCount)error('NODENAME_POINTER_OUT_OF_RANGE');
    const entry={ordinal:i/15,index:i/15,from,to,namePtr,
      witness:`${i/15}:${from}:${to}`,cardStart:head.start,
      diameterSpan:{start:head.start+67,end:head.start+80,
        raw:fixed(head,67,80,'ELEMENT_DIAMETER')},
      cardLines:erows.slice(i,i+15)};
    elements.push(entry);
    if(namePtr){const owners=pointerOwners.get(namePtr)||[];owners.push(entry.index);pointerOwners.set(namePtr,owners);}
    for (const n of new Set([from,to])) {const refs=byNode.get(n)||[];refs.push(entry);byNode.set(n,refs);}
    const id=`${from}->${to}`;const matches=byDirectedPair.get(id)||[];matches.push(entry);byDirectedPair.set(id,matches);
  }
  const nameIndex=names.map((line,i)=>({pointer:i+1,owners:pointerOwners.get(i+1)||[],
    from:{start:line.start+2,end:line.start+28,raw:fixed(line,2,28,'NODENAME_FROM')},
    to:{start:line.start+28,end:line.start+53,raw:fixed(line,28,53,'NODENAME_TO')}}));
  return {schema:SCHEMA,version,sourceByteLength:bytes.length,lineCount:lines.length,
    order, sectionCounts:Object.fromEntries([...sections].map(([k,v])=>[k,v.length])),
    nodeNameCount,rigidRecordCount:sections.get('RIGID')?.length||0,
    elements,names:nameIndex,pointerOwners,byNode,byDirectedPair,
    unitsPayload:(sections.get('UNITS')||[]).map(x=>x.text).join('\n'),
    // RIGID row pointer location is intentionally NOT inferred from numeric similarity.
    pointerMapQualification:{NODENAME:'READ_QUALIFIED_V11_V14',RIGID:'UNQUALIFIED_FIELD_MAP_REQUIRED'},
    observations:{missingNamePointerElements:elements.filter(e=>e.namePtr===0).length,
      sharedNamePointers:[...pointerOwners].filter(([,owners])=>owners.length>1).map(([pointer,owners])=>({pointer,owners})),
      duplicateDirectedPairs:[...byDirectedPair].filter(([,v])=>v.length>1).map(([pair,v])=>({pair,count:v.length}))}};
}
export function nodeNameOccurrences(index,node){
  const hits=index.byNode.get(node)||[];
  return hits.flatMap(e=>['FROM','TO'].filter(side=>e[side.toLowerCase()]===node).map(side=>{
    const name=e.namePtr?index.names[e.namePtr-1]?.[side.toLowerCase()]:null;
    return {elementWitness:e.witness,elementIndex:e.index,side,pointer:e.namePtr,
      status:!e.namePtr?'POINTER_ZERO':index.pointerOwners.get(e.namePtr)?.length!==1?'POINTER_SHARED':'POINTER_UNIQUE',
      name:name?.raw?.trim()||null,physicalSpan:name?{start:name.start,end:name.end}:null};
  }));
}
