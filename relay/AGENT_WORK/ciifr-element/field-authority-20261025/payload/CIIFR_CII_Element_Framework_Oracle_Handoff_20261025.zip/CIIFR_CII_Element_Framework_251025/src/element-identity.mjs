/** Element lookup by exact ordered node pair, independently of names or neighboring values. */
const bad=code=>{throw new Error(code)};
function int(x){const s=String(x); if(!/^(0|[1-9]\d*)$/.test(s)||!Number.isSafeInteger(Number(s)))bad('ELEMENT_NODE_NUMBER_INVALID');return Number(s);}
export function locateDirected(index,from,to){
  const f=int(from),t=int(to);const hits=index.byDirectedPair.get(`${f}->${t}`)||[];
  if(!hits.length)return {status:'NO_MATCH',witnesses:[]};
  if(hits.length!==1)return {status:'AMBIGUOUS_DUPLICATE_PAIR',witnesses:hits.map(x=>x.witness)};
  return {status:'CANDIDATE_UNVERIFIED_IDENTITY',witnesses:[hits[0].witness],element:hits[0]};
}
export function locateMappedElement(source,target,row){
  const sourceHit=locateDirected(source,row.sourceFrom,row.sourceTo);
  const targetHit=locateDirected(target,row.targetFrom,row.targetTo);
  if(!sourceHit.element || !targetHit.element)return {status:'HOLD_MATCH',source:sourceHit.status,target:targetHit.status};
  return {status:'PAIR_LOCATED_NOT_ENGINEERING_IDENTITY',
    source:sourceHit.element,target:targetHit.element,
    evidence:{mapping:row.provenance||'EXPLICIT_ROW_UNREVIEWED',
      sourceWitness:sourceHit.element.witness,targetWitness:targetHit.element.witness,
      reversed:sourceHit.element.from===targetHit.element.to && sourceHit.element.to===targetHit.element.from}};
}
