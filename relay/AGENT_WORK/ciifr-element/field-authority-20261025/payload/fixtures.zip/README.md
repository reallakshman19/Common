# CIIFR CII research fixtures — reproducing the benchmark

Open **BENCHMARK_REPORT.md** (or **BENCHMARK_REPORT.docx**) first. It records what was measured, exactly how, and the unproven boundaries.

This ZIP contains five public-safe, fully invented CII fixtures, two mapping CSVs, the required read-only JS modules, Node tests, the exact benchmark script, and original + rechecked JSON measurements. All relative import paths are preserved.

## Quick start

Requirements: Node.js 18+; tested 22.16.0.

1. Extract the entire ZIP, preserving folders.
2. Run `node --test tests/framework.test.mjs`.
3. Run `node bench/benchmark.mjs`.
4. Compare the output to `evidence/benchmark_original_20261025.json` and `evidence/benchmark_recheck_20261025.json`; durations need not match exactly.

On Windows, use `RUN_TESTS.cmd` and `RUN_BENCH.cmd`.

All modules are READ_ONLY. No process/rigid writer authority or TARGET1 output is implemented. No private original CII bytes are included. Fixture synthetic expected results are implementation-coupled; independent engineering acceptance is NOT_RUN.
