# CIIFR — Fixture Pack and Benchmark Evidence Report

**Date:** 25 October 2026  
**Scope:** CII element, node, and NODENAME-pointer inspection; source/target **read-only** property proposal foundation  
**Evidence class:** SELF-ASSESSED local native measurements, **not** independent engineering qualification  
**Implementation:** Node.js ES modules in `src/`, test file `tests/framework.test.mjs`, benchmark `bench/benchmark.mjs`.

## 1. What benchmark did we achieve?

The existing research framework successfully indexed synthetic CII-like V14 inputs of **353, 1,000 and 3,000 ELEMENTS records** without creating TARGET1 or modifying its input. The source-indexing routine read physical fixed-width record boundaries and created element, node, name-pointer and directed-pair indexes. The synthetic process and rigid adapters remained on **HOLD**, which is the intended safety outcome until their physical field maps are established.

### Reproducible results — two local executions

Both runs used Node.js `v22.16.0` on Linux and the same benchmark script. The timing is wall-clock elapsed milliseconds from `performance.now()`. Figures are illustrative machine-dependent microbenchmarks, not a throughput SLA.

| Synthetic elements | Generated input bytes | Original median parse (ms) | Recheck median parse (ms) | Original slowest-of-three (ms) | Recheck slowest-of-three (ms) |
|---:|---:|---:|---:|---:|---:|
| 353 | 434,521 | 23.968 | 25.080 | 30.210 | 33.966 |
| 1,000 | 1,230,331 | 90.357 | 83.369 | 125.055 | 129.836 |
| 3,000 | 3,690,331 | 363.914 | 295.672 | 426.700 | 345.626 |

**Interpretation:** The check shows indexing is runnable on multi-thousand-element synthetic inputs. It does **not** establish linear scalability, browser responsiveness, memory safety on arbitrarily large files, correctness of all CAESAR II formats, or engineering-write readiness. The two runs differ because timing is sensitive to CPU scheduling, garbage collection and warm-up.

### One-row read-only planner measurement

Each sample also executed one `planTransfer()` call using the **first element as an explicit source/target pair** and requesting `ELEMENTS.DIAMETER`, `ELEMENTS.PRESSURE_1` and `RIGID.WEIGHT`. Diameter is READ-QUALIFIED for inspection, while pressure and rigid weight are intentionally held. The measured one-row plan time is **not** a whole-model proposal time, and it must not be interpreted as a writer duration.

| Elements | Original one-row planner (ms) | Recheck one-row planner (ms) | Writer eligible? |
|---:|---:|---:|---|
| 353 | 0.720 | 0.959 | No (`writerEligible=false`) |
| 1,000 | 0.172 | 0.131 | No (`writerEligible=false`) |
| 3,000 | 0.385 | 0.369 | No (`writerEligible=false`) |

## 2. How was the benchmark performed?

1. The script `bench/benchmark.mjs` calls `syntheticCii({elementCount:n})` for `n = 353, 1000, 3000`. These are **invented** CII-shaped records, not proprietary model data; the generator is `src/synthetic-fixtures.mjs`.
2. For each generated file, it calls `indexCii(input)` from `src/fixed-cii-index.mjs`. The reader scans original bytes for line offsets, recognizes section markers, groups ELEMENTS in 15-line blocks, extracts the directed FROM/TO node pair, reads NODENAME pointers, and indexes directed pairs plus NODENAME record ownership. It does not serialize a CII output.
3. The script runs one **untimed warm-up** followed by exactly **three timed passes** of `indexCii` for that size using Node's `performance.now()`.
4. The reported median is the middle of the three measured pass durations. The field named `parseP95SampleMs` is obtained by the script's sample quantile function and, with only three data points, is effectively the **maximum** observed parse time. It is **not a statistically valid P95**.
5. It indexes the same synthetic bytes for a SOURCE, makes a one-row explicit source-to-target element mapping, and times a single `planTransfer()` call covering three requested property identities. Planner outcome is read-only and never writer eligible.
6. The script writes the JSON results to stdout. Saved results are in `evidence/benchmark_original_20261025.json` and `evidence/benchmark_recheck_20261025.json`. The recheck was executed afresh for this fixture ZIP.
7. The test suite uses Node's built-in `node:test` and `assert/strict`; the recheck produced **13 PASS, 0 FAIL**. It verifies the synthetic indexing and deliberate holds, not an independently established CAESAR II writer.

### Reproduce from the extracted ZIP

**Prerequisite:** Node.js 18 or newer. From the package root:

```powershell
node --version
node --test tests/framework.test.mjs
node bench/benchmark.mjs
```

On Windows you may instead double-click `RUN_TESTS.cmd` and `RUN_BENCH.cmd` after extracting the entire ZIP. Preserve the `src/`, `bench/`, `tests/` folder relationships because imports are relative. Results will differ by machine, runtime and background workload. For a more reliable P95, use many more iterations and a controlled environment; this kit makes no P95 performance claim.

## 3. Which fixtures are included, and what do they prove?

| Fixture | Invented structural scenario | Expected test / safety outcome |
|---|---|---|
| `synthetic-base.CII` | Four 15-row elements; NODENAME pointers [1,2,0,0] | Node 285 has two physical name aliases; node 565 appears twice with zero pointers |
| `synthetic-shared-pointer.CII` | First two elements reference pointer 1 | Shared-pointer ownership is identified; do not treat it as unique |
| `synthetic-duplicate-pair.CII` | Repeated directed element pair 280->285 | Pair matching reports AMBIGUOUS_DUPLICATE_PAIR; no choose-first |
| `synthetic-named-565.CII` | Missing-name case replaced with pointers [1,2,3,4] | Read-only index recognizes named occurrences; this is **not** a writer-created TARGET1 proof |
| `synthetic-other-units.CII` | Deliberately different invented UNITS section payload | Unit mismatch forces HOLD instead of copying numerical fields |

Two small mapping CSVs are also included. `EXPECTED_STRUCTURE.md` records the synthetic assumptions. These fixture expectations are derived from the same invented generator used by the tests, so they are **implementation-coupled**, not an independently supplied engineering golden oracle.

## 4. Original Owner file — separate read-only observation

The earlier original CII was inspected locally and only aggregate results are retained. It is **not bundled** and was not used as a writer proof.

| Observed item | Recorded value |
|---|---:|
| File size | 612,613 bytes
| SHA-256 identity | `4c9c9546bd9dbd5d0d2028fbd8cb55652747c2b252ab4f05254062994118182e` |
| CII version | 14 |
| Elements indexed | 353 |
| NODENAME records | 258 |
| RIGID records | 38 |
| Elements with zero NODENAME pointer | 95 |
| Pointer sharing recorded | 0 |
| Read-only parse observation | 70.322 ms (one recorded run, not a median) |

Node **565** appears in original ELEMENTS indexes 112 and 113 (0-based): as TO for one element and FROM for the next. Both NODENAME pointers are `0`. This validates the **input condition**, not the success of appending records or creating a correct TARGET1. The source file remains in Owner custody; `evidence/private_local_inventory.json` contains the sanitized inventory and excludes raw model bytes.

## 5. What tests passed, and what remains unproven?

**EXECUTED HERE (local recheck):** `node --test tests/framework.test.mjs`, Node v22.16.0, **13 tests, 13 pass, 0 fail**, with stdout in `evidence/native_tests_recheck_20261025.txt`. Covered scenarios: physical field spans, zero pointers, alias occurrence count, shared pointers, duplicate pairs, reverse direction, explicit source-target mapping, process/rigid HOLD, diameter difference in read-only mode, units mismatch, reused TARGET mapping, malformed pointers/cardinality and a self-loop case.

**NOT_RUN / NOT PROVEN:** independent original-data engineering oracle, real Chromium UI, app/PR #176 integration, RIGID pointer identity mapping, process pressure/temperature slot semantics, load-case equivalence, complete unit conversion, new record writer, TARGET1 export and byte-by-byte unrelated-field protection. The partial CII reader is not qualified for arbitrary dialects or complex native CII feature families.

### Important falsifier for the next specialist

An element pair with matching FROM/TO labels can represent a different engineering element between source and target; matching node numbers alone does not prove model correspondence. A plausible but wrong output could copy a process value from an unrelated element. Next work must qualify the original field layout, source/target element correspondence, case/units semantics and RIGID auxiliary-pointer ownership independently, including wrong-case tests that force HOLD.

## 6. Boundaries and custody

- **Read-only fixtures and code only.** The included framework neither writes nor exports a changed CII.
- No private original CII bytes or protected attachments are included. Only invented fixtures and a sanitized prior-file inventory are carried.
- GitHub PR #176 (Nodal NodeName transfer) is a **separate draft product candidate**, not the measured code inside this ZIP.
- The original VNext work order specifies Tab 3 for GEOMETRY; any Element Based Transfer tab assignment or scope change requires an explicit Owner amendment.
- This ZIP is a local handoff. Other agents must obtain bytes through an authorized durable Common relay and independently verify the ZIP SHA-256; a `sandbox:` link alone is not verified cross-chat delivery.

**Single next engineering step:** independently qualify a source-backed physical field map for process data and the RIGID pointer/record pair, with one positive and one genuine negative source/target fixture before any writer authority is considered.
