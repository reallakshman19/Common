const fs = require('node:fs');
const path = require('node:path');
const {chromium} = require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/playwright');
(async () => {
  const result = {scope:'PINNED_SCENE_PARSER_ONLY', originalBrowserReportCaptured:false, cases:[]};
  let browser;
  try {
    browser = await chromium.launch({headless:true, args:['--no-sandbox']});
    const page = await browser.newPage();
    const source = fs.readFileSync('reference/tabs/topology-workspace/occurrence-scene.mjs','utf8')
      .replace('export { escapeValue };','').replaceAll('export function ','function ');
    await page.addScriptTag({content:source + '\nwindow.parseOccurrenceScene=parseOccurrenceScene;'});
    for (const label of ['valid-original','F1-foreign-root','F2-foreign-namespace','F3-mixed-child-namespace']) {
      const xml=fs.readFileSync(path.join('output',label+'.xml'),'utf8');
      result.cases.push(await page.evaluate(({label,xml})=>{
        try {const s=window.parseOccurrenceScene(xml,'harness-source-sha');return {case:label,accepted:true,nodeCount:s.records.length};}
        catch(e){return {case:label,accepted:false,error:String(e)};}
      },{label,xml}));
    }
    result.executed=true;
    result.browserVersion=browser.version();
  } catch(e) {result.executed=false;result.environmentError=String(e);}
  finally {if(browser)await browser.close();}
  fs.writeFileSync('output/scene-admission-negatives.json',JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
})();
