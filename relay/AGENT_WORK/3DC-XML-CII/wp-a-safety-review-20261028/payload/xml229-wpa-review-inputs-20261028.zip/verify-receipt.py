"""Check material identities only; never authenticate a reviewer or engineering PASS."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--root',type=Path,default=Path('.'))
p.add_argument('--source',type=Path)
p.add_argument('--output',type=Path)
a=p.parse_args()
root=a.root.resolve()
manifest=json.loads((root/'SHA256SUMS.json').read_text())
checks=[]
for name,want in manifest.items():
    f=(root/name).resolve()
    if not f.is_relative_to(root):
        raise SystemExit('Manifest path escapes packet')
    actual=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None
    checks.append({'path':name,'expected':want,'actual':actual,'matches':actual==want})
source=None
if a.source:
    data=a.source.read_bytes()
    source={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    source['matches']=source['bytes']==144471 and source['sha256']=='feee5a5a6399207337e63bc56c8afb001fe37ab30c6a7a9283333ec60f6eea38'
ok=all(c['matches'] for c in checks) and (source is None or source['matches'])
result={'status':'PASS' if ok else 'FAIL','scope':'MATERIAL_IDENTITY_ONLY',
        'reviewerIdentityAuthenticated':False,'engineeringVerdict':'NOT_ASSESSED',
        'source':source,'members':checks}
if a.output:
    a.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'members':len(checks),
                  'sourceChecked':source is not None,'engineeringVerdict':'NOT_ASSESSED'}))
sys.exit(0 if ok else 1)
