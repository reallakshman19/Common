# Oracle continuation — safety evidence and successor design

**28 October 2026 · READ_ONLY · SELF_ASSESSED · ENGINEERING HOLD**

The continuation produced a new full-transaction preservation counterexample and a concrete WP-B design draft. It did not appoint a reviewer, edit product code, change the protected PR, or recover the historical browser report.

## Evidence observed in this session

- Fresh native-JS selection plus pinned Python transaction replay: 210 findings, 66 eligible, 45 initially selected, 40 applied, 26 excluded, nine checks pass, exact historical output digest matches.
- Applied action breakdown: 32 ALIAS_COINCIDENT_NODE, seven CONTRACT_PRESERVE_OWNER, one SAFE_DROP_PIPE_GEOMETRY. These produce 48 NodeNumber aliases and one record removal. All parsed element/attribute/text changes are accounted for by those operations; comparison ignores formatting whitespace, comments and processing instructions. This is structural accounting, not engineering/connectivity proof.
- Existing transaction lineage builds successfully: 216 source occurrences -> 215 retained, 48 changed retained and one removed. Existing lineage and selected-finding reanalysis were retained, not described as absent.
- New original-source target ACT-000194 removes B3:N1600:S2 against B3:N1610:S3, despite nonempty ComponentRefNo and model semantics=True. Its original reference also survives at B3:N1590:S1. An unsafe original repair is not established by this fact alone.
- A single-field synthetic unique-reference variant commits and loses that reference while all nine checks pass. Empty-reference positive and named-record rejection controls discriminate the mechanism. Original ACT-000030 still rejects on NodeName. These are actual full transactions, not only direct guard calls.
- Python admission accepts a foreign RichInput wrapper, wrong document namespace and a wrong-namespace consumed NodeNumber field. These are failures of the proposed strict admission requirement. UI source weakness is inspected, but runtime UI negatives are NOT_RUN because no local Chromium executable was available. No browser download or policy bypass was attempted.

## Key files

| File | Purpose |
|---|---|
| WP-B-design-contract.md | Reviewable admission/revision/case contract and future test matrix |
| output/summary.json | Source/output identities and fresh replay totals |
| output/applied-40-source-audit.json | Every applied action and operation with source/owner witnesses |
| output/excluded-source-ledger.json | All 26 exclusions, source fields and unresolved disposition |
| output/full-transaction-controls.json | Five complete transaction controls, predictions and receipts |
| output/component-ref-full-transaction-falsifier.json | Earlier ACT-000030 counterfactual with two vetoes removed |
| output/python-admission-negatives.json | Executed authoritative-parser admission results |
| output/scene-admission-negatives.json | Explicit UI runtime NOT_RUN evidence |
| output/existing-source-lineage.json | Existing pinned implementation's occurrence lineage |
| reference/git-blob-manifest.json | Git blob SHAs for all 13 pinned code files |
| investigate.py / falsify-removal.py | Reproducible public-source investigation scripts |

## Reproduce

From the extracted package root, run `python investigate.py`, then `python falsify-removal.py`. Python standard library and Node are sufficient. The first script calls the unmodified pinned native-JS planner. The source XML is public, pinned and SHA-verified; no user-private XML is included. Generated invalid XML variants are synthetic test inputs, not authorized engineering revisions. The optional `probe-scene.cjs` needs Playwright plus a locally installed Chromium; its result in this session is NOT_RUN.

The 13 reference code blobs were verified against Git object IDs. A UTF-8 connector transport discrepancy in the unused workspace controller copy was detected and corrected by fetching exact base64 bytes before final packaging; the executed Python modules and JS planner matched throughout.

## Validation and qualification

| Check | Status | Observation | Oracle |
|---|---|---|---|
| Exact source/code custody | PASS | Byte/hash execution | AUTHORITATIVE_REFERENCE for identity only |
| Historical count/output reproduction | PASS | Local execution | IMPLEMENTATION_COUPLED |
| 40-action structural accounting | PASS | Local execution | IMPLEMENTATION_COUPLED |
| Unique ComponentRefNo preservation | FAIL | Full synthetic transaction loses ref, nine checks pass | SELF_ASSESSED requirement counterexample |
| NodeName negative controls | PASS | Full transaction rejection | IMPLEMENTATION_COUPLED |
| Strict Python namespace/root admission | FAIL | Local execution | SELF_ASSESSED proposed-profile expectation |
| UI negative matrix | NOT_RUN | Browser executable unavailable | NONE |
| Independent engineering review | NOT_RUN | Reviewer unappointed | NONE |
| Manual S1 continuity / connectivity proof | NOT_RUN | Successor work only | NONE |

Observed failures pre-exist this investigation. Guard/model/parser blobs match the protected candidate. Preview action IDs remain preview-scoped; no protected-candidate plan replay or source-mutation authorization is implied.

## Recovery state and next action

WORK_INTENT=INVESTIGATE; MUTATION_AUTHORITY=READ_ONLY; CRITICALITY=ENGINEERING_CRITICAL. Recovery is complete for these evidence files; protected-PR implementation takeover qualification and repository-wide writer coordination were not performed. No implementation authority is claimed.

WP-A ledger identity is accepted for continuation. Engineering disposition remains open. WP-B design preparation is complete as a draft; WP-B code is not started. The next bounded gate is an eligible non-author assessment of reference-bearing deletion, all 26 exclusions, and the remaining applied actions. The reviewer must establish their own expectation provenance and disclose authorship/exposure. A Common relay is required if this package is transferred to another agent; no such transfer/dispatch occurred here.

Protected PR #346 was freshly observed open/draft at cba348152faa9c2077d5c91a5f85b4b81d2e8e25 before evidence return. No code, original model/XML, branch, deployment, issue state, protected review or merge state was changed by this read-only slice. Oracle issue #1 is the native return destination.
