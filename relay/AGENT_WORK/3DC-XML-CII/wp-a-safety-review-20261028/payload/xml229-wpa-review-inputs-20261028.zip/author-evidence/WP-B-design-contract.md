# WP-B design preparation — strict admission and revision-aware engineering cases

**28 October 2026 · DESIGN DRAFT · IMPLEMENTATION NOT STARTED**

This design implements the direction accepted in Oracle issue #1's handover addendum. It is a reviewable successor contract, not an activated work pack, engineering acceptance, or permission to change protected PR #346. The next qualification remains non-author assessment of WP-A safety, now including ACT-000194.

## 1. Source basis and boundaries

| Item | Pinned basis |
|---|---|
| Preview | `1b9804b21aacd14e12a884f98b5958b9441a9cc2` |
| Protected PR #346 | Draft/HOLD, `cba348152faa9c2077d5c91a5f85b4b81d2e8e25` |
| S0 raw UTF-8 source | 144,471 bytes; SHA-256 `feee5a5a6399207337e63bc56c8afb001fe37ab30c6a7a9283333ec60f6eea38` |
| Replayed 40-action copy | SHA-256 `6e76322a640fb26f34effeba9e203a6dd5347ebb02f90be8366dbf13d9b02567` |
| WP-A ledger basis | Owner-directed replay/native-JS equivalence, issue comment 6464103203 |

The pinned Python parser, transaction and models are byte-identical to their protected counterparts. The occurrence-scene parser also matches both protected root and docs copies. The preview planner/resolver differs from the protected candidate; preview action IDs are not transferable.

The scope is admission, revision and case continuity. CAD design authority, verified network connectivity, native CII, Weight, Final, release and merge authority stay at their existing boundaries.

## 2. Current behavior to retain and extend

`workspace-app.mjs::load/analyze/runFix` already fences asynchronous results by epoch and source SHA. The Python transaction already rebuilds topology and checks selected-finding resolution. `lineage.py::build_topofix_source_lineage` already maps original occurrences through its explicit transaction operations; its exact replay verifier supports a fresh pre-Final basis. These mechanisms must be reused where applicable.

The missing capability is persistent engineering case reconciliation across externally repaired source revisions. Existing transaction lineage does not establish authoritative equivalence for independently renumbered, inserted, deleted or edited CAD exports. Neither a retained component reference nor a coincident position alone establishes that equivalence.

## 3. Admission contract

Admit a source before presenting it as PSI116 or generating an actionable plan. Use a versioned admission profile with the same shared fixtures at every entrance. The authoritative parser must enforce its profile independently of the UI.

For the current reference profile, the observed root is `{http://aveva.com/pipeStress116.xsd}PipeStressExport`. This is an observed supported-source signature, not a claim that the complete official PSI116 schema has been qualified. Any additional supported schema/version needs an explicit profile and authentic positive fixture; do not create a fallback based only on local tag names.

| Requirement | Acceptance behavior |
|---|---|
| Root identity | Require the admitted expanded name at the document root; reject a foreign wrapper containing an otherwise valid export. |
| Namespace | Require the approved namespace on consumed elements. Prefix spelling may vary; namespace URI may not. |
| Structure | Consume Branch, Node and scalar fields only at profile-defined locations; reject ambiguous duplicate consumed fields and misleading nested lookalikes. |
| Extensions | Preserve permitted extensions explicitly; foreign elements must not masquerade as consumed fields by sharing a local name. |
| Units and values | Validate profile-required unit declarations and numeric input. Unknown units or invalid required values do not silently become defaults. Exact supported unit set needs engineering confirmation. |
| Source identity | Keep raw-byte SHA separate from engine UTF-8 text SHA when decoding changes bytes. Do not hash a normalized surrogate and label it the original. |
| Rejection | No scene presented as admitted PSI116, no actionable findings/plan, no fix transaction/export from rejected input. Retain a clear rejection reason. |

Enforcement locations: root/docs `tabs/topology-workspace/occurrence-scene.mjs`, workspace load and engine invocation boundaries, `parser.py::read_psi116_xml`, resolver/CLI entry, transaction entry (including supplied ResolutionResult provenance), and lineage/pre-Final reimport. Reusing a parsed object must not bypass source/profile binding. Inventory other callers before implementation rather than assuming this list is exhaustive.

Current executed Python negatives all remain open: foreign `RichInput` wrapper, foreign namespace, and a foreign-namespace `NodeNumber` are accepted and produce 216 occurrences. UI source inspection has the same local-name weakness. This session could not execute the UI negative matrix because a local Chromium executable was unavailable; that result is NOT_RUN.

## 4. Revision and analysis identity

| Proposed entity | Required identity and custody |
|---|---|
| Source revision | Persistent revision ID, immutable raw SHA/size, engine text SHA, parent revision(s), source owner/mode, import timestamp, admission profile/version, units and authoritative design reference. |
| Analysis run | Source revision, source hashes, code commit, rule/config digest, admission profile, analysis/run ID and asynchronous generation token. |
| Finding/action evidence | Analysis-run ID plus the original finding/action ID and revision-scoped occurrence keys. |
| Engineering case | Opaque persistent case ID, engineering question, linked evidence over revisions, disposition history, current status, authority and closure evidence. |

NodeNumber, source ordinal and `B#:N#:S#` are evidence locators within a revision. They are not persistent identities. The same action number under two runs does not establish the same action.

A byte-identical reimport can refer to the same immutable source revision while still creating a new analysis run if code/config/profile changes. Every such change invalidates actionable plan selections and receipts bound to the older run. Stale asynchronous callbacks must be rejected using the full current binding, not only a matching action string.

New source bytes create a new immutable revision. Selecting that revision clears active S0 plan selections and pending mutations. Historical S0 evidence remains accessible in its own revision context.

## 5. Persistent case record and reconciliation

Minimum proposed record: `case_id`, engineering question/rule family, source-revision/run links, all original findings/actions, occurrence references and full relevant source fields, component/branch context, geometry as supporting evidence, relation records, authority/design reference, proposed/adopted disposition, append-only history, next required revision/reanalysis, and explicit closure/regression evidence.

Occurrence mappings record from/to revisions and locators, evidence provenance, mapping method, confidence and ambiguity, authoritative approver where needed, and mapped/removed/inserted/unmapped status. Avoid an uncalibrated numeric confidence implying authority.

Mapping sources have different limits:

1. Existing deterministic transaction-operation lineage can establish what the exact automatic copy changed. Its receipt does not approve the engineering correctness of those operations.
2. An authoritative CAD/export change manifest or authorized XML patch custody record can supply external repair lineage.
3. References, branch context, geometry and field similarity can suggest correspondence. Conflicting or many-to-many candidates require explicit resolution; heuristics alone cannot close a case.

Cases may split or consolidate through explicit case relations while preserving history. Counts of findings, actions and engineering cases remain distinct. The 17 shared-occurrence exclusions establish conflict evidence; they do not establish mutually exclusive alternatives, prerequisite direction or redundancy after repair.

| Case status | Evidence required |
|---|---|
| UNRESOLVED | Case remains open, including a rejected or excluded proposal. |
| UNVERIFIABLE | Missing/ambiguous lineage, required source, authority or verification evidence. |
| REOPENED | A previously resolved/approved case fails the required later check or reappears. |
| APPROVED_AS_DESIGNED | Qualified authority and design reference approve the intentional condition; preserve it visibly as an exception. |
| VERIFIED_RESOLVED | Authoritative lineage, fresh full analysis, case-specific proof and appropriate review establish repair without relevant regression. |

A disappearing finding, reduced count, successful transaction, matched output digest or passed nine-check validation is insufficient to promote a case to VERIFIED_RESOLVED.

## 6. Manual repair and automatic-copy lifecycle

Investigate S0 -> record the authorized repair/preserve decision -> repair the upstream model, or explicitly authorized XML -> capture immutable S1 and custody -> strict admission -> fresh full analysis -> reconcile original/outstanding/new/regressed cases -> qualified disposition.

Where CAD owns design, downloading a corrected XML copy does not update that model. The ledger must retain whether S1 is an exported model revision, an authorized XML patch, or merely a provisional automatic copy.

For the current replay, existing lineage accounts for 216 S0 occurrences, 215 retained output occurrences, 48 changed retained occurrences and one removed pipe occurrence. It is not evidence of a completed manual-repair cycle or of all 40 engineering cases closing.

## 7. Safety finding that precedes implementation

ACT-000194 removes `B3:N1600:S2` (PIPE) against `B3:N1610:S3` (ELBO). The removed record has a nonempty ComponentRefNo and the semantic model returns true. The current removal guard nevertheless returns authority `PLAIN_PIPE_WITHOUT_ENGINEERING_SEMANTICS`. The same reference survives on `B3:N1590:S1`; an incorrect original repair is therefore not established solely by losing that record.

The independent question is whether any reference-bearing endpoint can be removed, under what design authority, and with what preserved source meaning. A synthetic single-field unique-reference variant commits the deletion, loses the unique reference, and passes nine checks. That is a full-transaction preservation counterexample, stronger than the prior narrow-predicate test. A NodeName control rejects correctly.

Proposed bounded repair requirement for review: fail closed on nonempty ComponentRefNo unless a separately justified, source-qualified preservation exception exists. Planner coalescing, UI eligibility and the transaction guard must agree; the guard is authoritative and cannot rely on UI screening. Preserve existing NodeName, restraint, rigid, weight, geometry and property vetoes. Do not weaken checks to restore the old 40-action count. The expected post-fix count/hash must be recomputed and separately reviewed; the old copy remains historical evidence.

No implementation choice or engineering exception is approved by this design draft.

## 8. Qualification matrix for future WP-B implementation

| Control | Required expected result | Current session |
|---|---|---|
| Exact authentic S0 | Admit under explicit profile; preserve both identities | Python accepts; UI runtime NOT_RUN |
| F1 foreign wrapper | Reject at UI and authoritative entry | Python accepts: requirement FAIL |
| F2 foreign namespace | Reject at UI and authoritative entry | Python accepts: requirement FAIL |
| F3 foreign namespace on consumed field | Reject masquerading field | Python accepts: requirement FAIL |
| Namespace-prefix-only change | Same profile acceptance; different raw SHA if bytes differ | Proposed, NOT_RUN |
| Renumbered S1 | Fresh action IDs; no S0 selection replay; case persists only with supported mapping | Proposed, NOT_RUN |
| Inserted node before witness | Shifted ordinal cannot silently inherit old identity | Proposed, NOT_RUN |
| Duplicate reference / coincident separate systems | Ambiguous mapping stays UNVERIFIABLE | Proposed, NOT_RUN |
| New source or config during analysis/fix | Reject stale result and pending action selection | Proposed, NOT_RUN |
| Finding disappears without repair/authority | No automatic closure | Proposed, NOT_RUN |
| Full unique-reference transaction | Preserve/reject meaningful reference unless approved exception | Current implementation deletes; requirement FAIL |
| Authorized repair with changed identity | Full S1 reanalysis and explicit case proof before closure | WP-C, NOT_RUN |

Expectations must be independently qualified. This package's executions are self-assessed implementation-coupled evidence. An eligible non-author reviewer remains unappointed. Implementation requires a scoped assignment and the applicable engineering qualification; release and merge remain held.

## 9. One next action

An eligible, non-author reviewer independently qualifies the ACT-000194 reference-preservation question and unique-reference falsifier, alongside the 26 exclusions and 39 other applied action proposals. Return precise source witnesses, independent expectation provenance, disposition and blockers to Oracle issue #1. Do not dispatch WP-B implementation or infer engineering closure from this prepared design.
