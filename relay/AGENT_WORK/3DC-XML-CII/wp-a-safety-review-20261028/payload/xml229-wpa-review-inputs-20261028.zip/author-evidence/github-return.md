## Read-only continuation — full-transaction ComponentRefNo falsifier and WP-B design prepared (2026-10-28)

**Disposition: NEW_PRESERVATION_COUNTEREXAMPLE_OBSERVED · SELF_ASSESSED · ENGINEERING_HOLD · NO_REVIEWER_DISPATCH.** This continues the Owner-directed ledger-evidence path in [comment 6464103203](https://github.com/reallakshman19/xml229-topology-wp1-preview-20261028/issues/1#issuecomment-6464103203). It does not recover the historical browser export or confer independent/engineering acceptance.

### Fresh source and replay

Pinned preview `1b9804b21aacd14e12a884f98b5958b9441a9cc2`; exact public S0 144,471 bytes, SHA256 `feee5a5a6399207337e63bc56c8afb001fe37ab30c6a7a9283333ec60f6eea38`. All 13 locally retained reference code files match their Git blob IDs. Fresh execution of the **native JS batch planner plus unmodified Python transaction** again yields 210 findings, 66 eligible, 45 initially selected, 40 committed, 26 excluded, 9/9 checks, and fixed XML SHA256 `6e76322a640fb26f34effeba9e203a6dd5347ebb02f90be8366dbf13d9b02567`.

All 40 applied proposals were traced: **32 ALIAS_COINCIDENT_NODE + 7 CONTRACT_PRESERVE_OWNER + 1 SAFE_DROP_PIPE_GEOMETRY**, producing **48 NodeNumber alias operations + 1 record removal**. Normalized element/attribute/text-tree changes are fully accounted for by these operations; this comparison ignores formatting whitespace, comments and processing instructions and does not prove connectivity or engineering correctness. Existing `build_topofix_source_lineage` succeeds: 216 source occurrences, 215 retained, 48 changed retained, one removed. Existing reanalysis/lineage are not absent.

### New original-source target: ACT-000194

Actual committed deletion: **`B3:N1600:S2` PIPE -> retained owner `B3:N1610:S3` ELBO**. Both have OD 219.1, wall 8.18, identical XYZ `445580.151 -1159925.000 2904.550`; removed PIPE has empty NodeName, no restraint, rigid/weight zero, and **nonempty ComponentRefNo** `PIPE AUTO /ASIM-1885-8"-S8810103-91261M7-HC-01/B1 1`. The model says `carries_engineering_semantics=True`, but the operation labels removal `PLAIN_PIPE_WITHOUT_ENGINEERING_SEMANTICS`.

**Qualification:** that original pipe reference also survives at `B3:N1590:S1`. Therefore this observation alone does **not** prove an unsafe original repair or complete loss of that original component reference. The retained ELBO owns a different reference `=1006649732/51429`; source-property context also differs (e.g. insulation thickness 0 versus 100). Those facts require engineering interpretation, not automatic condemnation or approval.

### Complete transaction controls — not merely a direct guard call

Predictions were recorded in the harness before execution. Each synthetic source is reparsed and its action freshly regenerated; no S0 ID is blindly replayed on changed bytes.

| Fixture | Observed complete transaction |
|---|---|
| Exact original ACT-000194 | COMMITS; 9/9; original ref remains elsewhere |
| Change only removed record's ComponentRefNo to `SYNTHETIC-UNIQUE-PIPE-REF-KEEP` | **COMMITS; 9/9; unique ref disappears entirely**, while model semantics=True |
| Empty ComponentRefNo control | COMMITS; 9/9; model semantics=False |
| Add NodeName control | REJECTS `ABSORBED_PIPE_HAS_NODE_NAME` |
| Exact original ACT-000030 | REJECTS `ABSORBED_PIPE_HAS_NODE_NAME` |

Unique-reference synthetic source SHA256: `eb1138fd3689354c967dbb062fe33795dd5397146fcfb914c3c8873894602d54`. This is a **reproduced full-transaction preservation gap** under the model's existing semantic classification. It strengthens the earlier narrow-predicate inconsistency into an executable falsifier. It remains **SELF_ASSESSED**, not a qualified design-authority decision or proof that the original 40-action copy is unsafe.

The protected and preview `transaction.py` share blob `121d751eeb34f6a4c927b4ab7ad9bad74e16226d`; `models.py` share blob `42fd8ceabe02e7962f4e6e15ae6633f5dc88dc24`. Shared guard behavior is source-grounded; preview **ACT IDs are still not protected-plan identities**.

### Admission evidence and successor design

Executed authoritative Python parser controls accept all 216 records under (F1) foreign `RichInput` wrapper, (F2) `urn:foreign:psi116` namespace, and (F3) foreign-namespace consumed `NodeNumber`. These fail the proposed strict-admission requirement. The parser blob matches protected `parser.py`; root/docs scene parsers match the preview's local-name implementation. **UI runtime matrix NOT_RUN** here because local Chromium is unavailable; source inspection is not browser execution.

Prepared `WP-B-design-contract.md`: expanded-name/root/profile admission at every entrance; separate raw/text source hashes; immutable revisions; run/config-bound actions; persistent cases; provenance-qualified cross-revision mapping; renumber/insert/ambiguity/stale-run negatives; explicit UNVERIFIABLE rather than disappearance-based closure. Reuse existing transaction lineage. This is **read-only design preparation**, not WP-B implementation or dispatch.

### Return and one next qualification

Reproducible scripts: `python investigate.py`, `python falsify-removal.py`; evidence includes every applied action's source/owner witnesses, all 26 excluded rows, full control receipts and admission results. The public-safe package is delivered in the Owner chat; no private XML is included or uploaded here.

**ONE NEXT:** an eligible non-author reviewer independently assesses the ACT-000194 reference-bearing removal and unique-reference falsifier, alongside the 26 exclusions and 39 other applied proposals. Establish expectation provenance and determine whether a bounded fail-closed ComponentRefNo repair is required **before WP-B coding**. Preserve NodeName/property vetoes; never weaken validation to restore the old 40-action count.

No reviewer has been appointed/dispatched. Engineering acceptance and all excluded dispositions remain held. Protected PR #346 freshly remains OPEN/DRAFT at `cba348152faa9c2077d5c91a5f85b4b81d2e8e25`. No product code, original model/XML, protected branch, deployment or merge state changed.
