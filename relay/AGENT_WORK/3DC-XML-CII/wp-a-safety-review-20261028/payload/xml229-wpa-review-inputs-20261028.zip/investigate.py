from __future__ import annotations
from collections import Counter
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import copy
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'reference/converters'))
from psi116_topology_resolver.models import ResolverConfig
from psi116_topology_resolver.resolver import resolve_psi116
from psi116_topology_resolver.transaction import apply_topofix_transaction, TransactionPolicy
from psi116_topology_resolver.lineage import build_topofix_source_lineage

OUT = ROOT / 'output'
OUT.mkdir(exist_ok=True)
SOURCE_SHA = 'feee5a5a6399207337e63bc56c8afb001fe37ab30c6a7a9283333ec60f6eea38'
OUTPUT_SHA = '6e76322a640fb26f34effeba9e203a6dd5347ebb02f90be8366dbf13d9b02567'
source = (ROOT / 'reference/FirstpassXML').read_bytes().decode('utf-8')
assert sha256(source.encode()).hexdigest() == SOURCE_SHA
cfg = ResolverConfig()
before = resolve_psi116(source, cfg, source_name='FirstpassXML')
records = {n.key: n for b in before.document.branches for n in b.nodes}
findings = {f.finding_id: f for f in before.findings}
actions = {a.action_id: a for a in before.fix_actions}

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def keys(action):
    return sorted({k for f in action.finding_ids for k in findings[f].node_keys})

def xml_record(node):
    return ET.fromstring(node.raw_xml)

def local(tag):
    return tag.rsplit('}', 1)[-1]

def fields(node):
    return {local(x.tag): (x.text or '').strip() for x in xml_record(node)}

def signature(el):
    return [el.tag, sorted(el.attrib.items()), (el.text or '').strip(), [signature(x) for x in el]]

def witness(node):
    return {'key': node.key, 'branchName': node.branch_name,
            'carriesEngineeringSemantics': node.carries_engineering_semantics,
            'allOriginalFields': fields(node), 'sourceXmlFragment': node.raw_xml}

scene = {k: {'nodeNumber': n.node_number, 'type': n.raw_component_type,
             'nodeName': n.node_name, 'restraint': n.has_restraint,
             'weight': fields(n).get('Weight', '')} for k, n in records.items()}
payload = {'findings': before.findings_payload(cfg)['findings'],
           'actions': before.fix_plan_payload(cfg)['actions'], 'records': scene}
save('planner-input.json', payload)
js = "import fs from 'node:fs';import {previewBatchPlan} from './reference/tabs/topology-workspace/batch-plan.mjs';const p=JSON.parse(fs.readFileSync('output/planner-input.json','utf8'));console.log(JSON.stringify(previewBatchPlan(p.findings,p.actions,p.records)));"
plan = json.loads(subprocess.check_output(['node', '--input-type=module', '-e', js], cwd=ROOT))
save('native-js-plan.json', plan)
selected = list(plan['actionIds'])
excluded = list(plan['skipped'])
attempts = []
for attempt in range(25):
    txn = apply_topofix_transaction(before, policy=TransactionPolicy(selected_action_ids=tuple(selected)))
    attempts.append({'selectedActionIds': list(selected), 'committed': txn.committed,
                     'rejectReasons': list(txn.reject_reasons)})
    if txn.committed:
        break
    rejected = sorted({m.group(1) for r in txn.reject_reasons
                       if (m := re.match(r'^APPLY_FAILED:Action (ACT-[0-9]+)(?:[^0-9]|$)', r))})
    assert rejected and set(rejected) < set(selected), txn.reject_reasons
    for action_id in rejected:
        excluded.append({'actionId': action_id, 'reason': next(r for r in txn.reject_reasons if 'Action '+action_id in r)})
    selected = [i for i in selected if i not in rejected]
else:
    raise AssertionError('No committed replay')
assert (len(before.findings), plan['candidateCount'], len(plan['actionIds']), len(selected), len(excluded)) == (210, 66, 45, 40, 26)
assert sha256(txn.fixed_xml.encode()).hexdigest() == OUTPUT_SHA
assert len(txn.checks) == 9 and all(c.passed for c in txn.checks)
assert not set(selected) & {e['actionId'] for e in excluded}
save('transaction.json', txn.transaction_payload())
save('validation.json', txn.validation_payload())
save('existing-source-lineage.json', build_topofix_source_lineage(txn))
save('attempts.json', attempts)
save('excluded-source-ledger.json', [dict(e, disposition=actions[e['actionId']].disposition,
     sourceWitnesses=[witness(records[k]) for k in keys(actions[e['actionId']])],
     engineeringDisposition='UNRESOLVED', dependencyOrAlternativeStatus='UNKNOWN') for e in excluded])

# Structural comparison covers all parsed element fields, attributes and children.
# It ignores formatting whitespace, comments and processing instructions.
# Replay operations against a separate original clone, then compare to actual output.
expected = ET.fromstring(source)
branches = [x for x in expected.iter() if local(x.tag) == 'Branch']
nodes = {(bi, si): x for bi, b in enumerate(branches)
         for si, x in enumerate(c for c in b if local(c.tag) == 'Node')}
applied = []
for a in txn.selected_actions:
    ops = [op for op in txn.operations if op.action_id == a.action_id]
    entry = {'actionId': a.action_id, 'disposition': a.disposition, 'operations': [],
             'engineeringQualification': 'NOT_ESTABLISHED'}
    for op in ops:
        n = records[op.source_node_key]
        el = nodes[n.branch_index, n.source_index]
        entry['operations'].append(dict(asdict(op), sourceWitness=witness(n),
               retainedWitness=witness(records[op.retained_node_key])))
        if op.operation == 'REMOVE_PLAIN_PIPE_NODE_RECORD':
            branches[n.branch_index].remove(el)
        else:
            tag = {'ALIAS_NODE_NUMBER': 'NodeNumber', 'SET_RIGID_ZERO': 'Rigid'}[op.operation]
            child = next((x for x in el if local(x.tag) == tag), None)
            if child is None:
                child = ET.Element(el.tag.rsplit('}', 1)[0] + '}' + tag)
                el.append(child)
            child.text = str(op.after)
    applied.append(entry)
actual = ET.fromstring(txn.fixed_xml)
assert signature(expected) == signature(actual), 'Unaccounted XML semantic-tree change'
save('applied-40-source-audit.json', applied)
removed = [op for op in txn.operations if op.operation == 'REMOVE_PLAIN_PIPE_NODE_RECORD']

# Predict before execution: nonempty ComponentRefNo should prevent a semantic record's
# deletion; current narrow guard is predicted to allow it after removing the other vetoes.
cfroot = ET.fromstring(source)
cfbranches = [x for x in cfroot.iter() if local(x.tag) == 'Branch']
cfnodes = [x for x in cfbranches[4] if local(x.tag) == 'Node']
def set_field(el, tag, value):
    next(x for x in el if local(x.tag) == tag).text = value
set_field(cfnodes[35], 'NodeName', '')
set_field(cfnodes[35], 'WallThickness', fields(records['B4:N2050:S34'])['WallThickness'])
cfsource = ET.tostring(cfroot, encoding='unicode')
cfbefore = resolve_psi116(cfsource, cfg, source_name='SYNTHETIC-NOT-ENGINEERING-REVISION')
cffindings = {f.finding_id: f for f in cfbefore.findings}
cfaction = next(a for a in cfbefore.fix_actions if a.disposition == 'SAFE_DROP_PIPE_GEOMETRY'
    and 'B4:N2060:S35' in {k for f in a.finding_ids for k in cffindings[f].node_keys})
cftxn = apply_topofix_transaction(cfbefore, policy=TransactionPolicy(selected_action_ids=(cfaction.action_id,)))
save('component-ref-full-transaction-falsifier.json', {
    'classification': 'SYNTHETIC_COUNTERFACTUAL_SELF_ASSESSED',
    'predictionBeforeRun': 'Preservation requirement predicts reject; implementation guard predicts deletion once NodeName and wall vetoes are removed.',
    'originalSourceSha256': SOURCE_SHA, 'syntheticSourceSha256': cfbefore.document.source_sha256,
    'changedFields': {'B4:N2060:S35': {'NodeName': '', 'WallThickness': fields(records['B4:N2050:S34'])['WallThickness']}},
    'actionIdRegeneratedFromSyntheticSource': cfaction.action_id,
    'sourceWitness': witness(next(n for b in cfbefore.document.branches for n in b.nodes if n.key == 'B4:N2060:S35')),
    'transaction': cftxn.transaction_payload(), 'validation': cftxn.validation_payload(),
    'originalBatchUnsafeDeletionClaim': False})

# Parser admission negatives, made from exact S0 in memory only.
admission = []
ns = 'http://aveva.com/pipeStress116.xsd'
wrapped = '<RichInput>' + source[source.index('<PipeStressExport '):] + '</RichInput>'
variants = {'valid-original': source, 'F1-foreign-root': wrapped,
            'F2-foreign-namespace': source.replace(ns, 'urn:foreign:psi116'),
            'F3-mixed-child-namespace': source.replace('<NodeNumber>10</NodeNumber>', '<NodeNumber xmlns="urn:foreign:child">10</NodeNumber>', 1)}
for label, text in variants.items():
    try:
        doc = resolve_psi116(text, cfg, source_name=label).document
        admission.append({'case': label, 'accepted': True, 'nodeCount': sum(len(b.nodes) for b in doc.branches), 'rootNamespace': doc.namespace})
    except Exception as exc:
        admission.append({'case': label, 'accepted': False, 'error': str(exc)})
save('python-admission-negatives.json', admission)
for name, text in variants.items():
    (OUT / (name + '.xml')).write_text(text)
summary = {
    'sourceSha256': SOURCE_SHA, 'correctedXmlSha256': OUTPUT_SHA,
    'sourceOccurrenceCount': len(records), 'findings': len(before.findings),
    'eligible': plan['candidateCount'], 'initialSelected': len(plan['actionIds']),
    'applied': len(selected), 'excluded': len(excluded), 'checksPassed': len(txn.checks),
    'appliedDispositions': dict(Counter(a.disposition for a in txn.selected_actions)),
    'operations': dict(Counter(op.operation for op in txn.operations)),
    'normalizedElementTreeChangesAccounted': True,
    'treeComparisonLimits': 'Ignores formatting whitespace, comments and processing instructions; not byte preservation or engineering proof.',
    'removedRecordsCarryingModelSemantics': [witness(records[op.source_node_key]) for op in removed if records[op.source_node_key].carries_engineering_semantics],
    'counterfactualTransactionCommitted': cftxn.committed,
    'counterfactualChecksPassed': sum(c.passed for c in cftxn.checks),
    'independence': 'NOT_ESTABLISHED', 'engineeringAcceptance': 'HOLD'}
save('summary.json', summary)
print(json.dumps(summary, indent=2))
print(json.dumps(admission, indent=2))
