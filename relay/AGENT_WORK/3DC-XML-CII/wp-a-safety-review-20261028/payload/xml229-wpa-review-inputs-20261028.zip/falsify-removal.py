from __future__ import annotations
from pathlib import Path
import json
import sys
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'reference/converters'))
from psi116_topology_resolver.resolver import resolve_psi116
from psi116_topology_resolver.transaction import apply_topofix_transaction, TransactionPolicy

source=(ROOT/'reference/FirstpassXML').read_bytes().decode()
def local(tag):
    return tag.rsplit('}',1)[-1]

# Predictions recorded in this input before invoking any variant:
# The complete transaction is predicted to commit a nonempty, unique pipe ref,
# despite model semantics=True; NodeName is predicted to veto the same deletion.
fixtures=[
    ('original-ACT-000194',3,2,{},True),
    ('unique-ref-only',3,2,{'ComponentRefNo':'SYNTHETIC-UNIQUE-PIPE-REF-KEEP'},True),
    ('empty-ref-control',3,2,{'ComponentRefNo':''},True),
    ('named-record-veto',3,2,{'NodeName':'SYNTHETIC-RETAIN-NAMED-RECORD'},False),
    ('original-ACT-000030',4,35,{},False),
]
rows=[]
for label,bi,si,changes,predicted in fixtures:
    root=ET.fromstring(source)
    branch=[x for x in root.iter() if local(x.tag)=='Branch'][bi]
    node=[x for x in branch if local(x.tag)=='Node'][si]
    for key,value in changes.items():
        next(x for x in node if local(x.tag)==key).text=value
    # For original controls, keep exact original bytes and digest.
    text=source if not changes else ET.tostring(root,encoding='unicode')
    result=resolve_psi116(text,source_name=label)
    record=next(n for b in result.document.branches for n in b.nodes
                if n.branch_index==bi and n.source_index==si)
    findings={f.finding_id:f for f in result.findings}
    candidates=[a for a in result.fix_actions if a.disposition=='SAFE_DROP_PIPE_GEOMETRY'
                and record.node_number in a.absorbed_node_numbers
                and record.key in {k for f in a.finding_ids for k in findings[f].node_keys}]
    assert len(candidates)==1,(label,len(candidates))
    action=candidates[0]
    txn=apply_topofix_transaction(result,policy=TransactionPolicy(selected_action_ids=(action.action_id,)))
    refs_after=[n.component_ref_no for b in txn.after_result.document.branches for n in b.nodes] if txn.after_result else []
    rows.append({'fixture':label,'synthetic':bool(changes),'changedFields':changes,
        'predictedCurrentImplementationCommit':predicted,
        'sourceSha256':result.document.source_sha256,'regeneratedActionId':action.action_id,
        'sourceKey':record.key,'componentRefNo':record.component_ref_no,
        'modelCarriesEngineeringSemantics':record.carries_engineering_semantics,
        'committed':txn.committed,'checksPassed':sum(c.passed for c in txn.checks),
        'checksCount':len(txn.checks),'rejectReasons':list(txn.reject_reasons),
        'componentRefPresentInOutput':record.component_ref_no in refs_after if txn.committed else None,
        'transaction':txn.transaction_payload(),'validation':txn.validation_payload()})
    assert txn.committed==predicted,label
(ROOT/'output/full-transaction-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{k:v for k,v in row.items() if k not in {'transaction','validation'}} for row in rows],indent=2))
