"""Small meaningful checks; all temporary test files stay in this directory."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from make_fixture import ROOT, PAYLOADS, MANIFEST, archive_bytes
from verify_canary import verify, MAX_ARCHIVE_BYTES, MAX_MEMBER_BYTES


def run():
    original = (ROOT / "canary.zip").read_bytes()
    expected_hash = sha256(original).hexdigest()
    assert original == archive_bytes() == archive_bytes(), "build is not deterministic"
    assert verify(ROOT / "canary.zip", expected_hash)["ok"]
    checks = ["deterministic rebuild", "valid ZIP with archive pin"]
    with TemporaryDirectory(prefix="checks-", dir=ROOT) as directory:
        target = Path(directory) / "test.zip"

        def rejected(label, data, expected_message, pin=None):
            target.write_bytes(data)
            try:
                verify(target, pin)
            except ValueError as error:
                assert expected_message in str(error), (label, str(error))
                checks.append(label)
            else:
                raise AssertionError(label + " was accepted")

        entries = {**PAYLOADS, "manifest.json": MANIFEST}
        changed = dict(entries)
        changed["payloads/all-bytes.bin"] = b"X" + PAYLOADS["payloads/all-bytes.bin"][1:]
        rejected("same-length byte mutation rejected", archive_bytes(changed), "SHA-256 mismatch")
        missing = dict(entries)
        del missing["payloads/empty.bin"]
        rejected("missing member rejected", archive_bytes(missing), "missing member")
        rejected("traversal rejected", archive_bytes({**entries, "../escape.bin": b"x"}), "unsafe member path")
        rejected("unexpected member rejected", archive_bytes({**entries, "extra.bin": b"x"}), "unexpected ZIP member")
        rejected("changed manifest rejected", archive_bytes({**entries, "manifest.json": MANIFEST + b" "}), "trusted manifest")
        rejected("oversized member rejected", archive_bytes({**entries, "huge.bin": b"x" * (MAX_MEMBER_BYTES + 1)}), "member exceeds size bound")
        rejected("oversized archive rejected", b"x" * (MAX_ARCHIVE_BYTES + 1), "archive exceeds size bound")
        rejected("wrong archive pin rejected", original, "archive SHA-256 mismatch", "0" * 64)
    print("PASS: " + "; ".join(checks))


if __name__ == "__main__":
    run()
