"""Build a public-safe deterministic fixture; standard library only."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_STORED

ROOT = Path(__file__).resolve().parent
TEXT = "Byte transfer canary — café; naïve; Ελληνικά; 日本語; العربية; 😀\nLF line\nCRLF line\r\nFinal NUL follows: \x00\n"
PAYLOADS = {
    "payloads/utf8-世界.txt": TEXT.encode("utf-8"),
    "payloads/all-bytes.bin": bytes(range(256)) * 17 + b"\x00\xff\x80\r\n\x00END",
    "payloads/empty.bin": b"",
}
MANIFEST = (json.dumps({
    "schema": "byte-transfer-canary/v1",
    "files": [{"path": name, "bytes": len(data), "sha256": sha256(data).hexdigest()}
              for name, data in sorted(PAYLOADS.items())],
}, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def archive_bytes(entries=None):
    entries = {**PAYLOADS, "manifest.json": MANIFEST} if entries is None else entries
    stream = BytesIO()
    with ZipFile(stream, "w", compression=ZIP_STORED, allowZip64=False) as archive:
        for name, data in sorted(entries.items()):
            info = ZipInfo(name, date_time=(2020, 1, 2, 3, 4, 6))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = ZIP_STORED
            archive.writestr(info, data)
    return stream.getvalue()


if __name__ == "__main__":
    ROOT.mkdir(parents=True, exist_ok=True)
    data = archive_bytes()
    (ROOT / "canary.zip").write_bytes(data)
    (ROOT / "manifest.json").write_bytes(MANIFEST)
    print(json.dumps({"archive_bytes": len(data), "archive_sha256": sha256(data).hexdigest(),
                      "manifest_sha256": sha256(MANIFEST).hexdigest()}, indent=2))
