# Synthetic byte-transfer qualification

This archive contains only public-safe synthetic test material. It qualifies
file transport; its contents do not establish that any transfer has succeeded.

The inner `canary.zip` must be exactly 5,495 bytes with SHA-256:
`7dc9fa7e979f9a7f96e389fcce2966e2f27c74652341e3a8e97e1da521072dc1`

It contains UTF-8 Unicode text, LF/CRLF/NUL, all byte values, an empty file, and
a manifest of exact payload lengths and SHA-256 hashes. ZIP metadata is fixed.

With Python 3.8+ and its standard library, verify the received inner file:

```text
python verify_canary.py canary.zip --expected-archive-sha256 7dc9fa7e979f9a7f96e389fcce2966e2f27c74652341e3a8e97e1da521072dc1
```

`make_fixture.py` rebuilds the inner fixture. `check_fixture.py` runs its
positive and negative checks. `checks.txt` is stdout captured from an actual
successful check run when this wrapper was built. The verifier reads without
extracting members and enforces size, member-set, path, length and hash checks.

Verify the outer archive's expected length and SHA-256 supplied through the
trusted handoff before unpacking it. Then run the inner verification above.
