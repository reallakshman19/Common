"""Verify this canary ZIP without extracting it; standard library only.

Pin --expected-archive-sha256 for exact ZIP byte identity. The embedded manifest
pin validates payload identity even without that optional transport-level pin.
"""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sys
from zipfile import ZipFile, BadZipFile, ZIP_STORED, ZIP_DEFLATED

EXPECTED_MANIFEST_SHA256 = "8e866b547787d38efc3684fe17b60b03dc7c9d4e46ad572699dbd109c73895f5"
MAX_ARCHIVE_BYTES = 1024 * 1024
MAX_MEMBER_BYTES = 64 * 1024
MAX_TOTAL_BYTES = 256 * 1024
MAX_MANIFEST_BYTES = 16 * 1024
MAX_MEMBERS = 16
CHUNK_BYTES = 8192


def require(condition, message):
    if not condition:
        raise ValueError(message)


def safe_name(name):
    require(isinstance(name, str) and 0 < len(name.encode("utf-8")) <= 256,
            "invalid member name")
    require(not any(c in name for c in ("\\", ":", "\x00")), "unsafe member name")
    require(all(part not in ("", ".", "..") for part in name.split("/")),
            "unsafe member path")


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, "duplicate JSON key")
        value[key] = item
    return value


def member_hash(archive, info, limit, collect=False):
    digest, length, chunks = sha256(), 0, []
    with archive.open(info, "r") as member:
        while chunk := member.read(CHUNK_BYTES):
            length += len(chunk)
            require(length <= limit, "member exceeds size bound")
            digest.update(chunk)
            if collect:
                chunks.append(chunk)
    require(length == info.file_size, "member length differs from ZIP declaration")
    return length, digest.hexdigest(), b"".join(chunks)


def verify(path, expected_archive_sha256=None):
    if expected_archive_sha256 is not None:
        require(re.fullmatch(r"[0-9a-fA-F]{64}", expected_archive_sha256) is not None,
                "expected archive SHA-256 must contain 64 hex digits")
        expected_archive_sha256 = expected_archive_sha256.lower()
    with Path(path).open("rb") as source:
        require(os.fstat(source.fileno()).st_size <= MAX_ARCHIVE_BYTES,
                "archive exceeds size bound")
        digest, archive_size = sha256(), 0
        while chunk := source.read(CHUNK_BYTES):
            archive_size += len(chunk)
            require(archive_size <= MAX_ARCHIVE_BYTES, "archive exceeds size bound")
            digest.update(chunk)
        archive_sha256 = digest.hexdigest()
        source.seek(0)
        with ZipFile(source, "r") as archive:
            entries = archive.infolist()
            require(0 < len(entries) <= MAX_MEMBERS, "invalid ZIP member count")
            names, total = {}, 0
            for entry in entries:
                safe_name(entry.filename)
                require(entry.orig_filename == entry.filename, "truncated ZIP member name")
                require(entry.filename not in names, "duplicate ZIP member")
                require(not entry.is_dir(), "directory members are not allowed")
                require(not entry.flag_bits & 1, "encrypted ZIP members are not allowed")
                require(entry.compress_type in (ZIP_STORED, ZIP_DEFLATED),
                        "unsupported ZIP compression")
                require(0 <= entry.file_size <= MAX_MEMBER_BYTES, "member exceeds size bound")
                total += entry.file_size
                require(total <= MAX_TOTAL_BYTES, "total uncompressed size exceeds bound")
                names[entry.filename] = entry
            require("manifest.json" in names, "missing manifest.json")
            info = names["manifest.json"]
            require(info.file_size <= MAX_MANIFEST_BYTES, "manifest exceeds size bound")
            _, manifest_hash, manifest_bytes = member_hash(archive, info, MAX_MANIFEST_BYTES, True)
            require(manifest_hash == EXPECTED_MANIFEST_SHA256, "trusted manifest SHA-256 mismatch")
            manifest = json.loads(manifest_bytes.decode("utf-8"), object_pairs_hook=unique_object)
            require(isinstance(manifest, dict) and set(manifest) == {"schema", "files"},
                    "invalid manifest structure")
            require(manifest["schema"] == "byte-transfer-canary/v1", "unknown manifest schema")
            require(isinstance(manifest["files"], list) and len(manifest["files"]) < MAX_MEMBERS,
                    "invalid manifest file count")
            expected, verified = {"manifest.json"}, []
            for item in manifest["files"]:
                require(isinstance(item, dict) and set(item) == {"path", "bytes", "sha256"},
                        "invalid manifest file entry")
                name, length, content_hash = item["path"], item["bytes"], item["sha256"]
                safe_name(name)
                require(name not in expected, "duplicate manifest path")
                require(type(length) is int and 0 <= length <= MAX_MEMBER_BYTES,
                        "invalid manifest byte length")
                require(isinstance(content_hash, str) and re.fullmatch(r"[0-9a-f]{64}", content_hash),
                        "invalid manifest SHA-256")
                expected.add(name)
                require(name in names, "missing member: " + name)
                actual_length, actual_hash, _ = member_hash(archive, names[name], MAX_MEMBER_BYTES)
                require(actual_length == length, "byte length mismatch: " + name)
                require(actual_hash == content_hash, "SHA-256 mismatch: " + name)
                verified.append({"path": name, "bytes": actual_length, "sha256": actual_hash})
            require(set(names) == expected, "unexpected ZIP member")
    require(expected_archive_sha256 is None or archive_sha256 == expected_archive_sha256,
            "archive SHA-256 mismatch")
    return {"ok": True, "archive_bytes": archive_size, "archive_sha256": archive_sha256,
            "manifest_sha256": manifest_hash, "files": verified}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive")
    parser.add_argument("--expected-archive-sha256")
    args = parser.parse_args()
    try:
        print(json.dumps(verify(args.archive, args.expected_archive_sha256), ensure_ascii=False, indent=2))
    except (OSError, ValueError, BadZipFile, RuntimeError, NotImplementedError) as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
