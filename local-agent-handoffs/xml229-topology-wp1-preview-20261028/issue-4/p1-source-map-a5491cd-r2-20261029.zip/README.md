# TopoFix WBS 1.3 — IR P1 follow-up

Governing WBS: https://reallakshman19.github.io/progress-page/#/topofix/progress/R1
Task: https://github.com/reallakshman19/xml229-topology-wp1-preview-20261028/issues/4
Code Draft PR: https://github.com/reallakshman19/xml229-topology-wp1-preview-20261028/pull/5
IR return: https://github.com/reallakshman19/xml229-topology-wp1-preview-20261028/issues/2#issuecomment-6494348817

Owner intent: auditable automatic solutions, otherwise clear manual directions and re-TopoFix after authorized correction. Oracle/author: 6ae1b0f7. Designated IR: 6ae2d5ac.

## Exact identities and application

Current candidate a5491cd836ae02db8a2b11b49f6cb969d3235f2e; Git tree ef6aec5b9e1bc709beff11b941d67e9c8b176906.
Prior reviewed head 9804e2c6108dfc0368f407fe8d52170dd071f78a; original preview baseline 1b9804b21aacd14e12a884f98b5958b9441a9cc2.
Check out the exact current remote head. Alternatively apply candidate.patch to the original baseline, or p1-delta.patch to the prior reviewed head. The API-published commit and author local commit differ; the complete Git tree matches the tested local tree.

## What changed

The batch planner always checks source witnesses before selecting SAFE_DROP_PIPE_GEOMETRY, including omitted/null source maps. Missing source proof uses the existing explicit rejection and does not reserve occurrence keys against an unrelated alias. Empty-reference Map/object positive controls still select. Python and workspace invocation are unchanged. Three-file delta: helper, regression tests and SAFETY_REVIEW.md.

## Executed here — author evidence only

The new missing-map regression first fails on the old reviewed head (19 pass, 1 fail). After repair:
- node --test --test-reporter=spec tests/audit-view.test.mjs tests/batch-plan.test.mjs : exit 0, 20 PASS.
- python -B -m unittest discover -s tests -v : exit 0, 13 PASS.
- Pinned source-derived JS selection is identical: 56 candidates, 39 selected, 17 conflicts; ten original proposals remain nonmutating preservation reviews.
- Actual Python transaction replay on original FirstpassXML: 39 selected actions, 48 operations, 9/9 checks PASS, all 216 records/references retained; output SHA256 f7a0b511160ed797f51fc3fcfba9650e551036a2f31f5af685e611224d66547b, byte-identical to the prior author replay output.

Original source SHA256 feee5a5a6399207337e63bc56c8afb001fe37ab30c6a7a9283333ec60f6eea38, 144471 bytes. Obtain separately from 3D_Converters@cba348152faa9c2077d5c91a5f85b4b81d2e8e25:Benchmarks/1885Sjson/FirstpassXML. No original/corrected engineering XML or circuit identifiers are packaged.

## Review limits and required return

IR 6ae2d5ac returned PARTIAL / INDEPENDENCE_NOT_ESTABLISHED on 9804e2c after source verification and bounded exact-code JS checks. Its Python transaction, original 66/40/26 and changed 39/17/10 replay, Chromium/Pyodide/download journey and Common artifact receipt were NOT_RUN. That return is not rebound to this new candidate.

Next: IR 6ae2d5ac independently retrieves/hashes this archive/current candidate and original source, verifies the P1 fix including missing-map and positive controls, executes Python/Node plus actual browser/download journey, supplies independent engineering expectations and returns the scoped verdict on issue #2. Oracle 6ae1b0f7 reconciles it.

Still open: WBS 1.1 case explanations, 1.2 engineering dispositions of original 66 proposals, 1.3 independent preservation qualification; all strict-admission/revision/current-action/case-identity WBS 2; full solution receipts/manual repair/S1 reimport and recheck WBS 3; connection intent, independent proof and Owner trial WBS 4. Source integrity is not corrected-output acceptance. No live unsafe XML deletion was demonstrated by the IR client-helper finding.

The author contributed code/tests/replay/packaging: SELF_ASSESSED. Browser journey remains NOT_RUN; prior installation failed before launch and was not retried here. Hosted preview deployment workflow remains NOT_RUN and was not dispatched. PR #5 and this artifact stay OPEN/DRAFT; protected PR #346 stays untouched/HOLD. No product merge/deploy/engineering acceptance.

## R2: clone-free executable source subset

This transfer adds runtime-source/ with all 11 exact Python package modules, both Python regression files, both standalone JS modules and their Node test files, plus SAFETY_REVIEW.md. File Git-blob identities are recorded against the current candidate tree. This removes the clone/DNS prerequisite for these package and client tests. It does not provide a browser binary or the full browser/UI asset bundle.

From runtime-source/:

    python -B -m unittest discover -s tests -v
    node --test --test-reporter=spec tests/audit-view.test.mjs tests/batch-plan.test.mjs

No npm or pip install is needed for these included checks (Python standard library / Node built-ins). Obtain the original source separately through its existing authorized exact-byte route; no XML is bundled. Use independent expectations and additional reviewer checks; author tests passing does not establish independence. Original artifact commit 49f3dadd and its byte receipt remain historical; this R2 has a new archive path, commit and hash, with the same product candidate.
