# TopoFix WBS 1.3 source-preservation candidate

Governing WBS: https://reallakshman19.github.io/progress-page/#/topofix/progress/R1
Task: https://github.com/reallakshman19/xml229-topology-wp1-preview-20261028/issues/4
Code Draft PR: https://github.com/reallakshman19/xml229-topology-wp1-preview-20261028/pull/5
IR task: https://github.com/reallakshman19/xml229-topology-wp1-preview-20261028/issues/2

Owner intent: provide auditable automatic solutions, otherwise clear manual-review directions. Latest instruction: "proceed coding". This is one bounded candidate, not completion of the WBS.

## Exact candidate

Repository: reallakshman19/xml229-topology-wp1-preview-20261028
Base: 1b9804b21aacd14e12a884f98b5958b9441a9cc2
Tests-first remote commit: 314a891769de89717580a0447964814cacbca875
Candidate remote commit: 9804e2c6108dfc0368f407fe8d52170dd071f78a
Complete candidate Git tree: 71ea7ff944bbd32538bb2b5167941072ba02aede

Check out the exact remote commit or apply candidate.patch to the exact base. Run both commands in evidence/environment.json. Review SAFETY_REVIEW.md in the patch. Before logs contain expected historical regression failures; after logs are current author execution. Transfer SHA/CRC is not engineering acceptance.

The shared guard refuses populated ComponentRefNo removal while retaining name/restraint/rigid/weight/property/position vetoes. The planner emits a nonmutating preservation review and the audit renders escaped source/owner/property evidence plus source-authority correction and re-export/recheck directions. Bulk screening requires explicit empty reference evidence. The Pyodide loader includes the shared module.

## Source replay and limitations

Original public FirstpassXML: 144471 bytes; SHA256 feee5a5a6399207337e63bc56c8afb001fe37ab30c6a7a9283333ec60f6eea38. Obtain through original owning-project source at 3D_Converters@cba348152faa9c2077d5c91a5f85b4b81d2e8e25. No original/corrected engineering XML is in this archive.

Self-assessed replay: original 66 proposals become 39 applied, 17 shared-occurrence conflicts and 10 preservation reviews. All 216 records and component references remain, with the historical 48 alias operations. Nine transaction checks pass. Normalized elements/attributes/text equal original plus those historical aliases, excluding formatting whitespace, comments and processing instructions. That comparison is not an independent engineering expectation.

Browser journey NOT_RUN: installation failed before launch. Hosted preview workflow NOT_RUN and unchanged; it deploys only main/manual dispatch. Do not dispatch for this draft. Its Python pattern runs only gap tests; full discovery must be run explicitly.

## Open criteria and next actor

IR 6ae155fe has not acknowledged, made its separate byte receipt, disclosed distinct principal/independent expectations or assessed the changed candidate. Next: independently retrieve/hash this ZIP and original source, inspect exact code and falsifiers, run Python/Node checks and the actual browser/Pyodide/download journey, then return source-qualified safety dispositions on #2 and cross-link #4.

Still open: WBS 1.1 engineering case explanations, 1.2 original 66-proposal engineering dispositions, 1.3 independent source-preservation qualification (including ACT-000030 constraints and ACT-000194 unique reference); 2.1 strict admission, 2.2 immutable revisions/current-only actions, 2.3 durable case identity; 3.1 solution-level receipts, 3.2 complete manual directions, 3.3 actual manual S1 repair/reimport/full recheck; 4.1 connection intent, 4.2 independent proof, 4.3 Owner-usable trial. Other populated fields and residual 1790/1800/1810 remain unqualified/unrepaired. No native CII/Final/Weight ownership change.

Author contributed code, tests, replay and packaging: SELF_ASSESSED. Protected 3D_Converters PR #346 stays Draft/HOLD and untouched. Code and artifact PRs stay OPEN/DRAFT. Owner reserves product merge/deploy/acceptance.
