# AA3 #56 incremental Error Check repair (not production acceptance)

This artifact is a **delta to the supplied** AA3-56-local-agent-handoff(1).zip, SHA256 `81bef5a678fd0cfff78c6fb8e4bae1315e7d160b68d22bea4f1d5e9af7705f66`, NOT a replacement for its 49-file patch against PR #48. Preserve the original ZIP and source fixture.

## Changes

- Preset stages component-basis, profile and cases only; never assigns an unconfirmed reviewer or reason.
- Settings-only batch preview no longer demands a fake property-edit approver. Property corrections still require both real fields; existing applied override attribution remains unchanged under a settings-only transaction.
- Stale override test invokes actual owner Preview -> Cancel -> Apply; reports BLOCK only if the cancelled token is actually rejected AND the live source/authorization/basis snapshot remains unchanged.
- Recovery compares live preFlight, source/effective table references, override set, workbench snapshot and component-basis selection with a pre-scenario capture. No instant invented success or misleading exception-as-BLOCK.
- E2E test added runtime fixture SHA256/size verification, empty reviewer assertion, actual negative-scenario messages, keyboard focus smoke, and a 7-primary-click ledger assertion (not run here).

## Apply on existing local agent's 49-file candidate (not direct to untouched PR48)

Extract the original handoff's `files/` as project-relative source or apply original `changes.patch` to an **independently checked** clean PR48 worktree. The supplied `repair.patch` is relative to those original handoff **postimages**; first run `git apply --check repair.patch` on that intermediate working tree, then `git apply repair.patch`. New files are also copied under `files/`. If any stage fails, stop and inspect exact base; do not force apply. Do not use this as a single direct patch to clean PR48.

## Actual evidence and limitations

- Local source-only `git apply --check` on extracted prior handoff postimages: **PASS**, actual apply and 8/8 postimage-byte check **PASS**.
- `node --test scripts/lfea-issue56-consent-scenarios.test.mjs`: **6/6 PASS** on actual pure scenario/preset modules with a synthetic owner; RED before modules existed exited 1 for missing module, **not** proof of pre-existing production failure.
- `node --experimental-vm-modules --test scripts/lfea-issue56-transaction-source.test.mjs`: **4/4 PASS** on actual supplied transaction and field-override source with VM authority and synthetic owner/preparation. Not a full real imported controller/ACCDB/browser pass.
- `node --check` and A13: authored/modified files are all <=300 physical lines.
- No complete AA3 checkout, original `BM4_L.ACCDB`, locked dependencies, browser, server, solver or screenshot-producing run in this execution environment. **npm ci, actual ACCDB hash, real Playwright/CSV reproduction: NOT_RUN.** Previous candidate's CSV and action ledger are predecessor evidence only.

## Required local-agent continuation

Apply delta after validating base; run `npm ci` and record genuine pre-patch failures separately, hash the authentic 5,136,384-byte fixture against independently trusted SHA256, run complete existing and new tests, test stage-only no-authority preview, actual disposable scenarios, 5-7 click browser path including no forged approval, keyboard/focus and downloaded case-bound solver CSV. Preserve numeric mechanics, A13, all AC1–AC12, Owner-only acceptance and **no merge/deploy**. The existing source preset still selects a named edition; the engineer must affirm applicable settings and limitations. Read comments/PRs via the Common local-handover issue comment relay. If publishing this archive to GitHub, put only this ZIP in its own DRAFT artifact PR.
