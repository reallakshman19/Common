# COMMANDS_AND_EXITS.md — Test Execution & Exit Code Ledger

**Host Environment:** Windows 11 Pro 64-bit (10.0.26100)  
**Node.js Runtime:** `v22.23.2`  
**Browser Channel:** Microsoft Edge `155.0.4283.62`  
**Git HEAD:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350` (PR #137)  
**Execution Date:** 2026-10-20  

---

## 1. Executed Test Runs

### Run 1: Microsoft Edge 26-Check Verification Script
- **Command:** `node scratch_incoming_edge_v2.mjs`
- **Working Directory:** `<WORKSPACE>` (`C:\Users\reall\Documents\antigravity\mysterious-bohr`)
- **Tested Git HEAD:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350`
- **Working Tree Status:** Clean against HEAD (untracked local scratch scripts only)
- **Node Version:** `v22.23.2`
- **Browser Channel & Version:** `msedge` / Microsoft Edge `155.0.4283.62`
- **Exit Code:** `0`
- **Assertions:** 26 total (4 benchmark SHA-256 custody, 2 code parity, 20 Edge UI/invalidation/safety checks)
- **Passed:** 26
- **Failed:** 0
- **Skipped / Not Run:** 0
- **Log Reference:** `logs/scratch_incoming_edge_v2.log`
- **Produced Evidence:** `evidence/edge-candidate-review-4060-4970.png`, `evidence/edge-stale-invalidation-5110.png`

### Run 2: Initial Microsoft Edge 15-Check Verification Script
- **Command:** `node scratch_verify_edge.mjs`
- **Working Directory:** `<WORKSPACE>` (`C:\Users\reall\Documents\antigravity\mysterious-bohr`)
- **Tested Git HEAD:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350`
- **Working Tree Status:** Clean against HEAD
- **Node Version:** `v22.23.2`
- **Browser Channel & Version:** `msedge` / Microsoft Edge `155.0.4283.62`
- **Exit Code:** `0`
- **Assertions:** 15 total (1 Method C tile, 1 Writer2 mount, 1 hash custody, 1 session custody, 1 row count 57, 1 Node 4060 witness, 1 candidate panel mount, 1 Node 4060 disposition, 1 Node 4970 disposition, 1 candidate screenshot, 1 JSON download, 1 JSON schema audit, 1 stale invalidation, 1 stale screenshot, 1 zero-console/page errors)
- **Passed:** 15
- **Failed:** 0
- **Skipped / Not Run:** 0
- **Log Reference:** `logs/scratch_verify_edge.log`
- **Produced Evidence:** `evidence/method-c-a-review-S1-9a9cb14db4c1-epoch3.json`

### Run 3: Unit Tests (Review, Sidecar, Markup)
- **Command:** `node --test tests/cii-workspace-method-c-a-candidate-review.test.mjs tests/cii-workspace-method-c-a-sidecar.test.mjs tests/cii-workspace-method-c-a-review-markup.test.mjs`
- **Working Directory:** `<WORKSPACE>` (`C:\Users\reall\Documents\antigravity\mysterious-bohr`)
- **Tested Git HEAD:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350`
- **Working Tree Status:** Clean against HEAD
- **Node Version:** `v22.23.2`
- **Exit Code:** `0`
- **Assertions / Subtests:** 16 total (4 candidate review tests + 9 sidecar tests + 3 review markup tests)
- **Passed:** 16
- **Failed:** 0
- **Skipped / Not Run:** 0
- **Log Reference:** `logs/unit_tests.log`

### Run 4: Native Writer2 Browser Tests
- **Command:** `node --test tests/cii-workspace-writer2-method-c-native-app-browser.test.mjs`
- **Working Directory:** `<WORKSPACE>` (`C:\Users\reall\Documents\antigravity\mysterious-bohr`)
- **Tested Git HEAD:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350`
- **Working Tree Status:** Clean against HEAD
- **Node Version:** `v22.23.2`
- **Browser Channel & Version:** Headless Chromium (Playwright bundled)
- **Exit Code:** `0`
- **Assertions / Subtests:** 2 total
  - `I126 REAL served Writer2 Inputs contains ONE original-file Method C action, no sibling replacement`: PASS
  - `I126 original S1/S2/S3/T selected once → Method C 57 original A rows without legacy full Inspect`: PASS
- **Passed:** 2
- **Failed:** 0
- **Skipped / Not Run:** 0
- **Log Reference:** `logs/native_writer2_browser.log`

### Run 5: Candidate Review Browser Tests
- **Command:** `node --test tests/cii-workspace-method-c-a-candidate-review-browser.test.mjs`
- **Working Directory:** `<WORKSPACE>` (`C:\Users\reall\Documents\antigravity\mysterious-bohr`)
- **Tested Git HEAD:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350`
- **Working Tree Status:** Clean against HEAD
- **Node Version:** `v22.23.2`
- **Browser Channel & Version:** Headless Chromium (Playwright bundled)
- **Exit Code:** `0`
- **Assertions / Subtests:** 2 total
  - `I126 REAL served Writer2 Inputs contains ONE original-file Method C action, no sibling replacement`: PASS
  - `I126 A01 original S1/S2/S3/T real next-step review → signed JSON; still A-only`: PASS
- **Passed:** 2
- **Failed:** 0
- **Skipped / Not Run:** 0
- **Log Reference:** `logs/candidate_review_browser.log`

### Run 6: Firebreak Test (Stacked PR Ancestry & Invariant Gate)
- **Command:** `node --test tests/cii-workspace-method-c-i126-firebreak.test.mjs`
- **Working Directory:** `<WORKSPACE>` (`C:\Users\reall\Documents\antigravity\mysterious-bohr`)
- **Tested Git HEAD:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350`
- **Working Tree Status:** Clean against HEAD
- **Node Version:** `v22.23.2`
- **Exit Code:** `1` (Preserved failure)
- **Assertions / Subtests:** 5 total
  - Test 1 (`I126 A-only bridge has identical served and source modules`): PASS
  - Test 2 (`I126 sidecar has no route to independent physical qualification or Writer2 Apply`): PASS
  - Test 3 (`I126 exact PR diff excludes PR107 ownership, benchmarks and previous gate oracles`): FAIL
  - Test 4 (`I126 Writer2 source/deployed entrypoints contain the exact read-only mount and no unrelated edits`): FAIL
  - Test 5 (`I126 predecessor WP7/WP9 jobs remain intact but may run only on original PR118 branch`): FAIL
- **Passed:** 2
- **Failed:** 3
- **Skipped / Not Run:** 0
- **Log Reference:** `logs/firebreak_test.log`

---

## 2. Summary Table of All Executed Test Suites

| Suite / Script | Command | Environment | Exit Code | Total Assertions | PASS | FAIL | NOT_RUN | Status |
|---|---|---|:---:|:---:|:---:|:---:|:---:|---|
| Edge 26-Check Script | `node scratch_incoming_edge_v2.mjs` | Windows 11, Edge 155 | 0 | 26 | 26 | 0 | 0 | **PASS** |
| Edge 15-Check Script | `node scratch_verify_edge.mjs` | Windows 11, Edge 155 | 0 | 15 | 15 | 0 | 0 | **PASS** |
| Unit Tests (3 files) | `node --test tests/cii-workspace-method-c-a-*.test.mjs` | Node.js v22.23.2 | 0 | 16 | 16 | 0 | 0 | **PASS** |
| Writer2 Browser Test | `node --test tests/...writer2-native-app-browser.test.mjs` | Headless Chromium | 0 | 2 | 2 | 0 | 0 | **PASS** |
| Review Browser Test | `node --test tests/...candidate-review-browser.test.mjs` | Headless Chromium | 0 | 2 | 2 | 0 | 0 | **PASS** |
| Firebreak Test | `node --test tests/cii-workspace-method-c-i126-firebreak.test.mjs` | Node.js v22.23.2 | 1 | 5 | 2 | 3 | 0 | **FAIL (PRESERVED)** |
