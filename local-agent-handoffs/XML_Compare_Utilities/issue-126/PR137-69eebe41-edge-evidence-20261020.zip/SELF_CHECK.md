# SELF_CHECK.md — Compliance Matrix: R1–R6 & A01-1..8

**Target Candidate:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350` (PR #137)  
**Verification Environment:** Windows 11 Pro 64-bit · Microsoft Edge `155.0.4283.62`  
**Protocol:** Common `agent-work/local-handover` v2.0  

---

## 1. Issue #126 Parent Acceptance Criteria (R1–R6)

| ID | Title / Requirement | Status | Concrete Evidence / Reason |
|---|---|:---:|---|
| **R1** | **Single Button / Reused Original Intake** | **MET (Prototype)** | Writer2 Inputs panel contains exactly one Method C action (`[data-ciiw-method-c-run]`). S1, S2, S3, T files loaded once into Writer2 established SHA custody READY without secondary file upload dialog. |
| **R2** | **Signed Original Immutable Evidence & Invalidation** | **MET (Prototype)** | JSON receipt signed with session epoch 3, source SHA `9a9cb14d...`, target SHA `abfa3ffc...`. Changing experimental anchor 3910→5110 immediately transitions review state to HOLD/invalidated and removes export button from DOM. |
| **R3** | **Noncircular Owner-Approved Physical B Policy** | **UNMET / UNAUTHORIZED** | No physical B certifier implemented. No policy exists for promoting near XYZ nodes to physical identity. `qualifiedPhysicalIdentityCount = 0` in all observations. Requires authoritative Owner policy specification. |
| **R4** | **Certified BOUND Rows in Compare Review** | **UNMET / BLOCKED** | Without physical B certification (R3), no rows enter `ciiMultiSourceReviewBySource` as BOUND. Compare Review only shows A-only geometric candidate list. |
| **R5** | **Writer2 Review / Transfer / Apply Safety** | **MET (A-Only Firebreak) / UNMET (Productive Transfer)** | A-only firebreak verified: exactly 0 Apply buttons in DOM before and after Method C run; `writerEligible = false`, `applyAuthorized = false`, `mutationOperations = []`. Productive transfer remains unavailable and blocked. |
| **R6** | **Accessible, Performant Real Original Journey** | **MET (A-Only in Edge) / PARTIAL (Issue #121 Hold)** | Served application exercised in Microsoft Edge 155.0.4283.62 with zero console errors and zero page errors. 57 observations rendered cleanly. Full legacy 3-source heavy normalization inspect (Issue #121) was NOT_RUN / HOLD. |

---

## 2. Approved Bounded Prototype Criteria (A01-1 through A01-8)

| Criteria ID | Requirement | Verdict | Runtime Witness / Observation |
|---|---|:---:|---|
| **A01-1** | Original File Selection Reused | **PASS** | Original S1/S2/S3/T selected once in Writer2 inputs; Method C run dialog has 0 `input[type="file"]`. |
| **A01-2** | Non-destructive Experimental Seed Anchor | **PASS** | Method C dialog allows specifying seed anchor 3910→875 without asserting physical node identity. |
| **A01-3** | 57 S1 Physical Source Observations (41/5/11) | **PASS** | Review table renders exactly 57 rows: 41 geometric candidates, 5 segment-only, 11 outside tolerance. |
| **A01-4** | NODE 4060 & 4970 Investigation UI | **PASS** | Interactive candidate panel displays NODE 4060 as projected onto TARGET segment 900→905 (residual 0 mm) and NODE 4970 as outside tolerance (300.57 mm). Dispositions `EVIDENCE_REQUESTED` and `INVESTIGATE` saved with notes. |
| **A01-5** | Truthful Non-Certifying A-Only Marker | **PASS** | Banner explicitly displays `READ_ONLY_GEOMETRY` and `Transfer unavailable`. |
| **A01-6** | Real Review-Only Signed JSON Download | **PASS** | Downloaded `method-c-a-review-S1-9a9cb14db4c1-epoch3.json` (280,707 bytes, SHA-256 `87f7aefc...`) contains full 57 observations, 0 writer operations, 0 qualified physical identities. |
| **A01-7** | Immediate Stale Invalidation | **PASS** | Changing anchor source to 5110 immediately transitions review to HOLD/invalidated and removes `[data-ciiw-candidate-export]` from DOM. |
| **A01-8** | Existing Geometry & Compare Review Undamaged | **PASS** | Native Writer2 browser tests (`tests/cii-workspace-writer2-method-c-native-app-browser.test.mjs`) pass 2/2. No regression to 114 duplicate rows. |

---

## 3. Governance & Delivery Invariants

1. **Product Source Writes:** FORBIDDEN. No files in `XML_Compare_Utilities` modified during this task.
2. **PR #137 State:** DRAFT. Not approved, not merged.
3. **Method C B Policy:** RESERVED to Owner. No agent self-authorization of B certification.
4. **Evidence Custody:** All hashes independently calculated and verified from raw file bytes.
