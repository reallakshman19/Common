# EDGE_26_CHECK_LEDGER.md — Named Assertions & Runtime Witnesses

**Execution Environment:** Windows 11 Pro 64-bit · Microsoft Edge `155.0.4283.62`  
**Execution Script:** `scripts/scratch_incoming_edge_v2.mjs`  
**Git Candidate Commit:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350` (PR #137)  
**Execution Result:** 26/26 PASS · 0 FAIL · 0 SKIPPED

---

## 1. Check-by-Check Assertion Ledger

| # | Check ID | Category | Assertion / Expectation | Runtime Witness / Selector / Oracle | Result | Observation |
|---|---|---|---|---|---|---|
| 1 | `HASH-S1.CII` | Custody | `Benchmark/S1.CII` matches canonical SHA-256 | `crypto.createHash('sha256')` equals `9a9cb14db4c13f5aac41cc74a60e7e528722eb5003d09f07192762ab6bfb1a2b` | **PASS** | Verified independently from raw bytes |
| 2 | `HASH-S2.CII` | Custody | `Benchmark/S2.CII` matches canonical SHA-256 | `crypto.createHash('sha256')` equals `7ec48b76b65eedfd5ecc9c8e8feca1a45dd8c83721a68b53aa0db3363e6d27fd` | **PASS** | Verified independently from raw bytes |
| 3 | `HASH-S3.CII` | Custody | `Benchmark/S3.CII` matches canonical SHA-256 | `crypto.createHash('sha256')` equals `c2143b31c482158ac5514d2709406c14a9179e656277c654e932bb845d090caa` | **PASS** | Verified independently from raw bytes |
| 4 | `HASH-T.CII` | Custody | `Benchmark/T.CII` matches canonical SHA-256 | `crypto.createHash('sha256')` equals `abfa3ffc9281fe75d4170b2d885d554cb1f120dadedae7c7ab609548b63cc060` | **PASS** | Verified independently from raw bytes |
| 5 | `PARITY-cii-workspace-method` (Bridge) | Integrity | `docs/tabs/cii-workspace/cii-workspace-method-c-writer2-bridge.js` == `tabs/cii-workspace/cii-workspace-method-c-writer2-bridge.js` | SHA-256 byte comparison | **PASS** | Byte-identical deployed and source files |
| 6 | `PARITY-cii-workspace-method` (Review) | Integrity | `docs/tabs/cii-workspace/cii-workspace-method-c-a-candidate-review.js` == `tabs/cii-workspace/cii-workspace-method-c-a-candidate-review.js` | SHA-256 byte comparison | **PASS** | Byte-identical deployed and source files |
| 7 | `EDGE-01` | Navigation | App tab `psnm-utility` clickable in Edge | `page.locator('.app-tab[data-tab="psnm-utility"]').click()` | **PASS** | Utility tab opened cleanly |
| 8 | `EDGE-02` | UI Mount | Exactly 1 Method C launch tile present | `page.locator('[data-ciiw-open-method-c]').count() === 1` | **PASS** | Expected count 1, observed 1 |
| 9 | `EDGE-03` | UI Mount | Writer2 shell opens with Inputs panel visible | `shell.locator('[data-ciiw-panel="inputs"]').waitFor({ state: 'visible' })` | **PASS** | Shell rendered and inputs panel active |
| 10 | `EDGE-04` | UI Mount | Exactly 1 Method C run action in inputs panel | `shell.locator('[data-ciiw-panel="inputs"] [data-ciiw-method-c-run]').count() === 1` | **PASS** | Expected 1 run action, observed 1 |
| 11 | `EDGE-05` | UI Mount | Method C review action present in compare panel | `shell.locator('[data-ciiw-panel="compare"] [data-ciiw-method-c-review]').count() === 1` | **PASS** | Expected 1 review action, observed 1 |
| 12 | `EDGE-06` | Safety Gate | Zero Apply buttons anywhere in Writer2 shell | `shell.locator('[data-ciiw-method-c-apply]').count() === 0` | **PASS** | Count = 0 (mutation route strictly closed) |
| 13 | `EDGE-07` | Custody Intake | Benchmark files S1, S2, S3, T loaded via File input | `shell.locator('[data-ciiw-source]').setInputFiles(...)` & `[data-ciiw-target]` | **PASS** | In-memory verified buffers accepted |
| 14 | `EDGE-08` | Custody Status | Retained file custody established | `shell.locator('[data-ciiw-method-c-message]')` matches `S1/S2/S3/T SHA custody READY` | **PASS** | Message observed within timeout |
| 15 | `EDGE-09` | Dialog | Method C input configuration dialog opens | `shell.locator('[data-ciiw-method-c-inputs]').waitFor({ state: 'visible' })` | **PASS** | Dialog visible in Edge DOM |
| 16 | `EDGE-10` | Custody Preservation | Zero file inputs inside Method C dialog (no re-upload) | `inputs.locator('input[type="file"]').count() === 0` | **PASS** | Count = 0 (original file handles preserved) |
| 17 | `EDGE-11` | Execution | Method C run initiated with S1 and anchor 3910→875 | Fill source=3910, target=875, click `[data-ciiw-method-c-start]` | **PASS** | Experimental seed accepted, pose computed |
| 18 | `EDGE-12` | Review Count | Exactly 57 observations in Compare Review table | `review.locator('tbody tr').count() === 57` | **PASS** | Count = 57 (not 41, not duplicate 114) |
| 19 | `EDGE-13` | Element Witness | NODE 4060 has status `MISSING_TARGET_NODE_BUT_ALIGNED_SEGMENT` | `tr[data-source-node="4060"]` data-status and text matching `900` / `905` | **PASS** | Projected on segment 900→905, 0 residual |
| 20 | `EDGE-14` | Safety Gate | Zero Apply buttons exist after Method C run | `shell.locator('[data-ciiw-method-c-apply]').count() === 0` | **PASS** | Count = 0 post-execution |
| 21 | `EDGE-15` | Status Banner | Review panel displays A-only marker | `review.innerText()` matches `/READ_ONLY_GEOMETRY\|Transfer unavailable/i` | **PASS** | Truthful A-only non-certifying banner |
| 22 | `EDGE-16` | Evidence Capture | Edge candidate review panel screenshot captured | `page.screenshot({ path: '...edge-candidate-review-4060-4970.png' })` | **PASS** | File written (129,317 bytes) |
| 23 | `EDGE-17` | Invalidation | Changing anchor 3910→5110 marks review HOLD/invalidated | `inputs.locator('[data-ciiw-method-c-anchor-source]').fill('5110')` | **PASS** | Review text reflects HOLD/invalidated |
| 24 | `EDGE-18` | Invalidation | Export button removed from DOM after stale state | `shell.locator('[data-ciiw-candidate-export]').count() === 0` | **PASS** | Count = 0 (stale export impossible) |
| 25 | `EDGE-19` | Session Health | Zero console errors and zero uncaught page errors | Console error listener count = 0, pageerror count = 0 | **PASS** | 0 console errors, 0 page errors |
| 26 | `EDGE-20` | Evidence Capture | Edge stale invalidation screenshot captured | `page.screenshot({ path: '...edge-stale-invalidation-5110.png' })` | **PASS** | File written (56,837 bytes) |

---

## 2. Explicit Unmeasured / NOT_RUN Capabilities

The 26 passed assertions above establish the functional behavior of the A-only candidate review prototype. The following properties were **NOT_RUN** or not instrumented in this automated script and must **NOT** be inferred as passing:

1. **Full Keyboard Accessibility Traversal (`NOT_RUN`):**  
   While DOM interactive elements have accessible semantics, full end-to-end Tab/Shift-Tab focus traversal without mouse intervention was not measured by this script.
2. **Main-Thread Frame Timing & FPS Budget (`NOT_RUN`):**  
   Neither `requestAnimationFrame` timing loops nor Chrome Trace Event profiling was recorded during table scrolling or candidate inspection.
3. **High-Frequency Animation Frame Gaps (`NOT_RUN`):**  
   Jank / frame drops were not measured.
4. **Cancellation Watchdog Under Concurrent Load (`NOT_RUN`):**  
   Long-running worker cancellation during multi-file normalization was not tested.
5. **Issue #121 3-Source Full Inspect (`HOLD` / `NOT_RUN`):**  
   The legacy 145-second heavy normalization path was intentionally not executed to prevent unrelated UI deadlock.
