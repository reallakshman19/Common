# FIREBREAK_RECONCILIATION.md — Firebreak Test Discrepancy & Root Cause Attribution

**Affected File:** `tests/cii-workspace-method-c-i126-firebreak.test.mjs`  
**Candidate SHA:** `69eebe419e6b662ec5ac96412ebd01e44d4f1350` (PR #137)  
**Mainline Anchor (`I126_BASE`):** `9a5916f972af170f272c525907728237391b7ca8`  

---

## 1. The Discrepancy

Two published GitHub Issue #126 comments reported conflicting test results for the exact same file:

| Report | Source | Passed | Failed | Test Runner Cited |
|---|---|:---:|:---:|---|
| **First Local Report** | [Issue #126 comment 6283322040](https://github.com/reallakshman19/XML_Compare_Utilities/issues/126#issuecomment-6283322040) | **3** | **2** | `node --experimental-vm-modules node_modules/.bin/jest` |
| **Incoming Result** | [Issue #126 comment 6283639643](https://github.com/reallakshman19/XML_Compare_Utilities/issues/126#issuecomment-6283639643) | **2** | **3** | `node --test` (Node.js built-in runner) |
| **GitHub Actions CI** | Run [#39355899512](https://github.com/reallakshman19/XML_Compare_Utilities/actions/runs/39355899512) (Linux Ubuntu 24.04) | **4** | **1** | `node --test` (as subtests in CI workflow) |

---

## 2. Source Code & Assertion Structure (At Candidate `69eebe41`)

The file contains exactly five tests defined via `node:test`:

1. **Test 1 (Lines 34–39):** `I126 A-only bridge has identical served and source modules`
   - *Assertion:* `assert.equal(content('docs/' + root + file), content(root + file))` for the 4 Method C workspace modules.
2. **Test 2 (Lines 41–54):** `I126 sidecar has no route to independent physical qualification or Writer2 Apply`
   - *Assertion:* Regex checks asserting absence of mutators (`applyCiiWorkspaceTargetWriter2WithVersionBridge`, `ciiCanonicalWriter2MutationSelection`), absence of Apply controls (`data-ciiw-ms-apply`), absence of `identityBound: true`, and presence of `qualifiedPhysicalIdentityCount: 0`, `applyAuthorized: false`, `mutationOperations: []`.
3. **Test 3 (Lines 56–63):** `I126 exact PR diff excludes PR107 ownership, benchmarks and previous gate oracles`
   - *Assertion:* Compares `git diff --name-only 9a5916f972af170f272c525907728237391b7ca8 HEAD` against an allowed whitelist function `allowed(name)`; asserts `forbidden.length === 0` with message `'I126_SCOPE_GRANT_REQUIRED_FOR_NEW_OR_PROTECTED_FILE'`.
4. **Test 4 (Lines 66–81):** `I126 Writer2 source/deployed entrypoints contain the exact read-only mount and no unrelated edits`
   - *Assertion:* Compares `content('tabs/cii-workspace/cii-workspace-tab.js')` against `expected` formed by replacing strings in `git show 9a5916f972af170f272c525907728237391b7ca8:tabs/cii-workspace/cii-workspace-tab.js`.
5. **Test 5 (Lines 84–94):** `I126 predecessor WP7/WP9 jobs remain intact but may run only on original PR118 branch`
   - *Assertion:* Reads `.github/workflows/cii-method-c-wp2.yml` and checks `workflow.includes('  ' + job + ':\n' + guard + '\n    name:')` for 8 predecessor jobs.

---

## 3. Re-Execution & Concrete Test Results

Command: `node --test tests/cii-workspace-method-c-i126-firebreak.test.mjs`  
Exit Code: `1`  
Summary: **2 PASS · 3 FAIL · 0 SKIPPED**

```text
TAP version 13
# Subtest: I126 A-only bridge has identical served and source modules
ok 1 - I126 A-only bridge has identical served and source modules
# Subtest: I126 sidecar has no route to independent physical qualification or Writer2 Apply
ok 2 - I126 sidecar has no route to independent physical qualification or Writer2 Apply
# Subtest: I126 exact PR diff excludes PR107 ownership, benchmarks and previous gate oracles
not ok 3 - I126 exact PR diff excludes PR107 ownership, benchmarks and previous gate oracles
# Subtest: I126 Writer2 source/deployed entrypoints contain the exact read-only mount and no unrelated edits
not ok 4 - I126 Writer2 source/deployed entrypoints contain the exact read-only mount and no unrelated edits
# Subtest: I126 predecessor WP7/WP9 jobs remain intact but may run only on original PR118 branch
not ok 5 - I126 predecessor WP7/WP9 jobs remain intact but may run only on original PR118 branch
1..5
# tests 5
# suites 0
# pass 2
# fail 3
```

---

## 4. Check-by-Check Failure Ledger & Attribution

| Test | Actual Status | Error / Failure Mechanism | Asserted Expectation | Observed Reality | Attribution Class | Explanation |
|---|:---:|---|---|---|---|---|
| **Test 1** | **PASS** | None | Source and deployed files match | Identical byte hashes | N/A | Operational |
| **Test 2** | **PASS** | None | Zero mutation authorities / 0 qualified | Zero match forbidden patterns | N/A | Operational |
| **Test 3** | **FAIL** | `AssertionError: I126_SCOPE_GRANT_REQUIRED_FOR_NEW_OR_PROTECTED_FILE` | Diff from `9a5916f9` (`main`) must only touch whitelisted I126 files (`forbidden === []`) | ~85 unreleased files present in git diff against `main` | **STACK_ANCESTRY_SCOPE_CONFLICT** (Pre-Existing) | PR #137 was branched from stacked PR #136 (`0a0f28ab`), which inherits unreleased Issue #121 worker files, workreports, and workflows not present in `main`. |
| **Test 4** | **FAIL** | `AssertionError [ERR_ASSERTION]: Expected values to be strictly equal` at line 79 | Exact character-for-character match against synthetic `expected` string | `expected` uses LF (`\n`); working tree file on Windows uses CRLF (`\r\n`) | **TEST_HARNESS_ERROR** (Platform Line-Ending) | On Windows, git checkouts convert text to CRLF (`\r\n`), whereas `git show` outputs LF (`\n`). Test 4 constructs `expected` with `\n`, causing a line-ending mismatch. This test PASSED in Linux CI (`ok 16`). |
| **Test 5** | **FAIL** | `AssertionError [ERR_ASSERTION]: unbounded predecessor job: physical-geometry` at line 92 | Workflow text contains `'  ' + job + ':\n' + guard + '\n    name:'` | Workflow text on Windows has CRLF `:\r\n` | **TEST_HARNESS_ERROR** (Platform Line-Ending) | The test assertion specifically searches for LF `:\n`. On Windows with CRLF checkout, `workflow.includes(':\n')` evaluates to false. This test PASSED in Linux CI (`ok 17`). |

---

## 5. Resolution of the Discrepancy

1. **Why the First Report Stated "3/5 PASS, 2 FAIL":**
   - The first agent executed `node --test tests/cii-workspace-method-c-i126-firebreak.test.mjs` in step 223 of the previous session. The raw tool output in step 224 showed:
     `# tests 5; # pass 2; # fail 3`.
   - When drafting the handover comment, the agent experienced an authoring transcription error (inverting 2 and 3, or subtracting 2 from 5 to infer 3 passes).
   - Furthermore, the first report cited a non-existent runner command `node --experimental-vm-modules node_modules/.bin/jest tests/cii-workspace-method-c-i126-firebreak.test.mjs`. In reality, `jest` is not installed in `node_modules` (execution yields `Cannot find module .../node_modules/jest/bin/jest.js`).
2. **Why the Incoming Report Stated "2 PASS, 3 FAIL":**
   - The incoming agent re-ran `node --test tests/cii-workspace-method-c-i126-firebreak.test.mjs`, inspected the actual TAP summary, and correctly identified that **2 passed and 3 failed**. In step 346 of the session transcript, the agent explicitly noted:
     *"Note: the predecessor's claim of 3/5 PASS is confirmed, but the actual failure count is 3 fails (not 2 as stated in the previous handover comment — that was a miscount)."*
3. **Why CI Showed 4 PASS / 1 FAIL:**
   - In GitHub Actions run #39355899512 on Ubuntu Linux 24.04, git checkouts retain LF (`\n`). Therefore, Tests 4 and 5 did not encounter CRLF line-ending mismatches and passed cleanly. Only Test 3 failed in CI due to the genuine stacked PR ancestry scope conflict.
4. **Final Verdict:**
   - On Windows local execution, the true and reproducible result is **2 PASS, 3 FAIL**.
   - No test assertions were altered, weakened, or deleted to reach this conclusion.
