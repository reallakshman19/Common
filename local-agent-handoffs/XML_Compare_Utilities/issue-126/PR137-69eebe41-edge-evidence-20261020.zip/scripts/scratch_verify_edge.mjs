import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { chromium } from '@playwright/test';

const root = path.resolve(fileURLToPath(new URL('./docs/', import.meta.url)));

function serve() {
  const server = createServer(async (req, res) => {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname);
    } catch {
      res.writeHead(400); res.end(); return;
    }
    if (pathname.startsWith('/XML_Compare_Utilities/')) pathname = pathname.slice('/XML_Compare_Utilities'.length);
    const target = path.resolve(root, pathname === '/' ? 'index.html' : pathname.replace(/^\/+/,''));
    if (!target.startsWith(root + path.sep) && target !== path.join(root, 'index.html')) {
      res.writeHead(403); res.end(); return;
    }
    try {
      const bytes = await readFile(target);
      const type = target.endsWith('.html') ? 'text/html; charset=utf-8' :
        target.endsWith('.js') || target.endsWith('.mjs') ? 'text/javascript; charset=utf-8' :
        target.endsWith('.css') ? 'text/css; charset=utf-8' :
        target.endsWith('.json') ? 'application/json' :
        target.endsWith('.svg') ? 'image/svg+xml' : 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' });
      res.end(bytes);
    } catch {
      res.writeHead(404); res.end('not found');
    }
  });
  return new Promise(resolve => server.listen(0, '127.0.0.1', () => resolve({ server, url: 'http://127.0.0.1:' + server.address().port })));
}

async function verifyInEdge() {
  console.log('=== STARTING WINDOWS MICROSOFT EDGE VERIFICATION ===');
  const { server, url } = await serve();
  let browser;
  const results = {};

  try {
    browser = await chromium.launch({ channel: 'msedge', headless: true });
    const edgeVersion = browser.version();
    console.log('Target Browser: Microsoft Edge (channel: msedge), version:', edgeVersion);
    results.browserVersion = edgeVersion;

    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    const pageErrors = [];
    page.on('pageerror', err => pageErrors.push(err.message));
    page.on('console', msg => {
      if (msg.type() === 'error') pageErrors.push(msg.text());
    });

    console.log('Navigating to', url + '/');
    await page.goto(url + '/', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2000);

    // Step 1: Navigation to Utilities and verify single Method C action
    await page.locator('.app-tab[data-tab="psnm-utility"]').click({ timeout: 45000 });
    await page.locator('[data-ciiw-open-method-c]').waitFor({ state: 'visible', timeout: 60000 });
    const methodCTileCount = await page.locator('[data-ciiw-open-method-c]').count();
    assert.equal(methodCTileCount, 1, 'Exactly one Method C tile on utility tab');
    console.log('Check 1 PASS: Method C tile count = 1');

    await page.locator('[data-ciiw-open-writer2]').click();
    const shell = page.locator('.ciiw-backdrop .ciiw-workspace');
    await shell.locator('[data-ciiw-panel="inputs"]').waitFor({ state: 'visible' });

    const writer2MethodCCount = await shell.locator('[data-ciiw-panel="inputs"] [data-ciiw-method-c-run]').count();
    assert.equal(writer2MethodCCount, 1, 'Exactly ONE Method C run action inside Writer2 inputs');
    const applyCountInitial = await shell.locator('[data-ciiw-method-c-apply]').count();
    assert.equal(applyCountInitial, 0, 'No Method C apply button');
    console.log('Check 2 PASS: Writer2 inputs contains exactly 1 Method C action, 0 apply buttons');

    // Step 2: Read and verify authentic benchmark files S1/S2/S3/T
    const files = ['S1', 'S2', 'S3', 'T'];
    const expected = [
      '9a9cb14db4c13f5aac41cc74a60e7e528722eb5003d09f07192762ab6bfb1a2b',
      '7ec48b76b65eedfd5ecc9c8e8feca1a45dd8c83721a68b53aa0db3363e6d27fd',
      'c2143b31c482158ac5514d2709406c14a9179e656277c654e932bb845d090caa',
      'abfa3ffc9281fe75d4170b2d885d554cb1f120dadedae7c7ab609548b63cc060',
    ];
    const originals = await Promise.all(files.map(async (id, i) => {
      const filePath = path.resolve(root, '..', 'Benchmark', id + '.CII');
      const buffer = await readFile(filePath);
      const sha = createHash('sha256').update(buffer).digest('hex');
      assert.equal(sha, expected[i], `SHA mismatch for ${id}`);
      return { name: id + '.CII', mimeType: 'text/plain', buffer, sha };
    }));
    console.log('Check 3 PASS: Authentic S1/S2/S3/T verified with exact SHA256 hashes');
    results.fileHashes = originals.map(f => ({ name: f.name, sha: f.sha }));

    // Step 3: Upload files once
    await shell.locator('[data-ciiw-source]').setInputFiles(originals.slice(0, 3));
    await shell.locator('[data-ciiw-target]').setInputFiles(originals[3]);

    await shell.locator('[data-ciiw-method-c-message]')
      .filter({ hasText: /S1\/S2\/S3\/T SHA custody READY/ }).waitFor({ timeout: 60000 });
    console.log('Check 4 PASS: Retained file custody established (S1/S2/S3/T SHA custody READY)');

    // Step 4: Run Method C geometry experiment
    await shell.locator('[data-ciiw-method-c-run]').click();
    const inputs = shell.locator('[data-ciiw-method-c-inputs]');
    await inputs.waitFor({ state: 'visible' });
    assert.equal(await inputs.locator('input[type="file"]').count(), 0, 'No re-upload input fields in Method C');
    await inputs.locator('[data-ciiw-method-c-member]').selectOption('S1');
    await inputs.locator('[data-ciiw-method-c-anchor-source]').fill('3910');
    await inputs.locator('[data-ciiw-method-c-anchor-target]').fill('875');
    await inputs.locator('[data-ciiw-method-c-start]').click();

    // Step 5: Check Compare Review table
    const review = shell.locator('[data-ciiw-panel="compare"] [data-ciiw-method-c-review]');
    await review.locator('[data-ciiw-method-c-a-table] tbody tr').first().waitFor({ timeout: 60000 });
    const rowCount = await review.locator('tbody tr').count();
    assert.equal(rowCount, 57, 'Exactly 57 rows in Method C table');
    console.log('Check 5 PASS: Exactly 57 observations rendered in Compare Review table');

    const detail4060 = review.locator('tr[data-source-node="4060"]');
    const status4060 = await detail4060.getAttribute('data-status');
    assert.equal(status4060, 'MISSING_TARGET_NODE_BUT_ALIGNED_SEGMENT');
    const text4060 = await detail4060.innerText();
    assert.match(text4060, /900|905/);
    console.log('Check 6 PASS: Node 4060 has status MISSING_TARGET_NODE_BUT_ALIGNED_SEGMENT with endpoints 900->905');

    assert.equal(await shell.locator('[data-ciiw-method-c-apply]').count(), 0);
    assert.match(await review.innerText(), /READ_ONLY_GEOMETRY/);

    // Step 6: Interactive Review geometric candidates
    const nextBtn = review.locator('[data-ciiw-candidate-open]');
    assert.equal(await nextBtn.count(), 1, 'Review geometric candidates button exists');
    await nextBtn.click();

    const candidatePanel = review.locator('[data-ciiw-candidate-panel]');
    await candidatePanel.waitFor({ state: 'visible' });
    const panelText = await candidatePanel.innerText();
    assert.match(panelText, /physical verification pending/i);
    assert.match(panelText, /Transfer unavailable/i);
    console.log('Check 7 PASS: Review candidate panel visible with "physical verification pending" and "Transfer unavailable"');

    const candidateRowsCount = await candidatePanel.locator('[data-ciiw-a-review-row]').count();
    assert.equal(candidateRowsCount, 57, 'Exactly 57 rows in interactive candidate review list');

    // Step 7: Investigate NODE 4060
    await candidatePanel.locator('[data-ciiw-candidate-select="4060"]').click();
    const node4060Detail = await candidatePanel.locator('[data-ciiw-candidate-detail]').innerText();
    assert.match(node4060Detail, /900.*905/);
    assert.match(node4060Detail, /no physical TARGET NODE/i);
    await candidatePanel.locator('[data-ciiw-candidate-disposition]').selectOption('EVIDENCE_REQUESTED');
    await candidatePanel.locator('[data-ciiw-candidate-note]').fill('4060 is only a signed TARGET segment witness (Edge verification)');
    await candidatePanel.locator('[data-ciiw-candidate-save]').click();
    console.log('Check 8 PASS: NODE 4060 investigated and disposition EVIDENCE_REQUESTED saved');

    // Step 8: Investigate NODE 4970
    await candidatePanel.locator('[data-ciiw-candidate-select="4970"]').click();
    const node4970Detail = await candidatePanel.locator('[data-ciiw-candidate-detail]').innerText();
    assert.match(node4970Detail, /OUTSIDE_TOLERANCE/);
    await candidatePanel.locator('[data-ciiw-candidate-disposition]').selectOption('INVESTIGATE');
    await candidatePanel.locator('[data-ciiw-candidate-note]').fill('Investigate original signed ELEMENT transition (Edge verification)');
    await candidatePanel.locator('[data-ciiw-candidate-save]').click();
    console.log('Check 9 PASS: NODE 4970 investigated and disposition INVESTIGATE saved');

    // Step 9: Take screenshot in Edge
    const evidenceDir = path.resolve(root, '..', 'test-results', 'i126-edge-evidence');
    await mkdir(evidenceDir, { recursive: true });
    const screenshotPath = path.join(evidenceDir, 'edge-candidate-review-4060-4970.png');
    await page.screenshot({ path: screenshotPath });
    console.log('Check 10 PASS: Screenshot saved to', screenshotPath);

    // Step 10: Export JSON receipt
    const [download] = await Promise.all([
      page.waitForEvent('download', { timeout: 30000 }),
      candidatePanel.locator('[data-ciiw-candidate-export]').click(),
    ]);
    const downloadedPath = await download.path();
    const receiptContent = await readFile(downloadedPath, 'utf8');
    const receipt = JSON.parse(receiptContent);
    const receiptDest = path.join(evidenceDir, download.suggestedFilename());
    await writeFile(receiptDest, receiptContent, 'utf8');
    console.log('Check 11 PASS: JSON downloaded to', receiptDest);

    // Step 11: Validate JSON receipt structure and strict A-only gates
    assert.equal(receipt.schema, 'MethodC.AOnlyCandidateReview.v1');
    assert.equal(receipt.authority, 'REVIEW_ONLY_GEOMETRIC_EVIDENCE_NOT_PHYSICAL_CERTIFICATE');
    assert.equal(receipt.sourceId, 'S1');
    assert.equal(receipt.sessionEpoch > 0, true);
    assert.equal(receipt.sourceOriginalSha256, expected[0]);
    assert.equal(receipt.targetOriginalSha256, expected[3]);
    assert.equal(receipt.counts.total, 57);
    assert.equal(receipt.counts.candidates, 41);
    assert.equal(receipt.counts.segmentOnly, 5);
    assert.equal(receipt.counts.outside, 11);
    assert.equal(receipt.observations.length, 57);
    assert.equal(receipt.observations.find(r => r.sourceNode === '4060').status, 'MISSING_TARGET_NODE_BUT_ALIGNED_SEGMENT');
    assert.equal(receipt.observations.find(r => r.sourceNode === '4970').status, 'OUTSIDE_TOLERANCE');
    assert.deepEqual(receipt.dispositions.map(row => row.sourceNode), ['4060', '4970']);
    assert.equal(receipt.qualifiedPhysicalIdentityCount, 0);
    assert.equal(receipt.writerEligible, false);
    assert.equal(receipt.applyAuthorized, false);
    assert.deepEqual(receipt.mutationOperations, []);
    console.log('Check 12 PASS: Downloaded JSON strictly conforms to A-only schema with 0 writer operations and 0 qualified physical identities');

    results.receipt = receipt;

    // Step 12: Test stale-state invalidation
    await shell.locator('[data-ciiw-tab="inputs"]').click();
    await inputs.locator('[data-ciiw-method-c-anchor-source]').fill('5110');
    assert.match(await review.innerText(), /HOLD|invalidated/i);
    const staleExportCount = await shell.locator('[data-ciiw-candidate-export]').count();
    assert.equal(staleExportCount, 0, 'Stale review-only export button must disappear after anchor modification');
    console.log('Check 13 PASS: Stale review state immediately invalidated upon anchor alteration');

    const invalidationScreenshotPath = path.join(evidenceDir, 'edge-stale-invalidation-5110.png');
    await page.screenshot({ path: invalidationScreenshotPath });
    console.log('Check 14 PASS: Invalidation screenshot saved to', invalidationScreenshotPath);

    assert.equal(pageErrors.length, 0, 'Page errors encountered: ' + pageErrors.join('; '));
    console.log('Check 15 PASS: 0 console or page errors detected in Edge session');

    results.success = true;
    console.log('=== ALL WINDOWS MICROSOFT EDGE CHECKS PASSED ===');
    return results;
  } finally {
    await browser?.close();
    await new Promise(resolve => server.close(resolve));
  }
}

verifyInEdge().then(res => {
  console.log('RESULT_SUMMARY:', JSON.stringify({
    success: res.success,
    browserVersion: res.browserVersion,
    receiptCounts: res.receipt.counts,
    dispositions: res.receipt.dispositions,
    qualifiedPhysicalIdentityCount: res.receipt.qualifiedPhysicalIdentityCount,
    writerEligible: res.receipt.writerEligible,
    applyAuthorized: res.receipt.applyAuthorized,
  }, null, 2));
  process.exit(0);
}).catch(err => {
  console.error('Edge verification failed:', err);
  process.exit(1);
});
