/**
 * INCOMING AGENT — Independent Microsoft Edge verification for I126 / PR #137
 * Candidate: 69eebe419e6b662ec5ac96412ebd01e44d4f1350
 * Navigation follows the actual app pattern read from the native test.
 * All claims are EXECUTED_HERE.
 */
import { chromium } from './node_modules/playwright/index.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const ROOT = path.resolve(fileURLToPath(new URL('../mysterious-bohr/docs/', import.meta.url)));
const BENCH = path.resolve(fileURLToPath(new URL('../mysterious-bohr/Benchmark/', import.meta.url)));
const ARTIFACT_DIR = path.resolve(fileURLToPath(new URL('../test-results/i126-edge-evidence/', import.meta.url)));

const REFERENCE_HASHES = {
  'S1.CII': '9a9cb14db4c13f5aac41cc74a60e7e528722eb5003d09f07192762ab6bfb1a2b',
  'S2.CII': '7ec48b76b65eedfd5ecc9c8e8feca1a45dd8c83721a68b53aa0db3363e6d27fd',
  'S3.CII': 'c2143b31c482158ac5514d2709406c14a9179e656277c654e932bb845d090caa',
  'T.CII':  'abfa3ffc9281fe75d4170b2d885d554cb1f120dadedae7c7ab609548b63cc060',
};

function serve() {
  const server = createServer(async (req, res) => {
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname); }
    catch { res.writeHead(400); res.end(); return; }
    if (pathname.startsWith('/XML_Compare_Utilities/')) pathname = pathname.slice('/XML_Compare_Utilities'.length);
    const target = path.resolve(ROOT, pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, ''));
    if (!target.startsWith(ROOT + path.sep) && target !== path.join(ROOT, 'index.html')) {
      res.writeHead(403); res.end(); return;
    }
    try {
      const bytes = await readFile(target);
      const type = target.endsWith('.html') ? 'text/html; charset=utf-8'
        : target.endsWith('.js') || target.endsWith('.mjs') ? 'text/javascript; charset=utf-8'
        : target.endsWith('.css') ? 'text/css; charset=utf-8'
        : target.endsWith('.json') ? 'application/json'
        : target.endsWith('.svg') ? 'image/svg+xml' : 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' }); res.end(bytes);
    } catch { res.writeHead(404); res.end('not found'); }
  });
  return new Promise(resolve => server.listen(0, '127.0.0.1', () =>
    resolve({ server, url: 'http://127.0.0.1:' + server.address().port })));
}

const checks = [];
let browserVersion = 'UNKNOWN';
const p = (id, note) => { checks.push({ id, status: 'PASS', note }); console.log(`✓ [PASS] ${id}: ${note}`); };
const f = (id, note) => { checks.push({ id, status: 'FAIL', note }); console.error(`✗ [FAIL] ${id}: ${note}`); };
const nr = (id, note) => { checks.push({ id, status: 'NOT_RUN', note }); console.log(`- [NOT_RUN] ${id}: ${note}`); };

// ── Independent benchmark hash verification ──
for (const [name, refHash] of Object.entries(REFERENCE_HASHES)) {
  const bytes = await readFile(path.join(BENCH, name));
  const actual = createHash('sha256').update(bytes).digest('hex').toLowerCase();
  if (actual === refHash) p(`HASH-${name}`, `SHA-256 independently verified: ${actual.slice(0,16)}…`);
  else f(`HASH-${name}`, `MISMATCH actual=${actual} vs ref=${refHash}`);
}

// ── docs/tabs parity ──
for (const mod of ['cii-workspace-method-c-writer2-bridge.js', 'cii-workspace-method-c-a-candidate-review.js']) {
  const docsBytes = await readFile(path.join(ROOT, 'tabs/cii-workspace', mod));
  const tabsBytes = await readFile(path.resolve(fileURLToPath(new URL(`../mysterious-bohr/tabs/cii-workspace/${mod}`, import.meta.url))));
  const match = createHash('sha256').update(docsBytes).digest('hex') === createHash('sha256').update(tabsBytes).digest('hex');
  if (match) p(`PARITY-${mod.slice(0,20)}`, 'docs/ and tabs/ byte-identical');
  else f(`PARITY-${mod.slice(0,20)}`, 'docs/ and tabs/ DIFFER');
}

// ── Microsoft Edge browser session ──
const { server, url } = await serve();
let browser;
try {
  browser = await chromium.launch({ channel: 'msedge', headless: true });
  browserVersion = browser.version();
  const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage();

  const pageErrors = []; const consoleErrors = [];
  page.on('pageerror', e => pageErrors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text()); });

  await page.goto(url + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2000);

  // Navigate exactly as native test: click psnm-utility tab, then Writer2 tile
  await page.locator('.app-tab[data-tab="psnm-utility"]').click({ timeout: 45000 });
  p('EDGE-01', 'psnm-utility tab clicked in Edge');

  await page.locator('[data-ciiw-open-method-c]').waitFor({ state: 'visible', timeout: 90000 });
  const mcTileCount = await page.locator('[data-ciiw-open-method-c]').count();
  if (mcTileCount === 1) p('EDGE-02', `Method C tile present: count=${mcTileCount}`);
  else f('EDGE-02', `Method C tile count unexpected: ${mcTileCount}`);

  await page.locator('[data-ciiw-open-writer2]').click();
  const shell = page.locator('.ciiw-backdrop .ciiw-workspace');
  await shell.locator('[data-ciiw-panel="inputs"]').waitFor({ state: 'visible' });
  p('EDGE-03', 'Writer2 shell opened, inputs panel visible');

  // Check Method C run button in inputs panel (the core A-only integration)
  const mcRunCount = await shell.locator('[data-ciiw-panel="inputs"] [data-ciiw-method-c-run]').count();
  if (mcRunCount === 1) p('EDGE-04', `ONE Method C run button in inputs panel (count=${mcRunCount})`);
  else f('EDGE-04', `Expected exactly 1 Method C run button, got ${mcRunCount}`);

  // Check review button in compare panel
  const mcReviewCount = await shell.locator('[data-ciiw-panel="compare"] [data-ciiw-method-c-review]').count();
  if (mcReviewCount === 1) p('EDGE-05', `Method C review button in compare panel (count=${mcReviewCount})`);
  else f('EDGE-05', `Expected 1 Method C review button in compare panel, got ${mcReviewCount}`);

  // Apply buttons must be 0
  const applyCount = await shell.locator('[data-ciiw-method-c-apply]').count();
  if (applyCount === 0) p('EDGE-06', 'Zero Apply buttons in Writer2 shell (mutation gate holds)');
  else f('EDGE-06', `Apply button count=${applyCount} — GATE VIOLATION`);

  // Load benchmark files independently and set them
  const fileBuffers = await Promise.all(['S1', 'S2', 'S3', 'T'].map(async (id, i) => {
    const buf = await readFile(path.join(BENCH, id + '.CII'));
    const actualHash = createHash('sha256').update(buf).digest('hex').toLowerCase();
    const refHash = Object.values(REFERENCE_HASHES)[i];
    if (actualHash !== refHash) throw new Error(`Hash mismatch for ${id}.CII at runtime`);
    return { name: id + '.CII', mimeType: 'text/plain', buffer: buf };
  }));

  await shell.locator('[data-ciiw-source]').setInputFiles(fileBuffers.slice(0, 3));
  await shell.locator('[data-ciiw-target]').setInputFiles(fileBuffers[3]);
  p('EDGE-07', 'S1/S2/S3/T benchmark files loaded into Writer2 inputs (hashes verified)');

  // Wait for custody READY
  await shell.locator('[data-ciiw-method-c-message]')
    .filter({ hasText: /S1\/S2\/S3\/T SHA custody READY/ })
    .waitFor({ timeout: 60000 });
  p('EDGE-08', 'S1/S2/S3/T SHA custody READY confirmed in Edge');

  // Click Method C Run
  await shell.locator('[data-ciiw-method-c-run]').click();
  const inputs = shell.locator('[data-ciiw-method-c-inputs]');
  await inputs.waitFor({ state: 'visible' });
  p('EDGE-09', 'Method C inputs dialog visible in Edge');

  // Verify no file inputs inside Method C dialog
  const fileInputsInDialog = await inputs.locator('input[type="file"]').count();
  if (fileInputsInDialog === 0) p('EDGE-10', 'Zero re-upload file inputs inside Method C dialog (original custody preserved)');
  else f('EDGE-10', `Unexpected file input(s) in MC dialog: count=${fileInputsInDialog}`);

  // Set member S1, anchor 3910 → 875, run
  await inputs.locator('[data-ciiw-method-c-member]').selectOption('S1');
  await inputs.locator('[data-ciiw-method-c-anchor-source]').fill('3910');
  await inputs.locator('[data-ciiw-method-c-anchor-target]').fill('875');
  await inputs.locator('[data-ciiw-method-c-start]').click();
  p('EDGE-11', 'Method C run started: S1, anchor 3910→875 (experimental seed, not physical identity)');

  // Wait for 57 A rows
  const review = shell.locator('[data-ciiw-panel="compare"] [data-ciiw-method-c-review]');
  await review.locator('[data-ciiw-method-c-a-table] tbody tr').first().waitFor({ timeout: 60000 });
  const rowCount = await review.locator('tbody tr').count();
  if (rowCount === 57) p('EDGE-12', `Exactly 57 A-only geometry rows in review table (not 41, not 114)`);
  else f('EDGE-12', `Expected 57 rows, got ${rowCount}`);

  // NODE 4060 independent check
  const row4060 = review.locator('tr[data-source-node="4060"]');
  const status4060 = await row4060.getAttribute('data-status').catch(() => null);
  const text4060 = await row4060.innerText().catch(() => '');
  if (status4060 === 'MISSING_TARGET_NODE_BUT_ALIGNED_SEGMENT') {
    p('EDGE-13', `NODE 4060 status=MISSING_TARGET_NODE_BUT_ALIGNED_SEGMENT (segment 900-905 projection confirmed: ${text4060.includes('900') || text4060.includes('905')})`);
  } else {
    f('EDGE-13', `NODE 4060 status unexpected: ${status4060} | text: ${text4060.slice(0,80)}`);
  }

  // Apply button still 0 after run
  const applyAfterRun = await shell.locator('[data-ciiw-method-c-apply]').count();
  if (applyAfterRun === 0) p('EDGE-14', 'Apply button count=0 after MC run (hard firebreak enforced)');
  else f('EDGE-14', `Apply buttons appeared after run: count=${applyAfterRun}`);

  // READ_ONLY_GEOMETRY or transfer-unavailable marker
  const reviewText = await review.innerText().catch(() => '');
  if (/READ_ONLY_GEOMETRY|Transfer unavailable|GEOMETRY_READY_A/i.test(reviewText)) {
    p('EDGE-15', 'Review panel shows A-only status (READ_ONLY_GEOMETRY / Transfer unavailable)');
  } else {
    f('EDGE-15', `Expected READ_ONLY_GEOMETRY marker not found. Preview: ${reviewText.slice(0,120)}`);
  }

  // Screenshot with candidate review open
  const ss1 = path.join(ARTIFACT_DIR, 'incoming-edge-v2-candidate-review.png');
  await page.screenshot({ path: ss1, fullPage: false });
  p('EDGE-16', `Screenshot captured: incoming-edge-v2-candidate-review.png`);

  // Stale-state: change anchor to 5110 and confirm HOLD/invalidated
  await shell.locator('[data-ciiw-tab="inputs"]').click();
  await inputs.locator('[data-ciiw-method-c-anchor-source]').fill('5110');
  await page.waitForTimeout(500);
  const reviewTextAfterStale = await review.innerText().catch(() => '');
  if (/HOLD|invalidated/i.test(reviewTextAfterStale)) {
    p('EDGE-17', 'Stale-state invalidation confirmed: review shows HOLD/invalidated after anchor→5110');
  } else {
    f('EDGE-17', `Stale invalidation NOT detected. Review text: ${reviewTextAfterStale.slice(0,120)}`);
  }

  // Export button must be gone after stale state
  const exportAfterStale = await shell.locator('[data-ciiw-candidate-export]').count();
  if (exportAfterStale === 0) p('EDGE-18', 'Export button removed from DOM after stale-state (cannot export stale evidence)');
  else f('EDGE-18', `Export button still present after stale-state: count=${exportAfterStale}`);

  // Console and page errors
  if (consoleErrors.length === 0 && pageErrors.length === 0) {
    p('EDGE-19', `Zero console errors, zero page errors throughout session`);
  } else {
    f('EDGE-19', `console errors: ${consoleErrors.length}, page errors: ${pageErrors.length} | ${[...consoleErrors, ...pageErrors].slice(0, 3).join(' | ')}`);
  }

  // Screenshot after stale state
  const ss2 = path.join(ARTIFACT_DIR, 'incoming-edge-v2-stale-invalidation.png');
  await page.screenshot({ path: ss2, fullPage: false });
  p('EDGE-20', `Screenshot captured: incoming-edge-v2-stale-invalidation.png`);

} catch (e) {
  f('EDGE-EXCEPTION', e.message.slice(0, 300));
} finally {
  if (browser) await browser.close().catch(() => {});
  await new Promise(resolve => server.close(resolve));
}

// ── Summary ──
const passed = checks.filter(c => c.status === 'PASS').length;
const failed = checks.filter(c => c.status === 'FAIL').length;
const notRun = checks.filter(c => c.status === 'NOT_RUN').length;

console.log('\n═════════════════════════════════════════════════════════');
console.log(`INCOMING AGENT — Independent Edge Verification`);
console.log(`Candidate: 69eebe419e6b662ec5ac96412ebd01e44d4f1350`);
console.log(`Browser: Microsoft Edge ${browserVersion}`);
console.log(`Checks: ${passed}/${checks.length} PASS | ${failed} FAIL | ${notRun} NOT_RUN`);
console.log('═════════════════════════════════════════════════════════');
checks.forEach(c => console.log(`  [${c.status.padEnd(7)}] ${c.id}: ${c.note}`));

const evidence = {
  agent: 'INCOMING-INDEPENDENT',
  candidate: '69eebe419e6b662ec5ac96412ebd01e44d4f1350',
  executedAt: new Date().toISOString(),
  browserChannel: 'msedge',
  browserVersion,
  checksPassed: `${passed}/${checks.length}`,
  checksFailed: failed,
  checksNotRun: notRun,
  checks,
  predecessorClaimsIndependentlyVerified: {
    'S1SHA': checks.find(c=>c.id==='HASH-S1.CII')?.status,
    'S2SHA': checks.find(c=>c.id==='HASH-S2.CII')?.status,
    'S3SHA': checks.find(c=>c.id==='HASH-S3.CII')?.status,
    'TSHA': checks.find(c=>c.id==='HASH-T.CII')?.status,
    '57rows': checks.find(c=>c.id==='EDGE-12')?.status,
    'applyCount0': checks.find(c=>c.id==='EDGE-06')?.status,
    'node4060Status': checks.find(c=>c.id==='EDGE-13')?.status,
    'staleInvalidation': checks.find(c=>c.id==='EDGE-17')?.status,
    'docsParity': checks.find(c=>c.id?.startsWith('PARITY'))?.status,
  },
};
const evPath = path.join(ARTIFACT_DIR, 'incoming-edge-v2-evidence.json');
await writeFile(evPath, JSON.stringify(evidence, null, 2));
console.log(`\nEvidence JSON: ${evPath}`);
process.exit(failed > 0 ? 1 : 0);
