# PR187 — independent review of Windows private-output repair

Destination: Independent Reviewer, existing chat **Review inspector evidence**, actual chat ID `6adf3dbf-424c-83eb-9bb5-012bae1b611f` (`6adf3dbf`).

Owner delivery of this prompt assigns a bounded **READ_ONLY, non-author review**. Inspect source, reproduce tests, derive independent expectations and use isolated scratch probes. Do not edit the product, repair findings, merge, change workflows/dependencies/runtime, create agents or send other chats messages. A prepared local copy is not evidence of delivery or activation.

## Outcome and subject

Decide which claims about PR187's local report protection and portability are supported, contradicted or still untested. The user needs trustworthy private local evidence as the foundation for later Element Property Transfer; a read-only inspector or green test count does not establish engineering-property editing, effective interpretation or WBS4 completion.

- [PR187](https://github.com/reallakshman19/XML_Compare_Utilities/pull/187), OPEN/DRAFT at preparation.
- **Exact candidate:** `df6521e1ed00e5a59a17a46cdc403f6aca970266`; Git tree `89720c96dbe6a8217d3ddf6fa848ecb310d7c642`.
- Repair preimage: `f1ffe90dee5b559c0781ce44f134e22f1f1da656`.
- Inherited PR168 base: `2aeaf7372de66eda3bc082b8d81bf8db43c34f4b`.
- [Exact repair diff](https://github.com/reallakshman19/XML_Compare_Utilities/compare/f1ffe90dee5b559c0781ce44f134e22f1f1da656...df6521e1ed00e5a59a17a46cdc403f6aca970266).
- [Current recovery-first workreport](https://github.com/reallakshman19/XML_Compare_Utilities/blob/df6521e1ed00e5a59a17a46cdc403f6aca970266/agents/PR187_workreport.md). Read its current checkpoint first; historical reports below are preserved history.

Verify repository/head/tree and actual files yourself. Prefer a fresh genuine checkout; record any source-subtree fallback precisely and leave full-checkout integration NOT_RUN. If the live PR changes, retain these exact-candidate findings and identify what requires new-head reconciliation. Do not silently review another head.

## Independence, inherited evidence and environment

The repair author is Oracle/Coder chat `01a17b00-2258-7f50-b364-49c7053b336b`. You are distinct from that chat and authored the earlier independent review, not this repair. Disclose prior exposure and any contribution to these new files before claiming non-author review. Shared GitHub principal `reallakshman19` does **not** establish a distinct authenticated GitHub approver.

Your earlier [IR3 scoped PASS](https://github.com/reallakshman19/XML_Compare_Utilities/issues/188#issuecomment-6423929691) applies to `f1ffe90d`: inspector17 + F3 seven + 536 independent raw-byte assertion groups. Inspector, inherited catalog and F3 source are unchanged by this repair. Verify byte identity and reuse the applicable old findings; do not repeat the whole investigation or claim the new security adapter was covered by IR3.

The author obtained 27/27 on a genuine Windows x64 checkout, Node v22.23.2, using the desktop user's token. AppContainer could not access the deliberately owner-only output directory; no DACL relaxation was used. These are **author execution observations**, not your independently executed Windows result. Prior reviewer Linux capability does not establish current Windows access. Report actual OS, Node, token context and available filesystem/security APIs. If Windows is unavailable, proceed with source review and Linux; leave independent native Windows execution NOT_RUN and return a scoped PARTIAL where needed.

The issue #188 opening body and Common Cycle revision8 contain historical candidate/assignment data. Do not use their old head or old dispatch as a new assignment. This request is not a Cycle generation or Oracle identity change. No Common receipt or control mutation is authorized by this prompt.

## Changed files

Review only this eight-file repair and its affected integration:

1. `tools/ciifr-wbs4/five-field-cli.mjs` — delegates local persistence while preserving source inspection, public-summary whitelist and direct CLI rejection contract.
2. `tools/ciifr-wbs4/private-output.mjs` — fresh directory, exclusive empty files, pre-content security checks, JSON writes, handle closure and bounded cleanup.
3. `tools/ciifr-wbs4/private-output-windows.ps1` — native protected directory creation and real descriptor/type verification.
4. `tests/ciifr-wbs4-five-field-evidence.test.mjs` — native privacy assertion and platform temporary-root test.
5. `tests/helpers/ciifr-private-output.mjs` — separate native/POSIX test assertions.
6. `tests/helpers/ciifr-private-output-access.ps1` — actual current/restricted-token AccessCheck and synthetic-only permissive fixture.
7. `tests/ciifr-wbs4-private-output.test.mjs` — three real filesystem positive/contrary/failure cases.
8. `agents/PR187_workreport.md` — current facts, prior failures, limits and recovery.

Read the current repository AGENTS instructions and applicable task authority. Appendix A is an implementation gate; this assignment grants no implementation or product writer custody. Keep scratch outputs/seeded defects outside the candidate. Never discard another task's changes.

## Required checks

### 1. Integration and Linux regression

At the exact candidate run:

```text
git rev-parse HEAD
git show -s --format=%T HEAD
node --version
node --test --test-reporter=tap tests/ciifr-wbs4-private-output.test.mjs tests/ciifr-wbs4-five-field-evidence.test.mjs tests/ciifr-wbs4-five-field-f3.test.mjs
```

Expected suite count is 27, with no skipped assertion used to conceal a platform failure. Preserve actual exit/counts and full safe output privately. Run on Linux and native Windows where genuinely available. Linux's mode/uid assertions are not a Windows restricted-token result, even if the shared test name mentions tokens. Existing hosted workflow run [40696852219](https://github.com/reallakshman19/XML_Compare_Utilities/actions/runs/40696852219) passed catalog/NodeName tests; it does not execute these 27 inspector cases.

### 2. Windows protection before private content

Trace actual `CreateDirectoryW` security attributes, current owner SID, protected DACL, inheritable current-user FullControl ACE, reparse/object-type rejection, exclusive report opens and both empty-file checks **before** JSON writes. Check directory, private-report.json and public-summary.json separately. POSIX `stat.mode` is not a Windows ACL oracle.

Independently inspect real descriptors and test authorization. Establish current-token read allowed and the documented Everyone-restricted-token read denied for all three objects. Inspect the test oracle itself: token rights, primary versus impersonation handles, generic mapping and the distinction between an API error and an actual denied access decision. An API failure must not count as a privacy PASS. This is a bounded authorization check, not proof about every privileged principal or a second login.

Use a real **synthetic-only** permissive-file contrast, independently derived rather than expected values copied from the production verifier. Show that a broad Read ACE changes the restricted-token read result and is detected. Never broaden permissions on a real inspector report or protected original. Inspect environment/path trust, unsupported protection providers/filesystems and any time-of-check versus open-handle assumptions that materially affect the claimed boundary.

Where useful, seed one plausible security mistake in an isolated disposable copy and show your method catches it; keep candidate and independent expected values unchanged. Report a surviving wrong-result risk if your checks cannot distinguish it.

### 3. Temporary-root behavior and error privacy

On Windows independently contrast TEMP versus TMP versus TMPDIR, with conflicting values set only in the child process. Confirm expected root from platform authority and a separate Node probe, then exercise the CLI with spaces in both paths. On Linux use the actual POSIX precedence. Read both resulting JSONs and verify cleanup. Do not alter global environment, policy or account settings.

Challenge a genuine protection/setup failure and direct CLI rejection. Check nonzero exit, constant `FIVE_FIELD_INSPECTOR_ERROR=SOURCE_REJECTED`, no private input basename/content/lexeme/byte span/digest in stdout or stderr, and no private contents written before protection is established. Avoid mocks where actual process/filesystem behavior suffices.

### 4. Partial output and cleanup

Existing new failure coverage uses a circular first report. Add a different isolated probe in which the first private report is written and **second-report** serialization fails. Check handle closure, exact created-file cleanup and containment within the task-created root. Trace close/unlink/directory-removal failures separately: do not claim guaranteed cleanup when the OS rejects it, and distinguish protected leftovers from permissive disclosure. Assess the direct CLI privacy contract separately from trusted in-process exceptions.

### 5. Preserve engineering limits

Confirm the inherited catalog, source inspector and F3 behavior remain unchanged; malformed I13 rejection, source immutability, occurrence/branch identity and public-summary privacy still hold at the tested integration boundary. General PR168 all-15-pointer lexical correction under #173 is separate. Do not reopen settled semantics or repeat all536 earlier assertions merely to generate a new count.

No protected original or CAESAR installation is required for this synthetic review. Effective units, Alpha/material interpretation, active job/basic cases/FDM, RIGID engineering meaning, SOURCE-to-TARGET correspondence, E2–E5 property transfer, Writer/TARGET1 and merge remain unqualified/held.

## Return

Return an evidence-backed review of this exact head on the Owner-authorized native review route [XCU #188](https://github.com/reallakshman19/XML_Compare_Utilities/issues/188), or through the Owner if publication is unavailable. Do not message another chat or post a Common Cycle receipt. Give:

- Your identity, authorship/exposure disclosure, exact source/head/tree, OS/Node/token/checkout basis.
- Per claim: `STATUS = PASS | FAIL | NOT_RUN | NOT_APPLICABLE`, observed execution/inspection basis, and independent versus implementation-coupled oracle.
- Real commands/counts, independent permission and temporary-root contrasts, partial-second-report probe and any seeded-defect result.
- Supported and contradicted claims, concrete findings with tight file/line references, untested conditions and one plausible surviving error.
- A scoped overall `PASS / FAIL / PARTIAL / BLOCKED`, with Windows and Linux dispositions kept distinct. Unavailable Windows is not a defect in Linux and is not a Windows PASS.
- One exact next action, responsible actor and return condition. If a repair is needed, report it for the existing author; do not implement it or merge.

## Platform authorities

- [Node v22.23.2 os.tmpdir](https://nodejs.org/download/release/v22.23.2/docs/api/os.html#ostmpdir)
- [Node Windows file modes](https://nodejs.org/download/release/v22.23.2/docs/api/fs.html#file-modes)
- [CreateDirectoryW security attributes](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createdirectoryw)
- [AccessCheck](https://learn.microsoft.com/en-us/windows/win32/api/securitybaseapi/nf-securitybaseapi-accesscheck)
- [CreateRestrictedToken](https://learn.microsoft.com/en-us/windows/win32/api/securitybaseapi/nf-securitybaseapi-createrestrictedtoken)
- [DuplicateToken rights](https://learn.microsoft.com/en-us/windows/win32/api/securitybaseapi/nf-securitybaseapi-duplicatetoken)

This return is independent technical evidence, not Owner acceptance, authenticated GitHub approval, WBS4 completion or merge authority.
