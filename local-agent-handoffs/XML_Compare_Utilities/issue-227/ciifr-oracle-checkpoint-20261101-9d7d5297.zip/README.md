# CIIFR Oracle checkpoint — 1 November 2026

Start with [the novice checkpoint and CII primer](docs/ciifr/property-transfer/v2/05_ORACLE_CHECKPOINT.md), then [the copy-ready Oracle prompt](docs/ciifr/property-transfer/v2/06_ORACLE_TAKEOVER_PROMPT.md). All four linked design documents are included at their repository paths.

Repository: reallakshman19/XML_Compare_Utilities; program issue227; product documentation PR245. Published checkpoint commit: 9d7d5297e9709db1ef5c54e7c7def748c77f0598. Input design head: 9a181e579011ea22d313a23196db8797ead0b675. Main snapshot: 3051ea171f966ac611f232982e0b1cc0774ba368. Refresh mutable sources before dependent action.

SOURCE_SNAPSHOT.json records inspected metadata/source identities; PRODUCT_READBACK.json records publication readback of four changed Markdown files. These are source/transport checks, not product test results. No new engineering/native/browser/CAESAR run was performed; historical results retain their own limits.

The nested reference ZIP is the unchanged public-safe parked-experiment reference already present in PR245, not installed code. No private CII, derived private XML, private paths/digests/screenshots or secrets are included. Some existing repository links require GitHub/network access. Relative links to pre-v2 documents outside this pack are repository references, not omitted acceptance evidence.

Coding is paused. This artifact grants no code/writer/agent-dispatch/merge/deployment/release authority. Successor identity, receipt/hash verification and acceptance are NOT_CONFIRMED. The verified project slug is the owning repository name XML_Compare_Utilities; no conflicting Common folder was present. This one-file artifact PR adds no separate project-index/main change.

Verify MANIFEST.json against actual archive members. Integrity/publication do not authenticate engineering correctness. Return successor reconciliation to issue227/PR245 under actual authority; do not create new legacy Common/relay records.
